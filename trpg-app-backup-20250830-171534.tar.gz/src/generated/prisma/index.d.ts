
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Character
 * 
 */
export type Character = $Result.DefaultSelection<Prisma.$CharacterPayload>
/**
 * Model Scenario
 * 
 */
export type Scenario = $Result.DefaultSelection<Prisma.$ScenarioPayload>
/**
 * Model Session
 * 
 */
export type Session = $Result.DefaultSelection<Prisma.$SessionPayload>
/**
 * Model SkillHistory
 * 
 */
export type SkillHistory = $Result.DefaultSelection<Prisma.$SkillHistoryPayload>
/**
 * Model SanityHistory
 * 
 */
export type SanityHistory = $Result.DefaultSelection<Prisma.$SanityHistoryPayload>
/**
 * Model InsanitySymptom
 * 
 */
export type InsanitySymptom = $Result.DefaultSelection<Prisma.$InsanitySymptomPayload>
/**
 * Model CharacterImage
 * 
 */
export type CharacterImage = $Result.DefaultSelection<Prisma.$CharacterImagePayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Characters
 * const characters = await prisma.character.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Characters
   * const characters = await prisma.character.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.character`: Exposes CRUD operations for the **Character** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Characters
    * const characters = await prisma.character.findMany()
    * ```
    */
  get character(): Prisma.CharacterDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.scenario`: Exposes CRUD operations for the **Scenario** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Scenarios
    * const scenarios = await prisma.scenario.findMany()
    * ```
    */
  get scenario(): Prisma.ScenarioDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.session`: Exposes CRUD operations for the **Session** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Sessions
    * const sessions = await prisma.session.findMany()
    * ```
    */
  get session(): Prisma.SessionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.skillHistory`: Exposes CRUD operations for the **SkillHistory** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SkillHistories
    * const skillHistories = await prisma.skillHistory.findMany()
    * ```
    */
  get skillHistory(): Prisma.SkillHistoryDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sanityHistory`: Exposes CRUD operations for the **SanityHistory** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SanityHistories
    * const sanityHistories = await prisma.sanityHistory.findMany()
    * ```
    */
  get sanityHistory(): Prisma.SanityHistoryDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.insanitySymptom`: Exposes CRUD operations for the **InsanitySymptom** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more InsanitySymptoms
    * const insanitySymptoms = await prisma.insanitySymptom.findMany()
    * ```
    */
  get insanitySymptom(): Prisma.InsanitySymptomDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.characterImage`: Exposes CRUD operations for the **CharacterImage** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CharacterImages
    * const characterImages = await prisma.characterImage.findMany()
    * ```
    */
  get characterImage(): Prisma.CharacterImageDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.15.0
   * Query Engine version: 85179d7826409ee107a6ba334b5e305ae3fba9fb
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Character: 'Character',
    Scenario: 'Scenario',
    Session: 'Session',
    SkillHistory: 'SkillHistory',
    SanityHistory: 'SanityHistory',
    InsanitySymptom: 'InsanitySymptom',
    CharacterImage: 'CharacterImage'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "character" | "scenario" | "session" | "skillHistory" | "sanityHistory" | "insanitySymptom" | "characterImage"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      Character: {
        payload: Prisma.$CharacterPayload<ExtArgs>
        fields: Prisma.CharacterFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CharacterFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CharacterFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>
          }
          findFirst: {
            args: Prisma.CharacterFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CharacterFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>
          }
          findMany: {
            args: Prisma.CharacterFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>[]
          }
          create: {
            args: Prisma.CharacterCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>
          }
          createMany: {
            args: Prisma.CharacterCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CharacterCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>[]
          }
          delete: {
            args: Prisma.CharacterDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>
          }
          update: {
            args: Prisma.CharacterUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>
          }
          deleteMany: {
            args: Prisma.CharacterDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CharacterUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CharacterUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>[]
          }
          upsert: {
            args: Prisma.CharacterUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterPayload>
          }
          aggregate: {
            args: Prisma.CharacterAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCharacter>
          }
          groupBy: {
            args: Prisma.CharacterGroupByArgs<ExtArgs>
            result: $Utils.Optional<CharacterGroupByOutputType>[]
          }
          count: {
            args: Prisma.CharacterCountArgs<ExtArgs>
            result: $Utils.Optional<CharacterCountAggregateOutputType> | number
          }
        }
      }
      Scenario: {
        payload: Prisma.$ScenarioPayload<ExtArgs>
        fields: Prisma.ScenarioFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ScenarioFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ScenarioFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>
          }
          findFirst: {
            args: Prisma.ScenarioFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ScenarioFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>
          }
          findMany: {
            args: Prisma.ScenarioFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>[]
          }
          create: {
            args: Prisma.ScenarioCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>
          }
          createMany: {
            args: Prisma.ScenarioCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ScenarioCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>[]
          }
          delete: {
            args: Prisma.ScenarioDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>
          }
          update: {
            args: Prisma.ScenarioUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>
          }
          deleteMany: {
            args: Prisma.ScenarioDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ScenarioUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ScenarioUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>[]
          }
          upsert: {
            args: Prisma.ScenarioUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ScenarioPayload>
          }
          aggregate: {
            args: Prisma.ScenarioAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateScenario>
          }
          groupBy: {
            args: Prisma.ScenarioGroupByArgs<ExtArgs>
            result: $Utils.Optional<ScenarioGroupByOutputType>[]
          }
          count: {
            args: Prisma.ScenarioCountArgs<ExtArgs>
            result: $Utils.Optional<ScenarioCountAggregateOutputType> | number
          }
        }
      }
      Session: {
        payload: Prisma.$SessionPayload<ExtArgs>
        fields: Prisma.SessionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SessionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SessionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          findFirst: {
            args: Prisma.SessionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SessionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          findMany: {
            args: Prisma.SessionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>[]
          }
          create: {
            args: Prisma.SessionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          createMany: {
            args: Prisma.SessionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SessionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>[]
          }
          delete: {
            args: Prisma.SessionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          update: {
            args: Prisma.SessionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          deleteMany: {
            args: Prisma.SessionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SessionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SessionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>[]
          }
          upsert: {
            args: Prisma.SessionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          aggregate: {
            args: Prisma.SessionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSession>
          }
          groupBy: {
            args: Prisma.SessionGroupByArgs<ExtArgs>
            result: $Utils.Optional<SessionGroupByOutputType>[]
          }
          count: {
            args: Prisma.SessionCountArgs<ExtArgs>
            result: $Utils.Optional<SessionCountAggregateOutputType> | number
          }
        }
      }
      SkillHistory: {
        payload: Prisma.$SkillHistoryPayload<ExtArgs>
        fields: Prisma.SkillHistoryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SkillHistoryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SkillHistoryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>
          }
          findFirst: {
            args: Prisma.SkillHistoryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SkillHistoryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>
          }
          findMany: {
            args: Prisma.SkillHistoryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>[]
          }
          create: {
            args: Prisma.SkillHistoryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>
          }
          createMany: {
            args: Prisma.SkillHistoryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SkillHistoryCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>[]
          }
          delete: {
            args: Prisma.SkillHistoryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>
          }
          update: {
            args: Prisma.SkillHistoryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>
          }
          deleteMany: {
            args: Prisma.SkillHistoryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SkillHistoryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SkillHistoryUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>[]
          }
          upsert: {
            args: Prisma.SkillHistoryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SkillHistoryPayload>
          }
          aggregate: {
            args: Prisma.SkillHistoryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSkillHistory>
          }
          groupBy: {
            args: Prisma.SkillHistoryGroupByArgs<ExtArgs>
            result: $Utils.Optional<SkillHistoryGroupByOutputType>[]
          }
          count: {
            args: Prisma.SkillHistoryCountArgs<ExtArgs>
            result: $Utils.Optional<SkillHistoryCountAggregateOutputType> | number
          }
        }
      }
      SanityHistory: {
        payload: Prisma.$SanityHistoryPayload<ExtArgs>
        fields: Prisma.SanityHistoryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SanityHistoryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SanityHistoryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>
          }
          findFirst: {
            args: Prisma.SanityHistoryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SanityHistoryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>
          }
          findMany: {
            args: Prisma.SanityHistoryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>[]
          }
          create: {
            args: Prisma.SanityHistoryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>
          }
          createMany: {
            args: Prisma.SanityHistoryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SanityHistoryCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>[]
          }
          delete: {
            args: Prisma.SanityHistoryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>
          }
          update: {
            args: Prisma.SanityHistoryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>
          }
          deleteMany: {
            args: Prisma.SanityHistoryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SanityHistoryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SanityHistoryUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>[]
          }
          upsert: {
            args: Prisma.SanityHistoryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SanityHistoryPayload>
          }
          aggregate: {
            args: Prisma.SanityHistoryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSanityHistory>
          }
          groupBy: {
            args: Prisma.SanityHistoryGroupByArgs<ExtArgs>
            result: $Utils.Optional<SanityHistoryGroupByOutputType>[]
          }
          count: {
            args: Prisma.SanityHistoryCountArgs<ExtArgs>
            result: $Utils.Optional<SanityHistoryCountAggregateOutputType> | number
          }
        }
      }
      InsanitySymptom: {
        payload: Prisma.$InsanitySymptomPayload<ExtArgs>
        fields: Prisma.InsanitySymptomFieldRefs
        operations: {
          findUnique: {
            args: Prisma.InsanitySymptomFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.InsanitySymptomFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>
          }
          findFirst: {
            args: Prisma.InsanitySymptomFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.InsanitySymptomFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>
          }
          findMany: {
            args: Prisma.InsanitySymptomFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>[]
          }
          create: {
            args: Prisma.InsanitySymptomCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>
          }
          createMany: {
            args: Prisma.InsanitySymptomCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.InsanitySymptomCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>[]
          }
          delete: {
            args: Prisma.InsanitySymptomDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>
          }
          update: {
            args: Prisma.InsanitySymptomUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>
          }
          deleteMany: {
            args: Prisma.InsanitySymptomDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.InsanitySymptomUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.InsanitySymptomUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>[]
          }
          upsert: {
            args: Prisma.InsanitySymptomUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InsanitySymptomPayload>
          }
          aggregate: {
            args: Prisma.InsanitySymptomAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateInsanitySymptom>
          }
          groupBy: {
            args: Prisma.InsanitySymptomGroupByArgs<ExtArgs>
            result: $Utils.Optional<InsanitySymptomGroupByOutputType>[]
          }
          count: {
            args: Prisma.InsanitySymptomCountArgs<ExtArgs>
            result: $Utils.Optional<InsanitySymptomCountAggregateOutputType> | number
          }
        }
      }
      CharacterImage: {
        payload: Prisma.$CharacterImagePayload<ExtArgs>
        fields: Prisma.CharacterImageFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CharacterImageFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CharacterImageFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>
          }
          findFirst: {
            args: Prisma.CharacterImageFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CharacterImageFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>
          }
          findMany: {
            args: Prisma.CharacterImageFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>[]
          }
          create: {
            args: Prisma.CharacterImageCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>
          }
          createMany: {
            args: Prisma.CharacterImageCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CharacterImageCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>[]
          }
          delete: {
            args: Prisma.CharacterImageDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>
          }
          update: {
            args: Prisma.CharacterImageUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>
          }
          deleteMany: {
            args: Prisma.CharacterImageDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CharacterImageUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CharacterImageUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>[]
          }
          upsert: {
            args: Prisma.CharacterImageUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CharacterImagePayload>
          }
          aggregate: {
            args: Prisma.CharacterImageAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCharacterImage>
          }
          groupBy: {
            args: Prisma.CharacterImageGroupByArgs<ExtArgs>
            result: $Utils.Optional<CharacterImageGroupByOutputType>[]
          }
          count: {
            args: Prisma.CharacterImageCountArgs<ExtArgs>
            result: $Utils.Optional<CharacterImageCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    character?: CharacterOmit
    scenario?: ScenarioOmit
    session?: SessionOmit
    skillHistory?: SkillHistoryOmit
    sanityHistory?: SanityHistoryOmit
    insanitySymptom?: InsanitySymptomOmit
    characterImage?: CharacterImageOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type CharacterCountOutputType
   */

  export type CharacterCountOutputType = {
    sessions: number
    skillHistories: number
    sanityHistories: number
    insanitySymptoms: number
    images: number
  }

  export type CharacterCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    sessions?: boolean | CharacterCountOutputTypeCountSessionsArgs
    skillHistories?: boolean | CharacterCountOutputTypeCountSkillHistoriesArgs
    sanityHistories?: boolean | CharacterCountOutputTypeCountSanityHistoriesArgs
    insanitySymptoms?: boolean | CharacterCountOutputTypeCountInsanitySymptomsArgs
    images?: boolean | CharacterCountOutputTypeCountImagesArgs
  }

  // Custom InputTypes
  /**
   * CharacterCountOutputType without action
   */
  export type CharacterCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterCountOutputType
     */
    select?: CharacterCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * CharacterCountOutputType without action
   */
  export type CharacterCountOutputTypeCountSessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SessionWhereInput
  }

  /**
   * CharacterCountOutputType without action
   */
  export type CharacterCountOutputTypeCountSkillHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SkillHistoryWhereInput
  }

  /**
   * CharacterCountOutputType without action
   */
  export type CharacterCountOutputTypeCountSanityHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SanityHistoryWhereInput
  }

  /**
   * CharacterCountOutputType without action
   */
  export type CharacterCountOutputTypeCountInsanitySymptomsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: InsanitySymptomWhereInput
  }

  /**
   * CharacterCountOutputType without action
   */
  export type CharacterCountOutputTypeCountImagesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CharacterImageWhereInput
  }


  /**
   * Count Type ScenarioCountOutputType
   */

  export type ScenarioCountOutputType = {
    sessions: number
  }

  export type ScenarioCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    sessions?: boolean | ScenarioCountOutputTypeCountSessionsArgs
  }

  // Custom InputTypes
  /**
   * ScenarioCountOutputType without action
   */
  export type ScenarioCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ScenarioCountOutputType
     */
    select?: ScenarioCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ScenarioCountOutputType without action
   */
  export type ScenarioCountOutputTypeCountSessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SessionWhereInput
  }


  /**
   * Count Type SessionCountOutputType
   */

  export type SessionCountOutputType = {
    skillHistories: number
    sanityHistories: number
    insanitySymptoms: number
  }

  export type SessionCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    skillHistories?: boolean | SessionCountOutputTypeCountSkillHistoriesArgs
    sanityHistories?: boolean | SessionCountOutputTypeCountSanityHistoriesArgs
    insanitySymptoms?: boolean | SessionCountOutputTypeCountInsanitySymptomsArgs
  }

  // Custom InputTypes
  /**
   * SessionCountOutputType without action
   */
  export type SessionCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SessionCountOutputType
     */
    select?: SessionCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SessionCountOutputType without action
   */
  export type SessionCountOutputTypeCountSkillHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SkillHistoryWhereInput
  }

  /**
   * SessionCountOutputType without action
   */
  export type SessionCountOutputTypeCountSanityHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SanityHistoryWhereInput
  }

  /**
   * SessionCountOutputType without action
   */
  export type SessionCountOutputTypeCountInsanitySymptomsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: InsanitySymptomWhereInput
  }


  /**
   * Models
   */

  /**
   * Model Character
   */

  export type AggregateCharacter = {
    _count: CharacterCountAggregateOutputType | null
    _avg: CharacterAvgAggregateOutputType | null
    _sum: CharacterSumAggregateOutputType | null
    _min: CharacterMinAggregateOutputType | null
    _max: CharacterMaxAggregateOutputType | null
  }

  export type CharacterAvgAggregateOutputType = {
    age: number | null
    str: number | null
    con: number | null
    pow: number | null
    dex: number | null
    app: number | null
    siz: number | null
    int: number | null
    edu: number | null
    luck: number | null
    hp: number | null
    maxHp: number | null
    mp: number | null
    maxMp: number | null
    san: number | null
    maxSan: number | null
    mov: number | null
    build: number | null
  }

  export type CharacterSumAggregateOutputType = {
    age: number | null
    str: number | null
    con: number | null
    pow: number | null
    dex: number | null
    app: number | null
    siz: number | null
    int: number | null
    edu: number | null
    luck: number | null
    hp: number | null
    maxHp: number | null
    mp: number | null
    maxMp: number | null
    san: number | null
    maxSan: number | null
    mov: number | null
    build: number | null
  }

  export type CharacterMinAggregateOutputType = {
    id: string | null
    name: string | null
    occupation: string | null
    age: number | null
    gender: string | null
    birthplace: string | null
    residence: string | null
    createdAt: Date | null
    updatedAt: Date | null
    str: number | null
    con: number | null
    pow: number | null
    dex: number | null
    app: number | null
    siz: number | null
    int: number | null
    edu: number | null
    luck: number | null
    hp: number | null
    maxHp: number | null
    mp: number | null
    maxMp: number | null
    san: number | null
    maxSan: number | null
    mov: number | null
    build: number | null
    skills: string | null
  }

  export type CharacterMaxAggregateOutputType = {
    id: string | null
    name: string | null
    occupation: string | null
    age: number | null
    gender: string | null
    birthplace: string | null
    residence: string | null
    createdAt: Date | null
    updatedAt: Date | null
    str: number | null
    con: number | null
    pow: number | null
    dex: number | null
    app: number | null
    siz: number | null
    int: number | null
    edu: number | null
    luck: number | null
    hp: number | null
    maxHp: number | null
    mp: number | null
    maxMp: number | null
    san: number | null
    maxSan: number | null
    mov: number | null
    build: number | null
    skills: string | null
  }

  export type CharacterCountAggregateOutputType = {
    id: number
    name: number
    occupation: number
    age: number
    gender: number
    birthplace: number
    residence: number
    createdAt: number
    updatedAt: number
    str: number
    con: number
    pow: number
    dex: number
    app: number
    siz: number
    int: number
    edu: number
    luck: number
    hp: number
    maxHp: number
    mp: number
    maxMp: number
    san: number
    maxSan: number
    mov: number
    build: number
    skills: number
    _all: number
  }


  export type CharacterAvgAggregateInputType = {
    age?: true
    str?: true
    con?: true
    pow?: true
    dex?: true
    app?: true
    siz?: true
    int?: true
    edu?: true
    luck?: true
    hp?: true
    maxHp?: true
    mp?: true
    maxMp?: true
    san?: true
    maxSan?: true
    mov?: true
    build?: true
  }

  export type CharacterSumAggregateInputType = {
    age?: true
    str?: true
    con?: true
    pow?: true
    dex?: true
    app?: true
    siz?: true
    int?: true
    edu?: true
    luck?: true
    hp?: true
    maxHp?: true
    mp?: true
    maxMp?: true
    san?: true
    maxSan?: true
    mov?: true
    build?: true
  }

  export type CharacterMinAggregateInputType = {
    id?: true
    name?: true
    occupation?: true
    age?: true
    gender?: true
    birthplace?: true
    residence?: true
    createdAt?: true
    updatedAt?: true
    str?: true
    con?: true
    pow?: true
    dex?: true
    app?: true
    siz?: true
    int?: true
    edu?: true
    luck?: true
    hp?: true
    maxHp?: true
    mp?: true
    maxMp?: true
    san?: true
    maxSan?: true
    mov?: true
    build?: true
    skills?: true
  }

  export type CharacterMaxAggregateInputType = {
    id?: true
    name?: true
    occupation?: true
    age?: true
    gender?: true
    birthplace?: true
    residence?: true
    createdAt?: true
    updatedAt?: true
    str?: true
    con?: true
    pow?: true
    dex?: true
    app?: true
    siz?: true
    int?: true
    edu?: true
    luck?: true
    hp?: true
    maxHp?: true
    mp?: true
    maxMp?: true
    san?: true
    maxSan?: true
    mov?: true
    build?: true
    skills?: true
  }

  export type CharacterCountAggregateInputType = {
    id?: true
    name?: true
    occupation?: true
    age?: true
    gender?: true
    birthplace?: true
    residence?: true
    createdAt?: true
    updatedAt?: true
    str?: true
    con?: true
    pow?: true
    dex?: true
    app?: true
    siz?: true
    int?: true
    edu?: true
    luck?: true
    hp?: true
    maxHp?: true
    mp?: true
    maxMp?: true
    san?: true
    maxSan?: true
    mov?: true
    build?: true
    skills?: true
    _all?: true
  }

  export type CharacterAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Character to aggregate.
     */
    where?: CharacterWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Characters to fetch.
     */
    orderBy?: CharacterOrderByWithRelationInput | CharacterOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CharacterWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Characters from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Characters.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Characters
    **/
    _count?: true | CharacterCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CharacterAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CharacterSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CharacterMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CharacterMaxAggregateInputType
  }

  export type GetCharacterAggregateType<T extends CharacterAggregateArgs> = {
        [P in keyof T & keyof AggregateCharacter]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCharacter[P]>
      : GetScalarType<T[P], AggregateCharacter[P]>
  }




  export type CharacterGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CharacterWhereInput
    orderBy?: CharacterOrderByWithAggregationInput | CharacterOrderByWithAggregationInput[]
    by: CharacterScalarFieldEnum[] | CharacterScalarFieldEnum
    having?: CharacterScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CharacterCountAggregateInputType | true
    _avg?: CharacterAvgAggregateInputType
    _sum?: CharacterSumAggregateInputType
    _min?: CharacterMinAggregateInputType
    _max?: CharacterMaxAggregateInputType
  }

  export type CharacterGroupByOutputType = {
    id: string
    name: string
    occupation: string | null
    age: number | null
    gender: string | null
    birthplace: string | null
    residence: string | null
    createdAt: Date
    updatedAt: Date
    str: number
    con: number
    pow: number
    dex: number
    app: number
    siz: number
    int: number
    edu: number
    luck: number
    hp: number
    maxHp: number
    mp: number
    maxMp: number
    san: number
    maxSan: number
    mov: number
    build: number
    skills: string
    _count: CharacterCountAggregateOutputType | null
    _avg: CharacterAvgAggregateOutputType | null
    _sum: CharacterSumAggregateOutputType | null
    _min: CharacterMinAggregateOutputType | null
    _max: CharacterMaxAggregateOutputType | null
  }

  type GetCharacterGroupByPayload<T extends CharacterGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CharacterGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CharacterGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CharacterGroupByOutputType[P]>
            : GetScalarType<T[P], CharacterGroupByOutputType[P]>
        }
      >
    >


  export type CharacterSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    occupation?: boolean
    age?: boolean
    gender?: boolean
    birthplace?: boolean
    residence?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    str?: boolean
    con?: boolean
    pow?: boolean
    dex?: boolean
    app?: boolean
    siz?: boolean
    int?: boolean
    edu?: boolean
    luck?: boolean
    hp?: boolean
    maxHp?: boolean
    mp?: boolean
    maxMp?: boolean
    san?: boolean
    maxSan?: boolean
    mov?: boolean
    build?: boolean
    skills?: boolean
    sessions?: boolean | Character$sessionsArgs<ExtArgs>
    skillHistories?: boolean | Character$skillHistoriesArgs<ExtArgs>
    sanityHistories?: boolean | Character$sanityHistoriesArgs<ExtArgs>
    insanitySymptoms?: boolean | Character$insanitySymptomsArgs<ExtArgs>
    images?: boolean | Character$imagesArgs<ExtArgs>
    _count?: boolean | CharacterCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["character"]>

  export type CharacterSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    occupation?: boolean
    age?: boolean
    gender?: boolean
    birthplace?: boolean
    residence?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    str?: boolean
    con?: boolean
    pow?: boolean
    dex?: boolean
    app?: boolean
    siz?: boolean
    int?: boolean
    edu?: boolean
    luck?: boolean
    hp?: boolean
    maxHp?: boolean
    mp?: boolean
    maxMp?: boolean
    san?: boolean
    maxSan?: boolean
    mov?: boolean
    build?: boolean
    skills?: boolean
  }, ExtArgs["result"]["character"]>

  export type CharacterSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    occupation?: boolean
    age?: boolean
    gender?: boolean
    birthplace?: boolean
    residence?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    str?: boolean
    con?: boolean
    pow?: boolean
    dex?: boolean
    app?: boolean
    siz?: boolean
    int?: boolean
    edu?: boolean
    luck?: boolean
    hp?: boolean
    maxHp?: boolean
    mp?: boolean
    maxMp?: boolean
    san?: boolean
    maxSan?: boolean
    mov?: boolean
    build?: boolean
    skills?: boolean
  }, ExtArgs["result"]["character"]>

  export type CharacterSelectScalar = {
    id?: boolean
    name?: boolean
    occupation?: boolean
    age?: boolean
    gender?: boolean
    birthplace?: boolean
    residence?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    str?: boolean
    con?: boolean
    pow?: boolean
    dex?: boolean
    app?: boolean
    siz?: boolean
    int?: boolean
    edu?: boolean
    luck?: boolean
    hp?: boolean
    maxHp?: boolean
    mp?: boolean
    maxMp?: boolean
    san?: boolean
    maxSan?: boolean
    mov?: boolean
    build?: boolean
    skills?: boolean
  }

  export type CharacterOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "occupation" | "age" | "gender" | "birthplace" | "residence" | "createdAt" | "updatedAt" | "str" | "con" | "pow" | "dex" | "app" | "siz" | "int" | "edu" | "luck" | "hp" | "maxHp" | "mp" | "maxMp" | "san" | "maxSan" | "mov" | "build" | "skills", ExtArgs["result"]["character"]>
  export type CharacterInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    sessions?: boolean | Character$sessionsArgs<ExtArgs>
    skillHistories?: boolean | Character$skillHistoriesArgs<ExtArgs>
    sanityHistories?: boolean | Character$sanityHistoriesArgs<ExtArgs>
    insanitySymptoms?: boolean | Character$insanitySymptomsArgs<ExtArgs>
    images?: boolean | Character$imagesArgs<ExtArgs>
    _count?: boolean | CharacterCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type CharacterIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type CharacterIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $CharacterPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Character"
    objects: {
      sessions: Prisma.$SessionPayload<ExtArgs>[]
      skillHistories: Prisma.$SkillHistoryPayload<ExtArgs>[]
      sanityHistories: Prisma.$SanityHistoryPayload<ExtArgs>[]
      insanitySymptoms: Prisma.$InsanitySymptomPayload<ExtArgs>[]
      images: Prisma.$CharacterImagePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      occupation: string | null
      age: number | null
      gender: string | null
      birthplace: string | null
      residence: string | null
      createdAt: Date
      updatedAt: Date
      str: number
      con: number
      pow: number
      dex: number
      app: number
      siz: number
      int: number
      edu: number
      luck: number
      hp: number
      maxHp: number
      mp: number
      maxMp: number
      san: number
      maxSan: number
      mov: number
      build: number
      skills: string
    }, ExtArgs["result"]["character"]>
    composites: {}
  }

  type CharacterGetPayload<S extends boolean | null | undefined | CharacterDefaultArgs> = $Result.GetResult<Prisma.$CharacterPayload, S>

  type CharacterCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CharacterFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CharacterCountAggregateInputType | true
    }

  export interface CharacterDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Character'], meta: { name: 'Character' } }
    /**
     * Find zero or one Character that matches the filter.
     * @param {CharacterFindUniqueArgs} args - Arguments to find a Character
     * @example
     * // Get one Character
     * const character = await prisma.character.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CharacterFindUniqueArgs>(args: SelectSubset<T, CharacterFindUniqueArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Character that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CharacterFindUniqueOrThrowArgs} args - Arguments to find a Character
     * @example
     * // Get one Character
     * const character = await prisma.character.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CharacterFindUniqueOrThrowArgs>(args: SelectSubset<T, CharacterFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Character that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterFindFirstArgs} args - Arguments to find a Character
     * @example
     * // Get one Character
     * const character = await prisma.character.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CharacterFindFirstArgs>(args?: SelectSubset<T, CharacterFindFirstArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Character that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterFindFirstOrThrowArgs} args - Arguments to find a Character
     * @example
     * // Get one Character
     * const character = await prisma.character.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CharacterFindFirstOrThrowArgs>(args?: SelectSubset<T, CharacterFindFirstOrThrowArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Characters that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Characters
     * const characters = await prisma.character.findMany()
     * 
     * // Get first 10 Characters
     * const characters = await prisma.character.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const characterWithIdOnly = await prisma.character.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CharacterFindManyArgs>(args?: SelectSubset<T, CharacterFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Character.
     * @param {CharacterCreateArgs} args - Arguments to create a Character.
     * @example
     * // Create one Character
     * const Character = await prisma.character.create({
     *   data: {
     *     // ... data to create a Character
     *   }
     * })
     * 
     */
    create<T extends CharacterCreateArgs>(args: SelectSubset<T, CharacterCreateArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Characters.
     * @param {CharacterCreateManyArgs} args - Arguments to create many Characters.
     * @example
     * // Create many Characters
     * const character = await prisma.character.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CharacterCreateManyArgs>(args?: SelectSubset<T, CharacterCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Characters and returns the data saved in the database.
     * @param {CharacterCreateManyAndReturnArgs} args - Arguments to create many Characters.
     * @example
     * // Create many Characters
     * const character = await prisma.character.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Characters and only return the `id`
     * const characterWithIdOnly = await prisma.character.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CharacterCreateManyAndReturnArgs>(args?: SelectSubset<T, CharacterCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Character.
     * @param {CharacterDeleteArgs} args - Arguments to delete one Character.
     * @example
     * // Delete one Character
     * const Character = await prisma.character.delete({
     *   where: {
     *     // ... filter to delete one Character
     *   }
     * })
     * 
     */
    delete<T extends CharacterDeleteArgs>(args: SelectSubset<T, CharacterDeleteArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Character.
     * @param {CharacterUpdateArgs} args - Arguments to update one Character.
     * @example
     * // Update one Character
     * const character = await prisma.character.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CharacterUpdateArgs>(args: SelectSubset<T, CharacterUpdateArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Characters.
     * @param {CharacterDeleteManyArgs} args - Arguments to filter Characters to delete.
     * @example
     * // Delete a few Characters
     * const { count } = await prisma.character.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CharacterDeleteManyArgs>(args?: SelectSubset<T, CharacterDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Characters.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Characters
     * const character = await prisma.character.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CharacterUpdateManyArgs>(args: SelectSubset<T, CharacterUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Characters and returns the data updated in the database.
     * @param {CharacterUpdateManyAndReturnArgs} args - Arguments to update many Characters.
     * @example
     * // Update many Characters
     * const character = await prisma.character.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Characters and only return the `id`
     * const characterWithIdOnly = await prisma.character.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CharacterUpdateManyAndReturnArgs>(args: SelectSubset<T, CharacterUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Character.
     * @param {CharacterUpsertArgs} args - Arguments to update or create a Character.
     * @example
     * // Update or create a Character
     * const character = await prisma.character.upsert({
     *   create: {
     *     // ... data to create a Character
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Character we want to update
     *   }
     * })
     */
    upsert<T extends CharacterUpsertArgs>(args: SelectSubset<T, CharacterUpsertArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Characters.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterCountArgs} args - Arguments to filter Characters to count.
     * @example
     * // Count the number of Characters
     * const count = await prisma.character.count({
     *   where: {
     *     // ... the filter for the Characters we want to count
     *   }
     * })
    **/
    count<T extends CharacterCountArgs>(
      args?: Subset<T, CharacterCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CharacterCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Character.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CharacterAggregateArgs>(args: Subset<T, CharacterAggregateArgs>): Prisma.PrismaPromise<GetCharacterAggregateType<T>>

    /**
     * Group by Character.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CharacterGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CharacterGroupByArgs['orderBy'] }
        : { orderBy?: CharacterGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CharacterGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCharacterGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Character model
   */
  readonly fields: CharacterFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Character.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CharacterClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    sessions<T extends Character$sessionsArgs<ExtArgs> = {}>(args?: Subset<T, Character$sessionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    skillHistories<T extends Character$skillHistoriesArgs<ExtArgs> = {}>(args?: Subset<T, Character$skillHistoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    sanityHistories<T extends Character$sanityHistoriesArgs<ExtArgs> = {}>(args?: Subset<T, Character$sanityHistoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    insanitySymptoms<T extends Character$insanitySymptomsArgs<ExtArgs> = {}>(args?: Subset<T, Character$insanitySymptomsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    images<T extends Character$imagesArgs<ExtArgs> = {}>(args?: Subset<T, Character$imagesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Character model
   */
  interface CharacterFieldRefs {
    readonly id: FieldRef<"Character", 'String'>
    readonly name: FieldRef<"Character", 'String'>
    readonly occupation: FieldRef<"Character", 'String'>
    readonly age: FieldRef<"Character", 'Int'>
    readonly gender: FieldRef<"Character", 'String'>
    readonly birthplace: FieldRef<"Character", 'String'>
    readonly residence: FieldRef<"Character", 'String'>
    readonly createdAt: FieldRef<"Character", 'DateTime'>
    readonly updatedAt: FieldRef<"Character", 'DateTime'>
    readonly str: FieldRef<"Character", 'Int'>
    readonly con: FieldRef<"Character", 'Int'>
    readonly pow: FieldRef<"Character", 'Int'>
    readonly dex: FieldRef<"Character", 'Int'>
    readonly app: FieldRef<"Character", 'Int'>
    readonly siz: FieldRef<"Character", 'Int'>
    readonly int: FieldRef<"Character", 'Int'>
    readonly edu: FieldRef<"Character", 'Int'>
    readonly luck: FieldRef<"Character", 'Int'>
    readonly hp: FieldRef<"Character", 'Int'>
    readonly maxHp: FieldRef<"Character", 'Int'>
    readonly mp: FieldRef<"Character", 'Int'>
    readonly maxMp: FieldRef<"Character", 'Int'>
    readonly san: FieldRef<"Character", 'Int'>
    readonly maxSan: FieldRef<"Character", 'Int'>
    readonly mov: FieldRef<"Character", 'Int'>
    readonly build: FieldRef<"Character", 'Int'>
    readonly skills: FieldRef<"Character", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Character findUnique
   */
  export type CharacterFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * Filter, which Character to fetch.
     */
    where: CharacterWhereUniqueInput
  }

  /**
   * Character findUniqueOrThrow
   */
  export type CharacterFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * Filter, which Character to fetch.
     */
    where: CharacterWhereUniqueInput
  }

  /**
   * Character findFirst
   */
  export type CharacterFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * Filter, which Character to fetch.
     */
    where?: CharacterWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Characters to fetch.
     */
    orderBy?: CharacterOrderByWithRelationInput | CharacterOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Characters.
     */
    cursor?: CharacterWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Characters from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Characters.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Characters.
     */
    distinct?: CharacterScalarFieldEnum | CharacterScalarFieldEnum[]
  }

  /**
   * Character findFirstOrThrow
   */
  export type CharacterFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * Filter, which Character to fetch.
     */
    where?: CharacterWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Characters to fetch.
     */
    orderBy?: CharacterOrderByWithRelationInput | CharacterOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Characters.
     */
    cursor?: CharacterWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Characters from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Characters.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Characters.
     */
    distinct?: CharacterScalarFieldEnum | CharacterScalarFieldEnum[]
  }

  /**
   * Character findMany
   */
  export type CharacterFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * Filter, which Characters to fetch.
     */
    where?: CharacterWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Characters to fetch.
     */
    orderBy?: CharacterOrderByWithRelationInput | CharacterOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Characters.
     */
    cursor?: CharacterWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Characters from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Characters.
     */
    skip?: number
    distinct?: CharacterScalarFieldEnum | CharacterScalarFieldEnum[]
  }

  /**
   * Character create
   */
  export type CharacterCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * The data needed to create a Character.
     */
    data: XOR<CharacterCreateInput, CharacterUncheckedCreateInput>
  }

  /**
   * Character createMany
   */
  export type CharacterCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Characters.
     */
    data: CharacterCreateManyInput | CharacterCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Character createManyAndReturn
   */
  export type CharacterCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * The data used to create many Characters.
     */
    data: CharacterCreateManyInput | CharacterCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Character update
   */
  export type CharacterUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * The data needed to update a Character.
     */
    data: XOR<CharacterUpdateInput, CharacterUncheckedUpdateInput>
    /**
     * Choose, which Character to update.
     */
    where: CharacterWhereUniqueInput
  }

  /**
   * Character updateMany
   */
  export type CharacterUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Characters.
     */
    data: XOR<CharacterUpdateManyMutationInput, CharacterUncheckedUpdateManyInput>
    /**
     * Filter which Characters to update
     */
    where?: CharacterWhereInput
    /**
     * Limit how many Characters to update.
     */
    limit?: number
  }

  /**
   * Character updateManyAndReturn
   */
  export type CharacterUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * The data used to update Characters.
     */
    data: XOR<CharacterUpdateManyMutationInput, CharacterUncheckedUpdateManyInput>
    /**
     * Filter which Characters to update
     */
    where?: CharacterWhereInput
    /**
     * Limit how many Characters to update.
     */
    limit?: number
  }

  /**
   * Character upsert
   */
  export type CharacterUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * The filter to search for the Character to update in case it exists.
     */
    where: CharacterWhereUniqueInput
    /**
     * In case the Character found by the `where` argument doesn't exist, create a new Character with this data.
     */
    create: XOR<CharacterCreateInput, CharacterUncheckedCreateInput>
    /**
     * In case the Character was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CharacterUpdateInput, CharacterUncheckedUpdateInput>
  }

  /**
   * Character delete
   */
  export type CharacterDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
    /**
     * Filter which Character to delete.
     */
    where: CharacterWhereUniqueInput
  }

  /**
   * Character deleteMany
   */
  export type CharacterDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Characters to delete
     */
    where?: CharacterWhereInput
    /**
     * Limit how many Characters to delete.
     */
    limit?: number
  }

  /**
   * Character.sessions
   */
  export type Character$sessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    where?: SessionWhereInput
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    cursor?: SessionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Character.skillHistories
   */
  export type Character$skillHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    where?: SkillHistoryWhereInput
    orderBy?: SkillHistoryOrderByWithRelationInput | SkillHistoryOrderByWithRelationInput[]
    cursor?: SkillHistoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SkillHistoryScalarFieldEnum | SkillHistoryScalarFieldEnum[]
  }

  /**
   * Character.sanityHistories
   */
  export type Character$sanityHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    where?: SanityHistoryWhereInput
    orderBy?: SanityHistoryOrderByWithRelationInput | SanityHistoryOrderByWithRelationInput[]
    cursor?: SanityHistoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SanityHistoryScalarFieldEnum | SanityHistoryScalarFieldEnum[]
  }

  /**
   * Character.insanitySymptoms
   */
  export type Character$insanitySymptomsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    where?: InsanitySymptomWhereInput
    orderBy?: InsanitySymptomOrderByWithRelationInput | InsanitySymptomOrderByWithRelationInput[]
    cursor?: InsanitySymptomWhereUniqueInput
    take?: number
    skip?: number
    distinct?: InsanitySymptomScalarFieldEnum | InsanitySymptomScalarFieldEnum[]
  }

  /**
   * Character.images
   */
  export type Character$imagesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    where?: CharacterImageWhereInput
    orderBy?: CharacterImageOrderByWithRelationInput | CharacterImageOrderByWithRelationInput[]
    cursor?: CharacterImageWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CharacterImageScalarFieldEnum | CharacterImageScalarFieldEnum[]
  }

  /**
   * Character without action
   */
  export type CharacterDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Character
     */
    select?: CharacterSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Character
     */
    omit?: CharacterOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterInclude<ExtArgs> | null
  }


  /**
   * Model Scenario
   */

  export type AggregateScenario = {
    _count: ScenarioCountAggregateOutputType | null
    _min: ScenarioMinAggregateOutputType | null
    _max: ScenarioMaxAggregateOutputType | null
  }

  export type ScenarioMinAggregateOutputType = {
    id: string | null
    title: string | null
    author: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ScenarioMaxAggregateOutputType = {
    id: string | null
    title: string | null
    author: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ScenarioCountAggregateOutputType = {
    id: number
    title: number
    author: number
    description: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type ScenarioMinAggregateInputType = {
    id?: true
    title?: true
    author?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ScenarioMaxAggregateInputType = {
    id?: true
    title?: true
    author?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ScenarioCountAggregateInputType = {
    id?: true
    title?: true
    author?: true
    description?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type ScenarioAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Scenario to aggregate.
     */
    where?: ScenarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Scenarios to fetch.
     */
    orderBy?: ScenarioOrderByWithRelationInput | ScenarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ScenarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Scenarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Scenarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Scenarios
    **/
    _count?: true | ScenarioCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ScenarioMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ScenarioMaxAggregateInputType
  }

  export type GetScenarioAggregateType<T extends ScenarioAggregateArgs> = {
        [P in keyof T & keyof AggregateScenario]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateScenario[P]>
      : GetScalarType<T[P], AggregateScenario[P]>
  }




  export type ScenarioGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ScenarioWhereInput
    orderBy?: ScenarioOrderByWithAggregationInput | ScenarioOrderByWithAggregationInput[]
    by: ScenarioScalarFieldEnum[] | ScenarioScalarFieldEnum
    having?: ScenarioScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ScenarioCountAggregateInputType | true
    _min?: ScenarioMinAggregateInputType
    _max?: ScenarioMaxAggregateInputType
  }

  export type ScenarioGroupByOutputType = {
    id: string
    title: string
    author: string | null
    description: string | null
    createdAt: Date
    updatedAt: Date
    _count: ScenarioCountAggregateOutputType | null
    _min: ScenarioMinAggregateOutputType | null
    _max: ScenarioMaxAggregateOutputType | null
  }

  type GetScenarioGroupByPayload<T extends ScenarioGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ScenarioGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ScenarioGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ScenarioGroupByOutputType[P]>
            : GetScalarType<T[P], ScenarioGroupByOutputType[P]>
        }
      >
    >


  export type ScenarioSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    author?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    sessions?: boolean | Scenario$sessionsArgs<ExtArgs>
    _count?: boolean | ScenarioCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["scenario"]>

  export type ScenarioSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    author?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["scenario"]>

  export type ScenarioSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    author?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["scenario"]>

  export type ScenarioSelectScalar = {
    id?: boolean
    title?: boolean
    author?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type ScenarioOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "title" | "author" | "description" | "createdAt" | "updatedAt", ExtArgs["result"]["scenario"]>
  export type ScenarioInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    sessions?: boolean | Scenario$sessionsArgs<ExtArgs>
    _count?: boolean | ScenarioCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type ScenarioIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type ScenarioIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $ScenarioPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Scenario"
    objects: {
      sessions: Prisma.$SessionPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      title: string
      author: string | null
      description: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["scenario"]>
    composites: {}
  }

  type ScenarioGetPayload<S extends boolean | null | undefined | ScenarioDefaultArgs> = $Result.GetResult<Prisma.$ScenarioPayload, S>

  type ScenarioCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ScenarioFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ScenarioCountAggregateInputType | true
    }

  export interface ScenarioDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Scenario'], meta: { name: 'Scenario' } }
    /**
     * Find zero or one Scenario that matches the filter.
     * @param {ScenarioFindUniqueArgs} args - Arguments to find a Scenario
     * @example
     * // Get one Scenario
     * const scenario = await prisma.scenario.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ScenarioFindUniqueArgs>(args: SelectSubset<T, ScenarioFindUniqueArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Scenario that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ScenarioFindUniqueOrThrowArgs} args - Arguments to find a Scenario
     * @example
     * // Get one Scenario
     * const scenario = await prisma.scenario.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ScenarioFindUniqueOrThrowArgs>(args: SelectSubset<T, ScenarioFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Scenario that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ScenarioFindFirstArgs} args - Arguments to find a Scenario
     * @example
     * // Get one Scenario
     * const scenario = await prisma.scenario.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ScenarioFindFirstArgs>(args?: SelectSubset<T, ScenarioFindFirstArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Scenario that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ScenarioFindFirstOrThrowArgs} args - Arguments to find a Scenario
     * @example
     * // Get one Scenario
     * const scenario = await prisma.scenario.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ScenarioFindFirstOrThrowArgs>(args?: SelectSubset<T, ScenarioFindFirstOrThrowArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Scenarios that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ScenarioFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Scenarios
     * const scenarios = await prisma.scenario.findMany()
     * 
     * // Get first 10 Scenarios
     * const scenarios = await prisma.scenario.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const scenarioWithIdOnly = await prisma.scenario.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ScenarioFindManyArgs>(args?: SelectSubset<T, ScenarioFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Scenario.
     * @param {ScenarioCreateArgs} args - Arguments to create a Scenario.
     * @example
     * // Create one Scenario
     * const Scenario = await prisma.scenario.create({
     *   data: {
     *     // ... data to create a Scenario
     *   }
     * })
     * 
     */
    create<T extends ScenarioCreateArgs>(args: SelectSubset<T, ScenarioCreateArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Scenarios.
     * @param {ScenarioCreateManyArgs} args - Arguments to create many Scenarios.
     * @example
     * // Create many Scenarios
     * const scenario = await prisma.scenario.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ScenarioCreateManyArgs>(args?: SelectSubset<T, ScenarioCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Scenarios and returns the data saved in the database.
     * @param {ScenarioCreateManyAndReturnArgs} args - Arguments to create many Scenarios.
     * @example
     * // Create many Scenarios
     * const scenario = await prisma.scenario.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Scenarios and only return the `id`
     * const scenarioWithIdOnly = await prisma.scenario.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ScenarioCreateManyAndReturnArgs>(args?: SelectSubset<T, ScenarioCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Scenario.
     * @param {ScenarioDeleteArgs} args - Arguments to delete one Scenario.
     * @example
     * // Delete one Scenario
     * const Scenario = await prisma.scenario.delete({
     *   where: {
     *     // ... filter to delete one Scenario
     *   }
     * })
     * 
     */
    delete<T extends ScenarioDeleteArgs>(args: SelectSubset<T, ScenarioDeleteArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Scenario.
     * @param {ScenarioUpdateArgs} args - Arguments to update one Scenario.
     * @example
     * // Update one Scenario
     * const scenario = await prisma.scenario.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ScenarioUpdateArgs>(args: SelectSubset<T, ScenarioUpdateArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Scenarios.
     * @param {ScenarioDeleteManyArgs} args - Arguments to filter Scenarios to delete.
     * @example
     * // Delete a few Scenarios
     * const { count } = await prisma.scenario.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ScenarioDeleteManyArgs>(args?: SelectSubset<T, ScenarioDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Scenarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ScenarioUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Scenarios
     * const scenario = await prisma.scenario.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ScenarioUpdateManyArgs>(args: SelectSubset<T, ScenarioUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Scenarios and returns the data updated in the database.
     * @param {ScenarioUpdateManyAndReturnArgs} args - Arguments to update many Scenarios.
     * @example
     * // Update many Scenarios
     * const scenario = await prisma.scenario.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Scenarios and only return the `id`
     * const scenarioWithIdOnly = await prisma.scenario.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ScenarioUpdateManyAndReturnArgs>(args: SelectSubset<T, ScenarioUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Scenario.
     * @param {ScenarioUpsertArgs} args - Arguments to update or create a Scenario.
     * @example
     * // Update or create a Scenario
     * const scenario = await prisma.scenario.upsert({
     *   create: {
     *     // ... data to create a Scenario
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Scenario we want to update
     *   }
     * })
     */
    upsert<T extends ScenarioUpsertArgs>(args: SelectSubset<T, ScenarioUpsertArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Scenarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ScenarioCountArgs} args - Arguments to filter Scenarios to count.
     * @example
     * // Count the number of Scenarios
     * const count = await prisma.scenario.count({
     *   where: {
     *     // ... the filter for the Scenarios we want to count
     *   }
     * })
    **/
    count<T extends ScenarioCountArgs>(
      args?: Subset<T, ScenarioCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ScenarioCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Scenario.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ScenarioAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ScenarioAggregateArgs>(args: Subset<T, ScenarioAggregateArgs>): Prisma.PrismaPromise<GetScenarioAggregateType<T>>

    /**
     * Group by Scenario.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ScenarioGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ScenarioGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ScenarioGroupByArgs['orderBy'] }
        : { orderBy?: ScenarioGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ScenarioGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetScenarioGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Scenario model
   */
  readonly fields: ScenarioFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Scenario.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ScenarioClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    sessions<T extends Scenario$sessionsArgs<ExtArgs> = {}>(args?: Subset<T, Scenario$sessionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Scenario model
   */
  interface ScenarioFieldRefs {
    readonly id: FieldRef<"Scenario", 'String'>
    readonly title: FieldRef<"Scenario", 'String'>
    readonly author: FieldRef<"Scenario", 'String'>
    readonly description: FieldRef<"Scenario", 'String'>
    readonly createdAt: FieldRef<"Scenario", 'DateTime'>
    readonly updatedAt: FieldRef<"Scenario", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Scenario findUnique
   */
  export type ScenarioFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * Filter, which Scenario to fetch.
     */
    where: ScenarioWhereUniqueInput
  }

  /**
   * Scenario findUniqueOrThrow
   */
  export type ScenarioFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * Filter, which Scenario to fetch.
     */
    where: ScenarioWhereUniqueInput
  }

  /**
   * Scenario findFirst
   */
  export type ScenarioFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * Filter, which Scenario to fetch.
     */
    where?: ScenarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Scenarios to fetch.
     */
    orderBy?: ScenarioOrderByWithRelationInput | ScenarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Scenarios.
     */
    cursor?: ScenarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Scenarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Scenarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Scenarios.
     */
    distinct?: ScenarioScalarFieldEnum | ScenarioScalarFieldEnum[]
  }

  /**
   * Scenario findFirstOrThrow
   */
  export type ScenarioFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * Filter, which Scenario to fetch.
     */
    where?: ScenarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Scenarios to fetch.
     */
    orderBy?: ScenarioOrderByWithRelationInput | ScenarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Scenarios.
     */
    cursor?: ScenarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Scenarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Scenarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Scenarios.
     */
    distinct?: ScenarioScalarFieldEnum | ScenarioScalarFieldEnum[]
  }

  /**
   * Scenario findMany
   */
  export type ScenarioFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * Filter, which Scenarios to fetch.
     */
    where?: ScenarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Scenarios to fetch.
     */
    orderBy?: ScenarioOrderByWithRelationInput | ScenarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Scenarios.
     */
    cursor?: ScenarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Scenarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Scenarios.
     */
    skip?: number
    distinct?: ScenarioScalarFieldEnum | ScenarioScalarFieldEnum[]
  }

  /**
   * Scenario create
   */
  export type ScenarioCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * The data needed to create a Scenario.
     */
    data: XOR<ScenarioCreateInput, ScenarioUncheckedCreateInput>
  }

  /**
   * Scenario createMany
   */
  export type ScenarioCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Scenarios.
     */
    data: ScenarioCreateManyInput | ScenarioCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Scenario createManyAndReturn
   */
  export type ScenarioCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * The data used to create many Scenarios.
     */
    data: ScenarioCreateManyInput | ScenarioCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Scenario update
   */
  export type ScenarioUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * The data needed to update a Scenario.
     */
    data: XOR<ScenarioUpdateInput, ScenarioUncheckedUpdateInput>
    /**
     * Choose, which Scenario to update.
     */
    where: ScenarioWhereUniqueInput
  }

  /**
   * Scenario updateMany
   */
  export type ScenarioUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Scenarios.
     */
    data: XOR<ScenarioUpdateManyMutationInput, ScenarioUncheckedUpdateManyInput>
    /**
     * Filter which Scenarios to update
     */
    where?: ScenarioWhereInput
    /**
     * Limit how many Scenarios to update.
     */
    limit?: number
  }

  /**
   * Scenario updateManyAndReturn
   */
  export type ScenarioUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * The data used to update Scenarios.
     */
    data: XOR<ScenarioUpdateManyMutationInput, ScenarioUncheckedUpdateManyInput>
    /**
     * Filter which Scenarios to update
     */
    where?: ScenarioWhereInput
    /**
     * Limit how many Scenarios to update.
     */
    limit?: number
  }

  /**
   * Scenario upsert
   */
  export type ScenarioUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * The filter to search for the Scenario to update in case it exists.
     */
    where: ScenarioWhereUniqueInput
    /**
     * In case the Scenario found by the `where` argument doesn't exist, create a new Scenario with this data.
     */
    create: XOR<ScenarioCreateInput, ScenarioUncheckedCreateInput>
    /**
     * In case the Scenario was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ScenarioUpdateInput, ScenarioUncheckedUpdateInput>
  }

  /**
   * Scenario delete
   */
  export type ScenarioDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
    /**
     * Filter which Scenario to delete.
     */
    where: ScenarioWhereUniqueInput
  }

  /**
   * Scenario deleteMany
   */
  export type ScenarioDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Scenarios to delete
     */
    where?: ScenarioWhereInput
    /**
     * Limit how many Scenarios to delete.
     */
    limit?: number
  }

  /**
   * Scenario.sessions
   */
  export type Scenario$sessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    where?: SessionWhereInput
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    cursor?: SessionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Scenario without action
   */
  export type ScenarioDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Scenario
     */
    select?: ScenarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Scenario
     */
    omit?: ScenarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ScenarioInclude<ExtArgs> | null
  }


  /**
   * Model Session
   */

  export type AggregateSession = {
    _count: SessionCountAggregateOutputType | null
    _min: SessionMinAggregateOutputType | null
    _max: SessionMaxAggregateOutputType | null
  }

  export type SessionMinAggregateOutputType = {
    id: string | null
    characterId: string | null
    scenarioId: string | null
    kpName: string | null
    playDate: Date | null
    memo: string | null
    participants: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SessionMaxAggregateOutputType = {
    id: string | null
    characterId: string | null
    scenarioId: string | null
    kpName: string | null
    playDate: Date | null
    memo: string | null
    participants: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SessionCountAggregateOutputType = {
    id: number
    characterId: number
    scenarioId: number
    kpName: number
    playDate: number
    memo: number
    participants: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SessionMinAggregateInputType = {
    id?: true
    characterId?: true
    scenarioId?: true
    kpName?: true
    playDate?: true
    memo?: true
    participants?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SessionMaxAggregateInputType = {
    id?: true
    characterId?: true
    scenarioId?: true
    kpName?: true
    playDate?: true
    memo?: true
    participants?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SessionCountAggregateInputType = {
    id?: true
    characterId?: true
    scenarioId?: true
    kpName?: true
    playDate?: true
    memo?: true
    participants?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SessionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Session to aggregate.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Sessions
    **/
    _count?: true | SessionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SessionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SessionMaxAggregateInputType
  }

  export type GetSessionAggregateType<T extends SessionAggregateArgs> = {
        [P in keyof T & keyof AggregateSession]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSession[P]>
      : GetScalarType<T[P], AggregateSession[P]>
  }




  export type SessionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SessionWhereInput
    orderBy?: SessionOrderByWithAggregationInput | SessionOrderByWithAggregationInput[]
    by: SessionScalarFieldEnum[] | SessionScalarFieldEnum
    having?: SessionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SessionCountAggregateInputType | true
    _min?: SessionMinAggregateInputType
    _max?: SessionMaxAggregateInputType
  }

  export type SessionGroupByOutputType = {
    id: string
    characterId: string
    scenarioId: string
    kpName: string | null
    playDate: Date
    memo: string | null
    participants: string | null
    createdAt: Date
    updatedAt: Date
    _count: SessionCountAggregateOutputType | null
    _min: SessionMinAggregateOutputType | null
    _max: SessionMaxAggregateOutputType | null
  }

  type GetSessionGroupByPayload<T extends SessionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SessionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SessionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SessionGroupByOutputType[P]>
            : GetScalarType<T[P], SessionGroupByOutputType[P]>
        }
      >
    >


  export type SessionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    scenarioId?: boolean
    kpName?: boolean
    playDate?: boolean
    memo?: boolean
    participants?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    scenario?: boolean | ScenarioDefaultArgs<ExtArgs>
    skillHistories?: boolean | Session$skillHistoriesArgs<ExtArgs>
    sanityHistories?: boolean | Session$sanityHistoriesArgs<ExtArgs>
    insanitySymptoms?: boolean | Session$insanitySymptomsArgs<ExtArgs>
    _count?: boolean | SessionCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["session"]>

  export type SessionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    scenarioId?: boolean
    kpName?: boolean
    playDate?: boolean
    memo?: boolean
    participants?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    scenario?: boolean | ScenarioDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["session"]>

  export type SessionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    scenarioId?: boolean
    kpName?: boolean
    playDate?: boolean
    memo?: boolean
    participants?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    scenario?: boolean | ScenarioDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["session"]>

  export type SessionSelectScalar = {
    id?: boolean
    characterId?: boolean
    scenarioId?: boolean
    kpName?: boolean
    playDate?: boolean
    memo?: boolean
    participants?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SessionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "characterId" | "scenarioId" | "kpName" | "playDate" | "memo" | "participants" | "createdAt" | "updatedAt", ExtArgs["result"]["session"]>
  export type SessionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    scenario?: boolean | ScenarioDefaultArgs<ExtArgs>
    skillHistories?: boolean | Session$skillHistoriesArgs<ExtArgs>
    sanityHistories?: boolean | Session$sanityHistoriesArgs<ExtArgs>
    insanitySymptoms?: boolean | Session$insanitySymptomsArgs<ExtArgs>
    _count?: boolean | SessionCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type SessionIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    scenario?: boolean | ScenarioDefaultArgs<ExtArgs>
  }
  export type SessionIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    scenario?: boolean | ScenarioDefaultArgs<ExtArgs>
  }

  export type $SessionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Session"
    objects: {
      character: Prisma.$CharacterPayload<ExtArgs>
      scenario: Prisma.$ScenarioPayload<ExtArgs>
      skillHistories: Prisma.$SkillHistoryPayload<ExtArgs>[]
      sanityHistories: Prisma.$SanityHistoryPayload<ExtArgs>[]
      insanitySymptoms: Prisma.$InsanitySymptomPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      characterId: string
      scenarioId: string
      kpName: string | null
      playDate: Date
      memo: string | null
      participants: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["session"]>
    composites: {}
  }

  type SessionGetPayload<S extends boolean | null | undefined | SessionDefaultArgs> = $Result.GetResult<Prisma.$SessionPayload, S>

  type SessionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SessionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SessionCountAggregateInputType | true
    }

  export interface SessionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Session'], meta: { name: 'Session' } }
    /**
     * Find zero or one Session that matches the filter.
     * @param {SessionFindUniqueArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SessionFindUniqueArgs>(args: SelectSubset<T, SessionFindUniqueArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Session that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SessionFindUniqueOrThrowArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SessionFindUniqueOrThrowArgs>(args: SelectSubset<T, SessionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Session that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionFindFirstArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SessionFindFirstArgs>(args?: SelectSubset<T, SessionFindFirstArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Session that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionFindFirstOrThrowArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SessionFindFirstOrThrowArgs>(args?: SelectSubset<T, SessionFindFirstOrThrowArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Sessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Sessions
     * const sessions = await prisma.session.findMany()
     * 
     * // Get first 10 Sessions
     * const sessions = await prisma.session.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sessionWithIdOnly = await prisma.session.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SessionFindManyArgs>(args?: SelectSubset<T, SessionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Session.
     * @param {SessionCreateArgs} args - Arguments to create a Session.
     * @example
     * // Create one Session
     * const Session = await prisma.session.create({
     *   data: {
     *     // ... data to create a Session
     *   }
     * })
     * 
     */
    create<T extends SessionCreateArgs>(args: SelectSubset<T, SessionCreateArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Sessions.
     * @param {SessionCreateManyArgs} args - Arguments to create many Sessions.
     * @example
     * // Create many Sessions
     * const session = await prisma.session.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SessionCreateManyArgs>(args?: SelectSubset<T, SessionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Sessions and returns the data saved in the database.
     * @param {SessionCreateManyAndReturnArgs} args - Arguments to create many Sessions.
     * @example
     * // Create many Sessions
     * const session = await prisma.session.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Sessions and only return the `id`
     * const sessionWithIdOnly = await prisma.session.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SessionCreateManyAndReturnArgs>(args?: SelectSubset<T, SessionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Session.
     * @param {SessionDeleteArgs} args - Arguments to delete one Session.
     * @example
     * // Delete one Session
     * const Session = await prisma.session.delete({
     *   where: {
     *     // ... filter to delete one Session
     *   }
     * })
     * 
     */
    delete<T extends SessionDeleteArgs>(args: SelectSubset<T, SessionDeleteArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Session.
     * @param {SessionUpdateArgs} args - Arguments to update one Session.
     * @example
     * // Update one Session
     * const session = await prisma.session.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SessionUpdateArgs>(args: SelectSubset<T, SessionUpdateArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Sessions.
     * @param {SessionDeleteManyArgs} args - Arguments to filter Sessions to delete.
     * @example
     * // Delete a few Sessions
     * const { count } = await prisma.session.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SessionDeleteManyArgs>(args?: SelectSubset<T, SessionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Sessions
     * const session = await prisma.session.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SessionUpdateManyArgs>(args: SelectSubset<T, SessionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Sessions and returns the data updated in the database.
     * @param {SessionUpdateManyAndReturnArgs} args - Arguments to update many Sessions.
     * @example
     * // Update many Sessions
     * const session = await prisma.session.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Sessions and only return the `id`
     * const sessionWithIdOnly = await prisma.session.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SessionUpdateManyAndReturnArgs>(args: SelectSubset<T, SessionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Session.
     * @param {SessionUpsertArgs} args - Arguments to update or create a Session.
     * @example
     * // Update or create a Session
     * const session = await prisma.session.upsert({
     *   create: {
     *     // ... data to create a Session
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Session we want to update
     *   }
     * })
     */
    upsert<T extends SessionUpsertArgs>(args: SelectSubset<T, SessionUpsertArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionCountArgs} args - Arguments to filter Sessions to count.
     * @example
     * // Count the number of Sessions
     * const count = await prisma.session.count({
     *   where: {
     *     // ... the filter for the Sessions we want to count
     *   }
     * })
    **/
    count<T extends SessionCountArgs>(
      args?: Subset<T, SessionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SessionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Session.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SessionAggregateArgs>(args: Subset<T, SessionAggregateArgs>): Prisma.PrismaPromise<GetSessionAggregateType<T>>

    /**
     * Group by Session.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SessionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SessionGroupByArgs['orderBy'] }
        : { orderBy?: SessionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SessionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSessionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Session model
   */
  readonly fields: SessionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Session.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SessionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    character<T extends CharacterDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CharacterDefaultArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    scenario<T extends ScenarioDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ScenarioDefaultArgs<ExtArgs>>): Prisma__ScenarioClient<$Result.GetResult<Prisma.$ScenarioPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    skillHistories<T extends Session$skillHistoriesArgs<ExtArgs> = {}>(args?: Subset<T, Session$skillHistoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    sanityHistories<T extends Session$sanityHistoriesArgs<ExtArgs> = {}>(args?: Subset<T, Session$sanityHistoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    insanitySymptoms<T extends Session$insanitySymptomsArgs<ExtArgs> = {}>(args?: Subset<T, Session$insanitySymptomsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Session model
   */
  interface SessionFieldRefs {
    readonly id: FieldRef<"Session", 'String'>
    readonly characterId: FieldRef<"Session", 'String'>
    readonly scenarioId: FieldRef<"Session", 'String'>
    readonly kpName: FieldRef<"Session", 'String'>
    readonly playDate: FieldRef<"Session", 'DateTime'>
    readonly memo: FieldRef<"Session", 'String'>
    readonly participants: FieldRef<"Session", 'String'>
    readonly createdAt: FieldRef<"Session", 'DateTime'>
    readonly updatedAt: FieldRef<"Session", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Session findUnique
   */
  export type SessionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session findUniqueOrThrow
   */
  export type SessionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session findFirst
   */
  export type SessionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Sessions.
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Sessions.
     */
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Session findFirstOrThrow
   */
  export type SessionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Sessions.
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Sessions.
     */
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Session findMany
   */
  export type SessionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Sessions to fetch.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Sessions.
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Session create
   */
  export type SessionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * The data needed to create a Session.
     */
    data: XOR<SessionCreateInput, SessionUncheckedCreateInput>
  }

  /**
   * Session createMany
   */
  export type SessionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Sessions.
     */
    data: SessionCreateManyInput | SessionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Session createManyAndReturn
   */
  export type SessionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * The data used to create many Sessions.
     */
    data: SessionCreateManyInput | SessionCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Session update
   */
  export type SessionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * The data needed to update a Session.
     */
    data: XOR<SessionUpdateInput, SessionUncheckedUpdateInput>
    /**
     * Choose, which Session to update.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session updateMany
   */
  export type SessionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Sessions.
     */
    data: XOR<SessionUpdateManyMutationInput, SessionUncheckedUpdateManyInput>
    /**
     * Filter which Sessions to update
     */
    where?: SessionWhereInput
    /**
     * Limit how many Sessions to update.
     */
    limit?: number
  }

  /**
   * Session updateManyAndReturn
   */
  export type SessionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * The data used to update Sessions.
     */
    data: XOR<SessionUpdateManyMutationInput, SessionUncheckedUpdateManyInput>
    /**
     * Filter which Sessions to update
     */
    where?: SessionWhereInput
    /**
     * Limit how many Sessions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Session upsert
   */
  export type SessionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * The filter to search for the Session to update in case it exists.
     */
    where: SessionWhereUniqueInput
    /**
     * In case the Session found by the `where` argument doesn't exist, create a new Session with this data.
     */
    create: XOR<SessionCreateInput, SessionUncheckedCreateInput>
    /**
     * In case the Session was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SessionUpdateInput, SessionUncheckedUpdateInput>
  }

  /**
   * Session delete
   */
  export type SessionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter which Session to delete.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session deleteMany
   */
  export type SessionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Sessions to delete
     */
    where?: SessionWhereInput
    /**
     * Limit how many Sessions to delete.
     */
    limit?: number
  }

  /**
   * Session.skillHistories
   */
  export type Session$skillHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    where?: SkillHistoryWhereInput
    orderBy?: SkillHistoryOrderByWithRelationInput | SkillHistoryOrderByWithRelationInput[]
    cursor?: SkillHistoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SkillHistoryScalarFieldEnum | SkillHistoryScalarFieldEnum[]
  }

  /**
   * Session.sanityHistories
   */
  export type Session$sanityHistoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    where?: SanityHistoryWhereInput
    orderBy?: SanityHistoryOrderByWithRelationInput | SanityHistoryOrderByWithRelationInput[]
    cursor?: SanityHistoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SanityHistoryScalarFieldEnum | SanityHistoryScalarFieldEnum[]
  }

  /**
   * Session.insanitySymptoms
   */
  export type Session$insanitySymptomsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    where?: InsanitySymptomWhereInput
    orderBy?: InsanitySymptomOrderByWithRelationInput | InsanitySymptomOrderByWithRelationInput[]
    cursor?: InsanitySymptomWhereUniqueInput
    take?: number
    skip?: number
    distinct?: InsanitySymptomScalarFieldEnum | InsanitySymptomScalarFieldEnum[]
  }

  /**
   * Session without action
   */
  export type SessionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
  }


  /**
   * Model SkillHistory
   */

  export type AggregateSkillHistory = {
    _count: SkillHistoryCountAggregateOutputType | null
    _avg: SkillHistoryAvgAggregateOutputType | null
    _sum: SkillHistorySumAggregateOutputType | null
    _min: SkillHistoryMinAggregateOutputType | null
    _max: SkillHistoryMaxAggregateOutputType | null
  }

  export type SkillHistoryAvgAggregateOutputType = {
    oldValue: number | null
    newValue: number | null
  }

  export type SkillHistorySumAggregateOutputType = {
    oldValue: number | null
    newValue: number | null
  }

  export type SkillHistoryMinAggregateOutputType = {
    id: string | null
    characterId: string | null
    sessionId: string | null
    skillName: string | null
    oldValue: number | null
    newValue: number | null
    reason: string | null
    createdAt: Date | null
  }

  export type SkillHistoryMaxAggregateOutputType = {
    id: string | null
    characterId: string | null
    sessionId: string | null
    skillName: string | null
    oldValue: number | null
    newValue: number | null
    reason: string | null
    createdAt: Date | null
  }

  export type SkillHistoryCountAggregateOutputType = {
    id: number
    characterId: number
    sessionId: number
    skillName: number
    oldValue: number
    newValue: number
    reason: number
    createdAt: number
    _all: number
  }


  export type SkillHistoryAvgAggregateInputType = {
    oldValue?: true
    newValue?: true
  }

  export type SkillHistorySumAggregateInputType = {
    oldValue?: true
    newValue?: true
  }

  export type SkillHistoryMinAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    skillName?: true
    oldValue?: true
    newValue?: true
    reason?: true
    createdAt?: true
  }

  export type SkillHistoryMaxAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    skillName?: true
    oldValue?: true
    newValue?: true
    reason?: true
    createdAt?: true
  }

  export type SkillHistoryCountAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    skillName?: true
    oldValue?: true
    newValue?: true
    reason?: true
    createdAt?: true
    _all?: true
  }

  export type SkillHistoryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SkillHistory to aggregate.
     */
    where?: SkillHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SkillHistories to fetch.
     */
    orderBy?: SkillHistoryOrderByWithRelationInput | SkillHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SkillHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SkillHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SkillHistories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SkillHistories
    **/
    _count?: true | SkillHistoryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SkillHistoryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SkillHistorySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SkillHistoryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SkillHistoryMaxAggregateInputType
  }

  export type GetSkillHistoryAggregateType<T extends SkillHistoryAggregateArgs> = {
        [P in keyof T & keyof AggregateSkillHistory]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSkillHistory[P]>
      : GetScalarType<T[P], AggregateSkillHistory[P]>
  }




  export type SkillHistoryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SkillHistoryWhereInput
    orderBy?: SkillHistoryOrderByWithAggregationInput | SkillHistoryOrderByWithAggregationInput[]
    by: SkillHistoryScalarFieldEnum[] | SkillHistoryScalarFieldEnum
    having?: SkillHistoryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SkillHistoryCountAggregateInputType | true
    _avg?: SkillHistoryAvgAggregateInputType
    _sum?: SkillHistorySumAggregateInputType
    _min?: SkillHistoryMinAggregateInputType
    _max?: SkillHistoryMaxAggregateInputType
  }

  export type SkillHistoryGroupByOutputType = {
    id: string
    characterId: string
    sessionId: string | null
    skillName: string
    oldValue: number
    newValue: number
    reason: string | null
    createdAt: Date
    _count: SkillHistoryCountAggregateOutputType | null
    _avg: SkillHistoryAvgAggregateOutputType | null
    _sum: SkillHistorySumAggregateOutputType | null
    _min: SkillHistoryMinAggregateOutputType | null
    _max: SkillHistoryMaxAggregateOutputType | null
  }

  type GetSkillHistoryGroupByPayload<T extends SkillHistoryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SkillHistoryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SkillHistoryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SkillHistoryGroupByOutputType[P]>
            : GetScalarType<T[P], SkillHistoryGroupByOutputType[P]>
        }
      >
    >


  export type SkillHistorySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    skillName?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SkillHistory$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["skillHistory"]>

  export type SkillHistorySelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    skillName?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SkillHistory$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["skillHistory"]>

  export type SkillHistorySelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    skillName?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SkillHistory$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["skillHistory"]>

  export type SkillHistorySelectScalar = {
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    skillName?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
  }

  export type SkillHistoryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "characterId" | "sessionId" | "skillName" | "oldValue" | "newValue" | "reason" | "createdAt", ExtArgs["result"]["skillHistory"]>
  export type SkillHistoryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SkillHistory$sessionArgs<ExtArgs>
  }
  export type SkillHistoryIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SkillHistory$sessionArgs<ExtArgs>
  }
  export type SkillHistoryIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SkillHistory$sessionArgs<ExtArgs>
  }

  export type $SkillHistoryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SkillHistory"
    objects: {
      character: Prisma.$CharacterPayload<ExtArgs>
      session: Prisma.$SessionPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      characterId: string
      sessionId: string | null
      skillName: string
      oldValue: number
      newValue: number
      reason: string | null
      createdAt: Date
    }, ExtArgs["result"]["skillHistory"]>
    composites: {}
  }

  type SkillHistoryGetPayload<S extends boolean | null | undefined | SkillHistoryDefaultArgs> = $Result.GetResult<Prisma.$SkillHistoryPayload, S>

  type SkillHistoryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SkillHistoryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SkillHistoryCountAggregateInputType | true
    }

  export interface SkillHistoryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SkillHistory'], meta: { name: 'SkillHistory' } }
    /**
     * Find zero or one SkillHistory that matches the filter.
     * @param {SkillHistoryFindUniqueArgs} args - Arguments to find a SkillHistory
     * @example
     * // Get one SkillHistory
     * const skillHistory = await prisma.skillHistory.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SkillHistoryFindUniqueArgs>(args: SelectSubset<T, SkillHistoryFindUniqueArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SkillHistory that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SkillHistoryFindUniqueOrThrowArgs} args - Arguments to find a SkillHistory
     * @example
     * // Get one SkillHistory
     * const skillHistory = await prisma.skillHistory.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SkillHistoryFindUniqueOrThrowArgs>(args: SelectSubset<T, SkillHistoryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SkillHistory that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SkillHistoryFindFirstArgs} args - Arguments to find a SkillHistory
     * @example
     * // Get one SkillHistory
     * const skillHistory = await prisma.skillHistory.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SkillHistoryFindFirstArgs>(args?: SelectSubset<T, SkillHistoryFindFirstArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SkillHistory that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SkillHistoryFindFirstOrThrowArgs} args - Arguments to find a SkillHistory
     * @example
     * // Get one SkillHistory
     * const skillHistory = await prisma.skillHistory.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SkillHistoryFindFirstOrThrowArgs>(args?: SelectSubset<T, SkillHistoryFindFirstOrThrowArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SkillHistories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SkillHistoryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SkillHistories
     * const skillHistories = await prisma.skillHistory.findMany()
     * 
     * // Get first 10 SkillHistories
     * const skillHistories = await prisma.skillHistory.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const skillHistoryWithIdOnly = await prisma.skillHistory.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SkillHistoryFindManyArgs>(args?: SelectSubset<T, SkillHistoryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SkillHistory.
     * @param {SkillHistoryCreateArgs} args - Arguments to create a SkillHistory.
     * @example
     * // Create one SkillHistory
     * const SkillHistory = await prisma.skillHistory.create({
     *   data: {
     *     // ... data to create a SkillHistory
     *   }
     * })
     * 
     */
    create<T extends SkillHistoryCreateArgs>(args: SelectSubset<T, SkillHistoryCreateArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SkillHistories.
     * @param {SkillHistoryCreateManyArgs} args - Arguments to create many SkillHistories.
     * @example
     * // Create many SkillHistories
     * const skillHistory = await prisma.skillHistory.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SkillHistoryCreateManyArgs>(args?: SelectSubset<T, SkillHistoryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many SkillHistories and returns the data saved in the database.
     * @param {SkillHistoryCreateManyAndReturnArgs} args - Arguments to create many SkillHistories.
     * @example
     * // Create many SkillHistories
     * const skillHistory = await prisma.skillHistory.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many SkillHistories and only return the `id`
     * const skillHistoryWithIdOnly = await prisma.skillHistory.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SkillHistoryCreateManyAndReturnArgs>(args?: SelectSubset<T, SkillHistoryCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a SkillHistory.
     * @param {SkillHistoryDeleteArgs} args - Arguments to delete one SkillHistory.
     * @example
     * // Delete one SkillHistory
     * const SkillHistory = await prisma.skillHistory.delete({
     *   where: {
     *     // ... filter to delete one SkillHistory
     *   }
     * })
     * 
     */
    delete<T extends SkillHistoryDeleteArgs>(args: SelectSubset<T, SkillHistoryDeleteArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SkillHistory.
     * @param {SkillHistoryUpdateArgs} args - Arguments to update one SkillHistory.
     * @example
     * // Update one SkillHistory
     * const skillHistory = await prisma.skillHistory.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SkillHistoryUpdateArgs>(args: SelectSubset<T, SkillHistoryUpdateArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SkillHistories.
     * @param {SkillHistoryDeleteManyArgs} args - Arguments to filter SkillHistories to delete.
     * @example
     * // Delete a few SkillHistories
     * const { count } = await prisma.skillHistory.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SkillHistoryDeleteManyArgs>(args?: SelectSubset<T, SkillHistoryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SkillHistories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SkillHistoryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SkillHistories
     * const skillHistory = await prisma.skillHistory.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SkillHistoryUpdateManyArgs>(args: SelectSubset<T, SkillHistoryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SkillHistories and returns the data updated in the database.
     * @param {SkillHistoryUpdateManyAndReturnArgs} args - Arguments to update many SkillHistories.
     * @example
     * // Update many SkillHistories
     * const skillHistory = await prisma.skillHistory.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more SkillHistories and only return the `id`
     * const skillHistoryWithIdOnly = await prisma.skillHistory.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SkillHistoryUpdateManyAndReturnArgs>(args: SelectSubset<T, SkillHistoryUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one SkillHistory.
     * @param {SkillHistoryUpsertArgs} args - Arguments to update or create a SkillHistory.
     * @example
     * // Update or create a SkillHistory
     * const skillHistory = await prisma.skillHistory.upsert({
     *   create: {
     *     // ... data to create a SkillHistory
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SkillHistory we want to update
     *   }
     * })
     */
    upsert<T extends SkillHistoryUpsertArgs>(args: SelectSubset<T, SkillHistoryUpsertArgs<ExtArgs>>): Prisma__SkillHistoryClient<$Result.GetResult<Prisma.$SkillHistoryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SkillHistories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SkillHistoryCountArgs} args - Arguments to filter SkillHistories to count.
     * @example
     * // Count the number of SkillHistories
     * const count = await prisma.skillHistory.count({
     *   where: {
     *     // ... the filter for the SkillHistories we want to count
     *   }
     * })
    **/
    count<T extends SkillHistoryCountArgs>(
      args?: Subset<T, SkillHistoryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SkillHistoryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SkillHistory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SkillHistoryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SkillHistoryAggregateArgs>(args: Subset<T, SkillHistoryAggregateArgs>): Prisma.PrismaPromise<GetSkillHistoryAggregateType<T>>

    /**
     * Group by SkillHistory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SkillHistoryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SkillHistoryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SkillHistoryGroupByArgs['orderBy'] }
        : { orderBy?: SkillHistoryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SkillHistoryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSkillHistoryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SkillHistory model
   */
  readonly fields: SkillHistoryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SkillHistory.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SkillHistoryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    character<T extends CharacterDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CharacterDefaultArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    session<T extends SkillHistory$sessionArgs<ExtArgs> = {}>(args?: Subset<T, SkillHistory$sessionArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SkillHistory model
   */
  interface SkillHistoryFieldRefs {
    readonly id: FieldRef<"SkillHistory", 'String'>
    readonly characterId: FieldRef<"SkillHistory", 'String'>
    readonly sessionId: FieldRef<"SkillHistory", 'String'>
    readonly skillName: FieldRef<"SkillHistory", 'String'>
    readonly oldValue: FieldRef<"SkillHistory", 'Int'>
    readonly newValue: FieldRef<"SkillHistory", 'Int'>
    readonly reason: FieldRef<"SkillHistory", 'String'>
    readonly createdAt: FieldRef<"SkillHistory", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SkillHistory findUnique
   */
  export type SkillHistoryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SkillHistory to fetch.
     */
    where: SkillHistoryWhereUniqueInput
  }

  /**
   * SkillHistory findUniqueOrThrow
   */
  export type SkillHistoryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SkillHistory to fetch.
     */
    where: SkillHistoryWhereUniqueInput
  }

  /**
   * SkillHistory findFirst
   */
  export type SkillHistoryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SkillHistory to fetch.
     */
    where?: SkillHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SkillHistories to fetch.
     */
    orderBy?: SkillHistoryOrderByWithRelationInput | SkillHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SkillHistories.
     */
    cursor?: SkillHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SkillHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SkillHistories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SkillHistories.
     */
    distinct?: SkillHistoryScalarFieldEnum | SkillHistoryScalarFieldEnum[]
  }

  /**
   * SkillHistory findFirstOrThrow
   */
  export type SkillHistoryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SkillHistory to fetch.
     */
    where?: SkillHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SkillHistories to fetch.
     */
    orderBy?: SkillHistoryOrderByWithRelationInput | SkillHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SkillHistories.
     */
    cursor?: SkillHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SkillHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SkillHistories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SkillHistories.
     */
    distinct?: SkillHistoryScalarFieldEnum | SkillHistoryScalarFieldEnum[]
  }

  /**
   * SkillHistory findMany
   */
  export type SkillHistoryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SkillHistories to fetch.
     */
    where?: SkillHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SkillHistories to fetch.
     */
    orderBy?: SkillHistoryOrderByWithRelationInput | SkillHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SkillHistories.
     */
    cursor?: SkillHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SkillHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SkillHistories.
     */
    skip?: number
    distinct?: SkillHistoryScalarFieldEnum | SkillHistoryScalarFieldEnum[]
  }

  /**
   * SkillHistory create
   */
  export type SkillHistoryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * The data needed to create a SkillHistory.
     */
    data: XOR<SkillHistoryCreateInput, SkillHistoryUncheckedCreateInput>
  }

  /**
   * SkillHistory createMany
   */
  export type SkillHistoryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SkillHistories.
     */
    data: SkillHistoryCreateManyInput | SkillHistoryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SkillHistory createManyAndReturn
   */
  export type SkillHistoryCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * The data used to create many SkillHistories.
     */
    data: SkillHistoryCreateManyInput | SkillHistoryCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * SkillHistory update
   */
  export type SkillHistoryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * The data needed to update a SkillHistory.
     */
    data: XOR<SkillHistoryUpdateInput, SkillHistoryUncheckedUpdateInput>
    /**
     * Choose, which SkillHistory to update.
     */
    where: SkillHistoryWhereUniqueInput
  }

  /**
   * SkillHistory updateMany
   */
  export type SkillHistoryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SkillHistories.
     */
    data: XOR<SkillHistoryUpdateManyMutationInput, SkillHistoryUncheckedUpdateManyInput>
    /**
     * Filter which SkillHistories to update
     */
    where?: SkillHistoryWhereInput
    /**
     * Limit how many SkillHistories to update.
     */
    limit?: number
  }

  /**
   * SkillHistory updateManyAndReturn
   */
  export type SkillHistoryUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * The data used to update SkillHistories.
     */
    data: XOR<SkillHistoryUpdateManyMutationInput, SkillHistoryUncheckedUpdateManyInput>
    /**
     * Filter which SkillHistories to update
     */
    where?: SkillHistoryWhereInput
    /**
     * Limit how many SkillHistories to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * SkillHistory upsert
   */
  export type SkillHistoryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * The filter to search for the SkillHistory to update in case it exists.
     */
    where: SkillHistoryWhereUniqueInput
    /**
     * In case the SkillHistory found by the `where` argument doesn't exist, create a new SkillHistory with this data.
     */
    create: XOR<SkillHistoryCreateInput, SkillHistoryUncheckedCreateInput>
    /**
     * In case the SkillHistory was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SkillHistoryUpdateInput, SkillHistoryUncheckedUpdateInput>
  }

  /**
   * SkillHistory delete
   */
  export type SkillHistoryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
    /**
     * Filter which SkillHistory to delete.
     */
    where: SkillHistoryWhereUniqueInput
  }

  /**
   * SkillHistory deleteMany
   */
  export type SkillHistoryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SkillHistories to delete
     */
    where?: SkillHistoryWhereInput
    /**
     * Limit how many SkillHistories to delete.
     */
    limit?: number
  }

  /**
   * SkillHistory.session
   */
  export type SkillHistory$sessionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    where?: SessionWhereInput
  }

  /**
   * SkillHistory without action
   */
  export type SkillHistoryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SkillHistory
     */
    select?: SkillHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SkillHistory
     */
    omit?: SkillHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SkillHistoryInclude<ExtArgs> | null
  }


  /**
   * Model SanityHistory
   */

  export type AggregateSanityHistory = {
    _count: SanityHistoryCountAggregateOutputType | null
    _avg: SanityHistoryAvgAggregateOutputType | null
    _sum: SanityHistorySumAggregateOutputType | null
    _min: SanityHistoryMinAggregateOutputType | null
    _max: SanityHistoryMaxAggregateOutputType | null
  }

  export type SanityHistoryAvgAggregateOutputType = {
    oldValue: number | null
    newValue: number | null
  }

  export type SanityHistorySumAggregateOutputType = {
    oldValue: number | null
    newValue: number | null
  }

  export type SanityHistoryMinAggregateOutputType = {
    id: string | null
    characterId: string | null
    sessionId: string | null
    oldValue: number | null
    newValue: number | null
    reason: string | null
    createdAt: Date | null
  }

  export type SanityHistoryMaxAggregateOutputType = {
    id: string | null
    characterId: string | null
    sessionId: string | null
    oldValue: number | null
    newValue: number | null
    reason: string | null
    createdAt: Date | null
  }

  export type SanityHistoryCountAggregateOutputType = {
    id: number
    characterId: number
    sessionId: number
    oldValue: number
    newValue: number
    reason: number
    createdAt: number
    _all: number
  }


  export type SanityHistoryAvgAggregateInputType = {
    oldValue?: true
    newValue?: true
  }

  export type SanityHistorySumAggregateInputType = {
    oldValue?: true
    newValue?: true
  }

  export type SanityHistoryMinAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    oldValue?: true
    newValue?: true
    reason?: true
    createdAt?: true
  }

  export type SanityHistoryMaxAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    oldValue?: true
    newValue?: true
    reason?: true
    createdAt?: true
  }

  export type SanityHistoryCountAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    oldValue?: true
    newValue?: true
    reason?: true
    createdAt?: true
    _all?: true
  }

  export type SanityHistoryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SanityHistory to aggregate.
     */
    where?: SanityHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SanityHistories to fetch.
     */
    orderBy?: SanityHistoryOrderByWithRelationInput | SanityHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SanityHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SanityHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SanityHistories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SanityHistories
    **/
    _count?: true | SanityHistoryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SanityHistoryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SanityHistorySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SanityHistoryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SanityHistoryMaxAggregateInputType
  }

  export type GetSanityHistoryAggregateType<T extends SanityHistoryAggregateArgs> = {
        [P in keyof T & keyof AggregateSanityHistory]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSanityHistory[P]>
      : GetScalarType<T[P], AggregateSanityHistory[P]>
  }




  export type SanityHistoryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SanityHistoryWhereInput
    orderBy?: SanityHistoryOrderByWithAggregationInput | SanityHistoryOrderByWithAggregationInput[]
    by: SanityHistoryScalarFieldEnum[] | SanityHistoryScalarFieldEnum
    having?: SanityHistoryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SanityHistoryCountAggregateInputType | true
    _avg?: SanityHistoryAvgAggregateInputType
    _sum?: SanityHistorySumAggregateInputType
    _min?: SanityHistoryMinAggregateInputType
    _max?: SanityHistoryMaxAggregateInputType
  }

  export type SanityHistoryGroupByOutputType = {
    id: string
    characterId: string
    sessionId: string | null
    oldValue: number
    newValue: number
    reason: string
    createdAt: Date
    _count: SanityHistoryCountAggregateOutputType | null
    _avg: SanityHistoryAvgAggregateOutputType | null
    _sum: SanityHistorySumAggregateOutputType | null
    _min: SanityHistoryMinAggregateOutputType | null
    _max: SanityHistoryMaxAggregateOutputType | null
  }

  type GetSanityHistoryGroupByPayload<T extends SanityHistoryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SanityHistoryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SanityHistoryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SanityHistoryGroupByOutputType[P]>
            : GetScalarType<T[P], SanityHistoryGroupByOutputType[P]>
        }
      >
    >


  export type SanityHistorySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SanityHistory$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["sanityHistory"]>

  export type SanityHistorySelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SanityHistory$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["sanityHistory"]>

  export type SanityHistorySelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SanityHistory$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["sanityHistory"]>

  export type SanityHistorySelectScalar = {
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    oldValue?: boolean
    newValue?: boolean
    reason?: boolean
    createdAt?: boolean
  }

  export type SanityHistoryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "characterId" | "sessionId" | "oldValue" | "newValue" | "reason" | "createdAt", ExtArgs["result"]["sanityHistory"]>
  export type SanityHistoryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SanityHistory$sessionArgs<ExtArgs>
  }
  export type SanityHistoryIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SanityHistory$sessionArgs<ExtArgs>
  }
  export type SanityHistoryIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | SanityHistory$sessionArgs<ExtArgs>
  }

  export type $SanityHistoryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SanityHistory"
    objects: {
      character: Prisma.$CharacterPayload<ExtArgs>
      session: Prisma.$SessionPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      characterId: string
      sessionId: string | null
      oldValue: number
      newValue: number
      reason: string
      createdAt: Date
    }, ExtArgs["result"]["sanityHistory"]>
    composites: {}
  }

  type SanityHistoryGetPayload<S extends boolean | null | undefined | SanityHistoryDefaultArgs> = $Result.GetResult<Prisma.$SanityHistoryPayload, S>

  type SanityHistoryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SanityHistoryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SanityHistoryCountAggregateInputType | true
    }

  export interface SanityHistoryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SanityHistory'], meta: { name: 'SanityHistory' } }
    /**
     * Find zero or one SanityHistory that matches the filter.
     * @param {SanityHistoryFindUniqueArgs} args - Arguments to find a SanityHistory
     * @example
     * // Get one SanityHistory
     * const sanityHistory = await prisma.sanityHistory.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SanityHistoryFindUniqueArgs>(args: SelectSubset<T, SanityHistoryFindUniqueArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SanityHistory that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SanityHistoryFindUniqueOrThrowArgs} args - Arguments to find a SanityHistory
     * @example
     * // Get one SanityHistory
     * const sanityHistory = await prisma.sanityHistory.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SanityHistoryFindUniqueOrThrowArgs>(args: SelectSubset<T, SanityHistoryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SanityHistory that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SanityHistoryFindFirstArgs} args - Arguments to find a SanityHistory
     * @example
     * // Get one SanityHistory
     * const sanityHistory = await prisma.sanityHistory.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SanityHistoryFindFirstArgs>(args?: SelectSubset<T, SanityHistoryFindFirstArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SanityHistory that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SanityHistoryFindFirstOrThrowArgs} args - Arguments to find a SanityHistory
     * @example
     * // Get one SanityHistory
     * const sanityHistory = await prisma.sanityHistory.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SanityHistoryFindFirstOrThrowArgs>(args?: SelectSubset<T, SanityHistoryFindFirstOrThrowArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SanityHistories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SanityHistoryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SanityHistories
     * const sanityHistories = await prisma.sanityHistory.findMany()
     * 
     * // Get first 10 SanityHistories
     * const sanityHistories = await prisma.sanityHistory.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sanityHistoryWithIdOnly = await prisma.sanityHistory.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SanityHistoryFindManyArgs>(args?: SelectSubset<T, SanityHistoryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SanityHistory.
     * @param {SanityHistoryCreateArgs} args - Arguments to create a SanityHistory.
     * @example
     * // Create one SanityHistory
     * const SanityHistory = await prisma.sanityHistory.create({
     *   data: {
     *     // ... data to create a SanityHistory
     *   }
     * })
     * 
     */
    create<T extends SanityHistoryCreateArgs>(args: SelectSubset<T, SanityHistoryCreateArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SanityHistories.
     * @param {SanityHistoryCreateManyArgs} args - Arguments to create many SanityHistories.
     * @example
     * // Create many SanityHistories
     * const sanityHistory = await prisma.sanityHistory.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SanityHistoryCreateManyArgs>(args?: SelectSubset<T, SanityHistoryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many SanityHistories and returns the data saved in the database.
     * @param {SanityHistoryCreateManyAndReturnArgs} args - Arguments to create many SanityHistories.
     * @example
     * // Create many SanityHistories
     * const sanityHistory = await prisma.sanityHistory.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many SanityHistories and only return the `id`
     * const sanityHistoryWithIdOnly = await prisma.sanityHistory.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SanityHistoryCreateManyAndReturnArgs>(args?: SelectSubset<T, SanityHistoryCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a SanityHistory.
     * @param {SanityHistoryDeleteArgs} args - Arguments to delete one SanityHistory.
     * @example
     * // Delete one SanityHistory
     * const SanityHistory = await prisma.sanityHistory.delete({
     *   where: {
     *     // ... filter to delete one SanityHistory
     *   }
     * })
     * 
     */
    delete<T extends SanityHistoryDeleteArgs>(args: SelectSubset<T, SanityHistoryDeleteArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SanityHistory.
     * @param {SanityHistoryUpdateArgs} args - Arguments to update one SanityHistory.
     * @example
     * // Update one SanityHistory
     * const sanityHistory = await prisma.sanityHistory.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SanityHistoryUpdateArgs>(args: SelectSubset<T, SanityHistoryUpdateArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SanityHistories.
     * @param {SanityHistoryDeleteManyArgs} args - Arguments to filter SanityHistories to delete.
     * @example
     * // Delete a few SanityHistories
     * const { count } = await prisma.sanityHistory.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SanityHistoryDeleteManyArgs>(args?: SelectSubset<T, SanityHistoryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SanityHistories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SanityHistoryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SanityHistories
     * const sanityHistory = await prisma.sanityHistory.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SanityHistoryUpdateManyArgs>(args: SelectSubset<T, SanityHistoryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SanityHistories and returns the data updated in the database.
     * @param {SanityHistoryUpdateManyAndReturnArgs} args - Arguments to update many SanityHistories.
     * @example
     * // Update many SanityHistories
     * const sanityHistory = await prisma.sanityHistory.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more SanityHistories and only return the `id`
     * const sanityHistoryWithIdOnly = await prisma.sanityHistory.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SanityHistoryUpdateManyAndReturnArgs>(args: SelectSubset<T, SanityHistoryUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one SanityHistory.
     * @param {SanityHistoryUpsertArgs} args - Arguments to update or create a SanityHistory.
     * @example
     * // Update or create a SanityHistory
     * const sanityHistory = await prisma.sanityHistory.upsert({
     *   create: {
     *     // ... data to create a SanityHistory
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SanityHistory we want to update
     *   }
     * })
     */
    upsert<T extends SanityHistoryUpsertArgs>(args: SelectSubset<T, SanityHistoryUpsertArgs<ExtArgs>>): Prisma__SanityHistoryClient<$Result.GetResult<Prisma.$SanityHistoryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SanityHistories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SanityHistoryCountArgs} args - Arguments to filter SanityHistories to count.
     * @example
     * // Count the number of SanityHistories
     * const count = await prisma.sanityHistory.count({
     *   where: {
     *     // ... the filter for the SanityHistories we want to count
     *   }
     * })
    **/
    count<T extends SanityHistoryCountArgs>(
      args?: Subset<T, SanityHistoryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SanityHistoryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SanityHistory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SanityHistoryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SanityHistoryAggregateArgs>(args: Subset<T, SanityHistoryAggregateArgs>): Prisma.PrismaPromise<GetSanityHistoryAggregateType<T>>

    /**
     * Group by SanityHistory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SanityHistoryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SanityHistoryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SanityHistoryGroupByArgs['orderBy'] }
        : { orderBy?: SanityHistoryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SanityHistoryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSanityHistoryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SanityHistory model
   */
  readonly fields: SanityHistoryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SanityHistory.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SanityHistoryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    character<T extends CharacterDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CharacterDefaultArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    session<T extends SanityHistory$sessionArgs<ExtArgs> = {}>(args?: Subset<T, SanityHistory$sessionArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SanityHistory model
   */
  interface SanityHistoryFieldRefs {
    readonly id: FieldRef<"SanityHistory", 'String'>
    readonly characterId: FieldRef<"SanityHistory", 'String'>
    readonly sessionId: FieldRef<"SanityHistory", 'String'>
    readonly oldValue: FieldRef<"SanityHistory", 'Int'>
    readonly newValue: FieldRef<"SanityHistory", 'Int'>
    readonly reason: FieldRef<"SanityHistory", 'String'>
    readonly createdAt: FieldRef<"SanityHistory", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SanityHistory findUnique
   */
  export type SanityHistoryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SanityHistory to fetch.
     */
    where: SanityHistoryWhereUniqueInput
  }

  /**
   * SanityHistory findUniqueOrThrow
   */
  export type SanityHistoryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SanityHistory to fetch.
     */
    where: SanityHistoryWhereUniqueInput
  }

  /**
   * SanityHistory findFirst
   */
  export type SanityHistoryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SanityHistory to fetch.
     */
    where?: SanityHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SanityHistories to fetch.
     */
    orderBy?: SanityHistoryOrderByWithRelationInput | SanityHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SanityHistories.
     */
    cursor?: SanityHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SanityHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SanityHistories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SanityHistories.
     */
    distinct?: SanityHistoryScalarFieldEnum | SanityHistoryScalarFieldEnum[]
  }

  /**
   * SanityHistory findFirstOrThrow
   */
  export type SanityHistoryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SanityHistory to fetch.
     */
    where?: SanityHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SanityHistories to fetch.
     */
    orderBy?: SanityHistoryOrderByWithRelationInput | SanityHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SanityHistories.
     */
    cursor?: SanityHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SanityHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SanityHistories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SanityHistories.
     */
    distinct?: SanityHistoryScalarFieldEnum | SanityHistoryScalarFieldEnum[]
  }

  /**
   * SanityHistory findMany
   */
  export type SanityHistoryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * Filter, which SanityHistories to fetch.
     */
    where?: SanityHistoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SanityHistories to fetch.
     */
    orderBy?: SanityHistoryOrderByWithRelationInput | SanityHistoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SanityHistories.
     */
    cursor?: SanityHistoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SanityHistories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SanityHistories.
     */
    skip?: number
    distinct?: SanityHistoryScalarFieldEnum | SanityHistoryScalarFieldEnum[]
  }

  /**
   * SanityHistory create
   */
  export type SanityHistoryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * The data needed to create a SanityHistory.
     */
    data: XOR<SanityHistoryCreateInput, SanityHistoryUncheckedCreateInput>
  }

  /**
   * SanityHistory createMany
   */
  export type SanityHistoryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SanityHistories.
     */
    data: SanityHistoryCreateManyInput | SanityHistoryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SanityHistory createManyAndReturn
   */
  export type SanityHistoryCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * The data used to create many SanityHistories.
     */
    data: SanityHistoryCreateManyInput | SanityHistoryCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * SanityHistory update
   */
  export type SanityHistoryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * The data needed to update a SanityHistory.
     */
    data: XOR<SanityHistoryUpdateInput, SanityHistoryUncheckedUpdateInput>
    /**
     * Choose, which SanityHistory to update.
     */
    where: SanityHistoryWhereUniqueInput
  }

  /**
   * SanityHistory updateMany
   */
  export type SanityHistoryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SanityHistories.
     */
    data: XOR<SanityHistoryUpdateManyMutationInput, SanityHistoryUncheckedUpdateManyInput>
    /**
     * Filter which SanityHistories to update
     */
    where?: SanityHistoryWhereInput
    /**
     * Limit how many SanityHistories to update.
     */
    limit?: number
  }

  /**
   * SanityHistory updateManyAndReturn
   */
  export type SanityHistoryUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * The data used to update SanityHistories.
     */
    data: XOR<SanityHistoryUpdateManyMutationInput, SanityHistoryUncheckedUpdateManyInput>
    /**
     * Filter which SanityHistories to update
     */
    where?: SanityHistoryWhereInput
    /**
     * Limit how many SanityHistories to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * SanityHistory upsert
   */
  export type SanityHistoryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * The filter to search for the SanityHistory to update in case it exists.
     */
    where: SanityHistoryWhereUniqueInput
    /**
     * In case the SanityHistory found by the `where` argument doesn't exist, create a new SanityHistory with this data.
     */
    create: XOR<SanityHistoryCreateInput, SanityHistoryUncheckedCreateInput>
    /**
     * In case the SanityHistory was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SanityHistoryUpdateInput, SanityHistoryUncheckedUpdateInput>
  }

  /**
   * SanityHistory delete
   */
  export type SanityHistoryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
    /**
     * Filter which SanityHistory to delete.
     */
    where: SanityHistoryWhereUniqueInput
  }

  /**
   * SanityHistory deleteMany
   */
  export type SanityHistoryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SanityHistories to delete
     */
    where?: SanityHistoryWhereInput
    /**
     * Limit how many SanityHistories to delete.
     */
    limit?: number
  }

  /**
   * SanityHistory.session
   */
  export type SanityHistory$sessionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    where?: SessionWhereInput
  }

  /**
   * SanityHistory without action
   */
  export type SanityHistoryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SanityHistory
     */
    select?: SanityHistorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SanityHistory
     */
    omit?: SanityHistoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SanityHistoryInclude<ExtArgs> | null
  }


  /**
   * Model InsanitySymptom
   */

  export type AggregateInsanitySymptom = {
    _count: InsanitySymptomCountAggregateOutputType | null
    _min: InsanitySymptomMinAggregateOutputType | null
    _max: InsanitySymptomMaxAggregateOutputType | null
  }

  export type InsanitySymptomMinAggregateOutputType = {
    id: string | null
    characterId: string | null
    sessionId: string | null
    symptomType: string | null
    symptomName: string | null
    description: string | null
    isRecovered: boolean | null
    recoveredAt: Date | null
    createdAt: Date | null
  }

  export type InsanitySymptomMaxAggregateOutputType = {
    id: string | null
    characterId: string | null
    sessionId: string | null
    symptomType: string | null
    symptomName: string | null
    description: string | null
    isRecovered: boolean | null
    recoveredAt: Date | null
    createdAt: Date | null
  }

  export type InsanitySymptomCountAggregateOutputType = {
    id: number
    characterId: number
    sessionId: number
    symptomType: number
    symptomName: number
    description: number
    isRecovered: number
    recoveredAt: number
    createdAt: number
    _all: number
  }


  export type InsanitySymptomMinAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    symptomType?: true
    symptomName?: true
    description?: true
    isRecovered?: true
    recoveredAt?: true
    createdAt?: true
  }

  export type InsanitySymptomMaxAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    symptomType?: true
    symptomName?: true
    description?: true
    isRecovered?: true
    recoveredAt?: true
    createdAt?: true
  }

  export type InsanitySymptomCountAggregateInputType = {
    id?: true
    characterId?: true
    sessionId?: true
    symptomType?: true
    symptomName?: true
    description?: true
    isRecovered?: true
    recoveredAt?: true
    createdAt?: true
    _all?: true
  }

  export type InsanitySymptomAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which InsanitySymptom to aggregate.
     */
    where?: InsanitySymptomWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InsanitySymptoms to fetch.
     */
    orderBy?: InsanitySymptomOrderByWithRelationInput | InsanitySymptomOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: InsanitySymptomWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InsanitySymptoms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InsanitySymptoms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned InsanitySymptoms
    **/
    _count?: true | InsanitySymptomCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: InsanitySymptomMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: InsanitySymptomMaxAggregateInputType
  }

  export type GetInsanitySymptomAggregateType<T extends InsanitySymptomAggregateArgs> = {
        [P in keyof T & keyof AggregateInsanitySymptom]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateInsanitySymptom[P]>
      : GetScalarType<T[P], AggregateInsanitySymptom[P]>
  }




  export type InsanitySymptomGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: InsanitySymptomWhereInput
    orderBy?: InsanitySymptomOrderByWithAggregationInput | InsanitySymptomOrderByWithAggregationInput[]
    by: InsanitySymptomScalarFieldEnum[] | InsanitySymptomScalarFieldEnum
    having?: InsanitySymptomScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: InsanitySymptomCountAggregateInputType | true
    _min?: InsanitySymptomMinAggregateInputType
    _max?: InsanitySymptomMaxAggregateInputType
  }

  export type InsanitySymptomGroupByOutputType = {
    id: string
    characterId: string
    sessionId: string | null
    symptomType: string
    symptomName: string
    description: string | null
    isRecovered: boolean
    recoveredAt: Date | null
    createdAt: Date
    _count: InsanitySymptomCountAggregateOutputType | null
    _min: InsanitySymptomMinAggregateOutputType | null
    _max: InsanitySymptomMaxAggregateOutputType | null
  }

  type GetInsanitySymptomGroupByPayload<T extends InsanitySymptomGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<InsanitySymptomGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof InsanitySymptomGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], InsanitySymptomGroupByOutputType[P]>
            : GetScalarType<T[P], InsanitySymptomGroupByOutputType[P]>
        }
      >
    >


  export type InsanitySymptomSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    symptomType?: boolean
    symptomName?: boolean
    description?: boolean
    isRecovered?: boolean
    recoveredAt?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | InsanitySymptom$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["insanitySymptom"]>

  export type InsanitySymptomSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    symptomType?: boolean
    symptomName?: boolean
    description?: boolean
    isRecovered?: boolean
    recoveredAt?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | InsanitySymptom$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["insanitySymptom"]>

  export type InsanitySymptomSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    symptomType?: boolean
    symptomName?: boolean
    description?: boolean
    isRecovered?: boolean
    recoveredAt?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | InsanitySymptom$sessionArgs<ExtArgs>
  }, ExtArgs["result"]["insanitySymptom"]>

  export type InsanitySymptomSelectScalar = {
    id?: boolean
    characterId?: boolean
    sessionId?: boolean
    symptomType?: boolean
    symptomName?: boolean
    description?: boolean
    isRecovered?: boolean
    recoveredAt?: boolean
    createdAt?: boolean
  }

  export type InsanitySymptomOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "characterId" | "sessionId" | "symptomType" | "symptomName" | "description" | "isRecovered" | "recoveredAt" | "createdAt", ExtArgs["result"]["insanitySymptom"]>
  export type InsanitySymptomInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | InsanitySymptom$sessionArgs<ExtArgs>
  }
  export type InsanitySymptomIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | InsanitySymptom$sessionArgs<ExtArgs>
  }
  export type InsanitySymptomIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
    session?: boolean | InsanitySymptom$sessionArgs<ExtArgs>
  }

  export type $InsanitySymptomPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "InsanitySymptom"
    objects: {
      character: Prisma.$CharacterPayload<ExtArgs>
      session: Prisma.$SessionPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      characterId: string
      sessionId: string | null
      symptomType: string
      symptomName: string
      description: string | null
      isRecovered: boolean
      recoveredAt: Date | null
      createdAt: Date
    }, ExtArgs["result"]["insanitySymptom"]>
    composites: {}
  }

  type InsanitySymptomGetPayload<S extends boolean | null | undefined | InsanitySymptomDefaultArgs> = $Result.GetResult<Prisma.$InsanitySymptomPayload, S>

  type InsanitySymptomCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<InsanitySymptomFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: InsanitySymptomCountAggregateInputType | true
    }

  export interface InsanitySymptomDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['InsanitySymptom'], meta: { name: 'InsanitySymptom' } }
    /**
     * Find zero or one InsanitySymptom that matches the filter.
     * @param {InsanitySymptomFindUniqueArgs} args - Arguments to find a InsanitySymptom
     * @example
     * // Get one InsanitySymptom
     * const insanitySymptom = await prisma.insanitySymptom.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends InsanitySymptomFindUniqueArgs>(args: SelectSubset<T, InsanitySymptomFindUniqueArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one InsanitySymptom that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {InsanitySymptomFindUniqueOrThrowArgs} args - Arguments to find a InsanitySymptom
     * @example
     * // Get one InsanitySymptom
     * const insanitySymptom = await prisma.insanitySymptom.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends InsanitySymptomFindUniqueOrThrowArgs>(args: SelectSubset<T, InsanitySymptomFindUniqueOrThrowArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first InsanitySymptom that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InsanitySymptomFindFirstArgs} args - Arguments to find a InsanitySymptom
     * @example
     * // Get one InsanitySymptom
     * const insanitySymptom = await prisma.insanitySymptom.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends InsanitySymptomFindFirstArgs>(args?: SelectSubset<T, InsanitySymptomFindFirstArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first InsanitySymptom that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InsanitySymptomFindFirstOrThrowArgs} args - Arguments to find a InsanitySymptom
     * @example
     * // Get one InsanitySymptom
     * const insanitySymptom = await prisma.insanitySymptom.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends InsanitySymptomFindFirstOrThrowArgs>(args?: SelectSubset<T, InsanitySymptomFindFirstOrThrowArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more InsanitySymptoms that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InsanitySymptomFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all InsanitySymptoms
     * const insanitySymptoms = await prisma.insanitySymptom.findMany()
     * 
     * // Get first 10 InsanitySymptoms
     * const insanitySymptoms = await prisma.insanitySymptom.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const insanitySymptomWithIdOnly = await prisma.insanitySymptom.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends InsanitySymptomFindManyArgs>(args?: SelectSubset<T, InsanitySymptomFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a InsanitySymptom.
     * @param {InsanitySymptomCreateArgs} args - Arguments to create a InsanitySymptom.
     * @example
     * // Create one InsanitySymptom
     * const InsanitySymptom = await prisma.insanitySymptom.create({
     *   data: {
     *     // ... data to create a InsanitySymptom
     *   }
     * })
     * 
     */
    create<T extends InsanitySymptomCreateArgs>(args: SelectSubset<T, InsanitySymptomCreateArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many InsanitySymptoms.
     * @param {InsanitySymptomCreateManyArgs} args - Arguments to create many InsanitySymptoms.
     * @example
     * // Create many InsanitySymptoms
     * const insanitySymptom = await prisma.insanitySymptom.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends InsanitySymptomCreateManyArgs>(args?: SelectSubset<T, InsanitySymptomCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many InsanitySymptoms and returns the data saved in the database.
     * @param {InsanitySymptomCreateManyAndReturnArgs} args - Arguments to create many InsanitySymptoms.
     * @example
     * // Create many InsanitySymptoms
     * const insanitySymptom = await prisma.insanitySymptom.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many InsanitySymptoms and only return the `id`
     * const insanitySymptomWithIdOnly = await prisma.insanitySymptom.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends InsanitySymptomCreateManyAndReturnArgs>(args?: SelectSubset<T, InsanitySymptomCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a InsanitySymptom.
     * @param {InsanitySymptomDeleteArgs} args - Arguments to delete one InsanitySymptom.
     * @example
     * // Delete one InsanitySymptom
     * const InsanitySymptom = await prisma.insanitySymptom.delete({
     *   where: {
     *     // ... filter to delete one InsanitySymptom
     *   }
     * })
     * 
     */
    delete<T extends InsanitySymptomDeleteArgs>(args: SelectSubset<T, InsanitySymptomDeleteArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one InsanitySymptom.
     * @param {InsanitySymptomUpdateArgs} args - Arguments to update one InsanitySymptom.
     * @example
     * // Update one InsanitySymptom
     * const insanitySymptom = await prisma.insanitySymptom.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends InsanitySymptomUpdateArgs>(args: SelectSubset<T, InsanitySymptomUpdateArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more InsanitySymptoms.
     * @param {InsanitySymptomDeleteManyArgs} args - Arguments to filter InsanitySymptoms to delete.
     * @example
     * // Delete a few InsanitySymptoms
     * const { count } = await prisma.insanitySymptom.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends InsanitySymptomDeleteManyArgs>(args?: SelectSubset<T, InsanitySymptomDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more InsanitySymptoms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InsanitySymptomUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many InsanitySymptoms
     * const insanitySymptom = await prisma.insanitySymptom.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends InsanitySymptomUpdateManyArgs>(args: SelectSubset<T, InsanitySymptomUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more InsanitySymptoms and returns the data updated in the database.
     * @param {InsanitySymptomUpdateManyAndReturnArgs} args - Arguments to update many InsanitySymptoms.
     * @example
     * // Update many InsanitySymptoms
     * const insanitySymptom = await prisma.insanitySymptom.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more InsanitySymptoms and only return the `id`
     * const insanitySymptomWithIdOnly = await prisma.insanitySymptom.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends InsanitySymptomUpdateManyAndReturnArgs>(args: SelectSubset<T, InsanitySymptomUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one InsanitySymptom.
     * @param {InsanitySymptomUpsertArgs} args - Arguments to update or create a InsanitySymptom.
     * @example
     * // Update or create a InsanitySymptom
     * const insanitySymptom = await prisma.insanitySymptom.upsert({
     *   create: {
     *     // ... data to create a InsanitySymptom
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the InsanitySymptom we want to update
     *   }
     * })
     */
    upsert<T extends InsanitySymptomUpsertArgs>(args: SelectSubset<T, InsanitySymptomUpsertArgs<ExtArgs>>): Prisma__InsanitySymptomClient<$Result.GetResult<Prisma.$InsanitySymptomPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of InsanitySymptoms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InsanitySymptomCountArgs} args - Arguments to filter InsanitySymptoms to count.
     * @example
     * // Count the number of InsanitySymptoms
     * const count = await prisma.insanitySymptom.count({
     *   where: {
     *     // ... the filter for the InsanitySymptoms we want to count
     *   }
     * })
    **/
    count<T extends InsanitySymptomCountArgs>(
      args?: Subset<T, InsanitySymptomCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], InsanitySymptomCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a InsanitySymptom.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InsanitySymptomAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends InsanitySymptomAggregateArgs>(args: Subset<T, InsanitySymptomAggregateArgs>): Prisma.PrismaPromise<GetInsanitySymptomAggregateType<T>>

    /**
     * Group by InsanitySymptom.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InsanitySymptomGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends InsanitySymptomGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: InsanitySymptomGroupByArgs['orderBy'] }
        : { orderBy?: InsanitySymptomGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, InsanitySymptomGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetInsanitySymptomGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the InsanitySymptom model
   */
  readonly fields: InsanitySymptomFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for InsanitySymptom.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__InsanitySymptomClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    character<T extends CharacterDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CharacterDefaultArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    session<T extends InsanitySymptom$sessionArgs<ExtArgs> = {}>(args?: Subset<T, InsanitySymptom$sessionArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the InsanitySymptom model
   */
  interface InsanitySymptomFieldRefs {
    readonly id: FieldRef<"InsanitySymptom", 'String'>
    readonly characterId: FieldRef<"InsanitySymptom", 'String'>
    readonly sessionId: FieldRef<"InsanitySymptom", 'String'>
    readonly symptomType: FieldRef<"InsanitySymptom", 'String'>
    readonly symptomName: FieldRef<"InsanitySymptom", 'String'>
    readonly description: FieldRef<"InsanitySymptom", 'String'>
    readonly isRecovered: FieldRef<"InsanitySymptom", 'Boolean'>
    readonly recoveredAt: FieldRef<"InsanitySymptom", 'DateTime'>
    readonly createdAt: FieldRef<"InsanitySymptom", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * InsanitySymptom findUnique
   */
  export type InsanitySymptomFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * Filter, which InsanitySymptom to fetch.
     */
    where: InsanitySymptomWhereUniqueInput
  }

  /**
   * InsanitySymptom findUniqueOrThrow
   */
  export type InsanitySymptomFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * Filter, which InsanitySymptom to fetch.
     */
    where: InsanitySymptomWhereUniqueInput
  }

  /**
   * InsanitySymptom findFirst
   */
  export type InsanitySymptomFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * Filter, which InsanitySymptom to fetch.
     */
    where?: InsanitySymptomWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InsanitySymptoms to fetch.
     */
    orderBy?: InsanitySymptomOrderByWithRelationInput | InsanitySymptomOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for InsanitySymptoms.
     */
    cursor?: InsanitySymptomWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InsanitySymptoms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InsanitySymptoms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of InsanitySymptoms.
     */
    distinct?: InsanitySymptomScalarFieldEnum | InsanitySymptomScalarFieldEnum[]
  }

  /**
   * InsanitySymptom findFirstOrThrow
   */
  export type InsanitySymptomFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * Filter, which InsanitySymptom to fetch.
     */
    where?: InsanitySymptomWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InsanitySymptoms to fetch.
     */
    orderBy?: InsanitySymptomOrderByWithRelationInput | InsanitySymptomOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for InsanitySymptoms.
     */
    cursor?: InsanitySymptomWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InsanitySymptoms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InsanitySymptoms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of InsanitySymptoms.
     */
    distinct?: InsanitySymptomScalarFieldEnum | InsanitySymptomScalarFieldEnum[]
  }

  /**
   * InsanitySymptom findMany
   */
  export type InsanitySymptomFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * Filter, which InsanitySymptoms to fetch.
     */
    where?: InsanitySymptomWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InsanitySymptoms to fetch.
     */
    orderBy?: InsanitySymptomOrderByWithRelationInput | InsanitySymptomOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing InsanitySymptoms.
     */
    cursor?: InsanitySymptomWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InsanitySymptoms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InsanitySymptoms.
     */
    skip?: number
    distinct?: InsanitySymptomScalarFieldEnum | InsanitySymptomScalarFieldEnum[]
  }

  /**
   * InsanitySymptom create
   */
  export type InsanitySymptomCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * The data needed to create a InsanitySymptom.
     */
    data: XOR<InsanitySymptomCreateInput, InsanitySymptomUncheckedCreateInput>
  }

  /**
   * InsanitySymptom createMany
   */
  export type InsanitySymptomCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many InsanitySymptoms.
     */
    data: InsanitySymptomCreateManyInput | InsanitySymptomCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * InsanitySymptom createManyAndReturn
   */
  export type InsanitySymptomCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * The data used to create many InsanitySymptoms.
     */
    data: InsanitySymptomCreateManyInput | InsanitySymptomCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * InsanitySymptom update
   */
  export type InsanitySymptomUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * The data needed to update a InsanitySymptom.
     */
    data: XOR<InsanitySymptomUpdateInput, InsanitySymptomUncheckedUpdateInput>
    /**
     * Choose, which InsanitySymptom to update.
     */
    where: InsanitySymptomWhereUniqueInput
  }

  /**
   * InsanitySymptom updateMany
   */
  export type InsanitySymptomUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update InsanitySymptoms.
     */
    data: XOR<InsanitySymptomUpdateManyMutationInput, InsanitySymptomUncheckedUpdateManyInput>
    /**
     * Filter which InsanitySymptoms to update
     */
    where?: InsanitySymptomWhereInput
    /**
     * Limit how many InsanitySymptoms to update.
     */
    limit?: number
  }

  /**
   * InsanitySymptom updateManyAndReturn
   */
  export type InsanitySymptomUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * The data used to update InsanitySymptoms.
     */
    data: XOR<InsanitySymptomUpdateManyMutationInput, InsanitySymptomUncheckedUpdateManyInput>
    /**
     * Filter which InsanitySymptoms to update
     */
    where?: InsanitySymptomWhereInput
    /**
     * Limit how many InsanitySymptoms to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * InsanitySymptom upsert
   */
  export type InsanitySymptomUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * The filter to search for the InsanitySymptom to update in case it exists.
     */
    where: InsanitySymptomWhereUniqueInput
    /**
     * In case the InsanitySymptom found by the `where` argument doesn't exist, create a new InsanitySymptom with this data.
     */
    create: XOR<InsanitySymptomCreateInput, InsanitySymptomUncheckedCreateInput>
    /**
     * In case the InsanitySymptom was found with the provided `where` argument, update it with this data.
     */
    update: XOR<InsanitySymptomUpdateInput, InsanitySymptomUncheckedUpdateInput>
  }

  /**
   * InsanitySymptom delete
   */
  export type InsanitySymptomDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
    /**
     * Filter which InsanitySymptom to delete.
     */
    where: InsanitySymptomWhereUniqueInput
  }

  /**
   * InsanitySymptom deleteMany
   */
  export type InsanitySymptomDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which InsanitySymptoms to delete
     */
    where?: InsanitySymptomWhereInput
    /**
     * Limit how many InsanitySymptoms to delete.
     */
    limit?: number
  }

  /**
   * InsanitySymptom.session
   */
  export type InsanitySymptom$sessionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    where?: SessionWhereInput
  }

  /**
   * InsanitySymptom without action
   */
  export type InsanitySymptomDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InsanitySymptom
     */
    select?: InsanitySymptomSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InsanitySymptom
     */
    omit?: InsanitySymptomOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InsanitySymptomInclude<ExtArgs> | null
  }


  /**
   * Model CharacterImage
   */

  export type AggregateCharacterImage = {
    _count: CharacterImageCountAggregateOutputType | null
    _avg: CharacterImageAvgAggregateOutputType | null
    _sum: CharacterImageSumAggregateOutputType | null
    _min: CharacterImageMinAggregateOutputType | null
    _max: CharacterImageMaxAggregateOutputType | null
  }

  export type CharacterImageAvgAggregateOutputType = {
    fileSize: number | null
  }

  export type CharacterImageSumAggregateOutputType = {
    fileSize: number | null
  }

  export type CharacterImageMinAggregateOutputType = {
    id: string | null
    characterId: string | null
    filename: string | null
    originalName: string | null
    imageName: string | null
    filePath: string | null
    fileSize: number | null
    mimeType: string | null
    createdAt: Date | null
  }

  export type CharacterImageMaxAggregateOutputType = {
    id: string | null
    characterId: string | null
    filename: string | null
    originalName: string | null
    imageName: string | null
    filePath: string | null
    fileSize: number | null
    mimeType: string | null
    createdAt: Date | null
  }

  export type CharacterImageCountAggregateOutputType = {
    id: number
    characterId: number
    filename: number
    originalName: number
    imageName: number
    filePath: number
    fileSize: number
    mimeType: number
    createdAt: number
    _all: number
  }


  export type CharacterImageAvgAggregateInputType = {
    fileSize?: true
  }

  export type CharacterImageSumAggregateInputType = {
    fileSize?: true
  }

  export type CharacterImageMinAggregateInputType = {
    id?: true
    characterId?: true
    filename?: true
    originalName?: true
    imageName?: true
    filePath?: true
    fileSize?: true
    mimeType?: true
    createdAt?: true
  }

  export type CharacterImageMaxAggregateInputType = {
    id?: true
    characterId?: true
    filename?: true
    originalName?: true
    imageName?: true
    filePath?: true
    fileSize?: true
    mimeType?: true
    createdAt?: true
  }

  export type CharacterImageCountAggregateInputType = {
    id?: true
    characterId?: true
    filename?: true
    originalName?: true
    imageName?: true
    filePath?: true
    fileSize?: true
    mimeType?: true
    createdAt?: true
    _all?: true
  }

  export type CharacterImageAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CharacterImage to aggregate.
     */
    where?: CharacterImageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CharacterImages to fetch.
     */
    orderBy?: CharacterImageOrderByWithRelationInput | CharacterImageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CharacterImageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CharacterImages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CharacterImages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CharacterImages
    **/
    _count?: true | CharacterImageCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CharacterImageAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CharacterImageSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CharacterImageMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CharacterImageMaxAggregateInputType
  }

  export type GetCharacterImageAggregateType<T extends CharacterImageAggregateArgs> = {
        [P in keyof T & keyof AggregateCharacterImage]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCharacterImage[P]>
      : GetScalarType<T[P], AggregateCharacterImage[P]>
  }




  export type CharacterImageGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CharacterImageWhereInput
    orderBy?: CharacterImageOrderByWithAggregationInput | CharacterImageOrderByWithAggregationInput[]
    by: CharacterImageScalarFieldEnum[] | CharacterImageScalarFieldEnum
    having?: CharacterImageScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CharacterImageCountAggregateInputType | true
    _avg?: CharacterImageAvgAggregateInputType
    _sum?: CharacterImageSumAggregateInputType
    _min?: CharacterImageMinAggregateInputType
    _max?: CharacterImageMaxAggregateInputType
  }

  export type CharacterImageGroupByOutputType = {
    id: string
    characterId: string
    filename: string
    originalName: string
    imageName: string | null
    filePath: string
    fileSize: number
    mimeType: string
    createdAt: Date
    _count: CharacterImageCountAggregateOutputType | null
    _avg: CharacterImageAvgAggregateOutputType | null
    _sum: CharacterImageSumAggregateOutputType | null
    _min: CharacterImageMinAggregateOutputType | null
    _max: CharacterImageMaxAggregateOutputType | null
  }

  type GetCharacterImageGroupByPayload<T extends CharacterImageGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CharacterImageGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CharacterImageGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CharacterImageGroupByOutputType[P]>
            : GetScalarType<T[P], CharacterImageGroupByOutputType[P]>
        }
      >
    >


  export type CharacterImageSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    filename?: boolean
    originalName?: boolean
    imageName?: boolean
    filePath?: boolean
    fileSize?: boolean
    mimeType?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["characterImage"]>

  export type CharacterImageSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    filename?: boolean
    originalName?: boolean
    imageName?: boolean
    filePath?: boolean
    fileSize?: boolean
    mimeType?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["characterImage"]>

  export type CharacterImageSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    characterId?: boolean
    filename?: boolean
    originalName?: boolean
    imageName?: boolean
    filePath?: boolean
    fileSize?: boolean
    mimeType?: boolean
    createdAt?: boolean
    character?: boolean | CharacterDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["characterImage"]>

  export type CharacterImageSelectScalar = {
    id?: boolean
    characterId?: boolean
    filename?: boolean
    originalName?: boolean
    imageName?: boolean
    filePath?: boolean
    fileSize?: boolean
    mimeType?: boolean
    createdAt?: boolean
  }

  export type CharacterImageOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "characterId" | "filename" | "originalName" | "imageName" | "filePath" | "fileSize" | "mimeType" | "createdAt", ExtArgs["result"]["characterImage"]>
  export type CharacterImageInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
  }
  export type CharacterImageIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
  }
  export type CharacterImageIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    character?: boolean | CharacterDefaultArgs<ExtArgs>
  }

  export type $CharacterImagePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "CharacterImage"
    objects: {
      character: Prisma.$CharacterPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      characterId: string
      filename: string
      originalName: string
      imageName: string | null
      filePath: string
      fileSize: number
      mimeType: string
      createdAt: Date
    }, ExtArgs["result"]["characterImage"]>
    composites: {}
  }

  type CharacterImageGetPayload<S extends boolean | null | undefined | CharacterImageDefaultArgs> = $Result.GetResult<Prisma.$CharacterImagePayload, S>

  type CharacterImageCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CharacterImageFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CharacterImageCountAggregateInputType | true
    }

  export interface CharacterImageDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CharacterImage'], meta: { name: 'CharacterImage' } }
    /**
     * Find zero or one CharacterImage that matches the filter.
     * @param {CharacterImageFindUniqueArgs} args - Arguments to find a CharacterImage
     * @example
     * // Get one CharacterImage
     * const characterImage = await prisma.characterImage.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CharacterImageFindUniqueArgs>(args: SelectSubset<T, CharacterImageFindUniqueArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one CharacterImage that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CharacterImageFindUniqueOrThrowArgs} args - Arguments to find a CharacterImage
     * @example
     * // Get one CharacterImage
     * const characterImage = await prisma.characterImage.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CharacterImageFindUniqueOrThrowArgs>(args: SelectSubset<T, CharacterImageFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CharacterImage that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterImageFindFirstArgs} args - Arguments to find a CharacterImage
     * @example
     * // Get one CharacterImage
     * const characterImage = await prisma.characterImage.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CharacterImageFindFirstArgs>(args?: SelectSubset<T, CharacterImageFindFirstArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CharacterImage that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterImageFindFirstOrThrowArgs} args - Arguments to find a CharacterImage
     * @example
     * // Get one CharacterImage
     * const characterImage = await prisma.characterImage.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CharacterImageFindFirstOrThrowArgs>(args?: SelectSubset<T, CharacterImageFindFirstOrThrowArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more CharacterImages that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterImageFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CharacterImages
     * const characterImages = await prisma.characterImage.findMany()
     * 
     * // Get first 10 CharacterImages
     * const characterImages = await prisma.characterImage.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const characterImageWithIdOnly = await prisma.characterImage.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CharacterImageFindManyArgs>(args?: SelectSubset<T, CharacterImageFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a CharacterImage.
     * @param {CharacterImageCreateArgs} args - Arguments to create a CharacterImage.
     * @example
     * // Create one CharacterImage
     * const CharacterImage = await prisma.characterImage.create({
     *   data: {
     *     // ... data to create a CharacterImage
     *   }
     * })
     * 
     */
    create<T extends CharacterImageCreateArgs>(args: SelectSubset<T, CharacterImageCreateArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many CharacterImages.
     * @param {CharacterImageCreateManyArgs} args - Arguments to create many CharacterImages.
     * @example
     * // Create many CharacterImages
     * const characterImage = await prisma.characterImage.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CharacterImageCreateManyArgs>(args?: SelectSubset<T, CharacterImageCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many CharacterImages and returns the data saved in the database.
     * @param {CharacterImageCreateManyAndReturnArgs} args - Arguments to create many CharacterImages.
     * @example
     * // Create many CharacterImages
     * const characterImage = await prisma.characterImage.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many CharacterImages and only return the `id`
     * const characterImageWithIdOnly = await prisma.characterImage.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CharacterImageCreateManyAndReturnArgs>(args?: SelectSubset<T, CharacterImageCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a CharacterImage.
     * @param {CharacterImageDeleteArgs} args - Arguments to delete one CharacterImage.
     * @example
     * // Delete one CharacterImage
     * const CharacterImage = await prisma.characterImage.delete({
     *   where: {
     *     // ... filter to delete one CharacterImage
     *   }
     * })
     * 
     */
    delete<T extends CharacterImageDeleteArgs>(args: SelectSubset<T, CharacterImageDeleteArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one CharacterImage.
     * @param {CharacterImageUpdateArgs} args - Arguments to update one CharacterImage.
     * @example
     * // Update one CharacterImage
     * const characterImage = await prisma.characterImage.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CharacterImageUpdateArgs>(args: SelectSubset<T, CharacterImageUpdateArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more CharacterImages.
     * @param {CharacterImageDeleteManyArgs} args - Arguments to filter CharacterImages to delete.
     * @example
     * // Delete a few CharacterImages
     * const { count } = await prisma.characterImage.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CharacterImageDeleteManyArgs>(args?: SelectSubset<T, CharacterImageDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CharacterImages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterImageUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CharacterImages
     * const characterImage = await prisma.characterImage.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CharacterImageUpdateManyArgs>(args: SelectSubset<T, CharacterImageUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CharacterImages and returns the data updated in the database.
     * @param {CharacterImageUpdateManyAndReturnArgs} args - Arguments to update many CharacterImages.
     * @example
     * // Update many CharacterImages
     * const characterImage = await prisma.characterImage.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more CharacterImages and only return the `id`
     * const characterImageWithIdOnly = await prisma.characterImage.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CharacterImageUpdateManyAndReturnArgs>(args: SelectSubset<T, CharacterImageUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one CharacterImage.
     * @param {CharacterImageUpsertArgs} args - Arguments to update or create a CharacterImage.
     * @example
     * // Update or create a CharacterImage
     * const characterImage = await prisma.characterImage.upsert({
     *   create: {
     *     // ... data to create a CharacterImage
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CharacterImage we want to update
     *   }
     * })
     */
    upsert<T extends CharacterImageUpsertArgs>(args: SelectSubset<T, CharacterImageUpsertArgs<ExtArgs>>): Prisma__CharacterImageClient<$Result.GetResult<Prisma.$CharacterImagePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of CharacterImages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterImageCountArgs} args - Arguments to filter CharacterImages to count.
     * @example
     * // Count the number of CharacterImages
     * const count = await prisma.characterImage.count({
     *   where: {
     *     // ... the filter for the CharacterImages we want to count
     *   }
     * })
    **/
    count<T extends CharacterImageCountArgs>(
      args?: Subset<T, CharacterImageCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CharacterImageCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CharacterImage.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterImageAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CharacterImageAggregateArgs>(args: Subset<T, CharacterImageAggregateArgs>): Prisma.PrismaPromise<GetCharacterImageAggregateType<T>>

    /**
     * Group by CharacterImage.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CharacterImageGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CharacterImageGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CharacterImageGroupByArgs['orderBy'] }
        : { orderBy?: CharacterImageGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CharacterImageGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCharacterImageGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the CharacterImage model
   */
  readonly fields: CharacterImageFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for CharacterImage.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CharacterImageClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    character<T extends CharacterDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CharacterDefaultArgs<ExtArgs>>): Prisma__CharacterClient<$Result.GetResult<Prisma.$CharacterPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the CharacterImage model
   */
  interface CharacterImageFieldRefs {
    readonly id: FieldRef<"CharacterImage", 'String'>
    readonly characterId: FieldRef<"CharacterImage", 'String'>
    readonly filename: FieldRef<"CharacterImage", 'String'>
    readonly originalName: FieldRef<"CharacterImage", 'String'>
    readonly imageName: FieldRef<"CharacterImage", 'String'>
    readonly filePath: FieldRef<"CharacterImage", 'String'>
    readonly fileSize: FieldRef<"CharacterImage", 'Int'>
    readonly mimeType: FieldRef<"CharacterImage", 'String'>
    readonly createdAt: FieldRef<"CharacterImage", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * CharacterImage findUnique
   */
  export type CharacterImageFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * Filter, which CharacterImage to fetch.
     */
    where: CharacterImageWhereUniqueInput
  }

  /**
   * CharacterImage findUniqueOrThrow
   */
  export type CharacterImageFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * Filter, which CharacterImage to fetch.
     */
    where: CharacterImageWhereUniqueInput
  }

  /**
   * CharacterImage findFirst
   */
  export type CharacterImageFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * Filter, which CharacterImage to fetch.
     */
    where?: CharacterImageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CharacterImages to fetch.
     */
    orderBy?: CharacterImageOrderByWithRelationInput | CharacterImageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CharacterImages.
     */
    cursor?: CharacterImageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CharacterImages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CharacterImages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CharacterImages.
     */
    distinct?: CharacterImageScalarFieldEnum | CharacterImageScalarFieldEnum[]
  }

  /**
   * CharacterImage findFirstOrThrow
   */
  export type CharacterImageFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * Filter, which CharacterImage to fetch.
     */
    where?: CharacterImageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CharacterImages to fetch.
     */
    orderBy?: CharacterImageOrderByWithRelationInput | CharacterImageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CharacterImages.
     */
    cursor?: CharacterImageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CharacterImages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CharacterImages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CharacterImages.
     */
    distinct?: CharacterImageScalarFieldEnum | CharacterImageScalarFieldEnum[]
  }

  /**
   * CharacterImage findMany
   */
  export type CharacterImageFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * Filter, which CharacterImages to fetch.
     */
    where?: CharacterImageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CharacterImages to fetch.
     */
    orderBy?: CharacterImageOrderByWithRelationInput | CharacterImageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CharacterImages.
     */
    cursor?: CharacterImageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CharacterImages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CharacterImages.
     */
    skip?: number
    distinct?: CharacterImageScalarFieldEnum | CharacterImageScalarFieldEnum[]
  }

  /**
   * CharacterImage create
   */
  export type CharacterImageCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * The data needed to create a CharacterImage.
     */
    data: XOR<CharacterImageCreateInput, CharacterImageUncheckedCreateInput>
  }

  /**
   * CharacterImage createMany
   */
  export type CharacterImageCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CharacterImages.
     */
    data: CharacterImageCreateManyInput | CharacterImageCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CharacterImage createManyAndReturn
   */
  export type CharacterImageCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * The data used to create many CharacterImages.
     */
    data: CharacterImageCreateManyInput | CharacterImageCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * CharacterImage update
   */
  export type CharacterImageUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * The data needed to update a CharacterImage.
     */
    data: XOR<CharacterImageUpdateInput, CharacterImageUncheckedUpdateInput>
    /**
     * Choose, which CharacterImage to update.
     */
    where: CharacterImageWhereUniqueInput
  }

  /**
   * CharacterImage updateMany
   */
  export type CharacterImageUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CharacterImages.
     */
    data: XOR<CharacterImageUpdateManyMutationInput, CharacterImageUncheckedUpdateManyInput>
    /**
     * Filter which CharacterImages to update
     */
    where?: CharacterImageWhereInput
    /**
     * Limit how many CharacterImages to update.
     */
    limit?: number
  }

  /**
   * CharacterImage updateManyAndReturn
   */
  export type CharacterImageUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * The data used to update CharacterImages.
     */
    data: XOR<CharacterImageUpdateManyMutationInput, CharacterImageUncheckedUpdateManyInput>
    /**
     * Filter which CharacterImages to update
     */
    where?: CharacterImageWhereInput
    /**
     * Limit how many CharacterImages to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * CharacterImage upsert
   */
  export type CharacterImageUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * The filter to search for the CharacterImage to update in case it exists.
     */
    where: CharacterImageWhereUniqueInput
    /**
     * In case the CharacterImage found by the `where` argument doesn't exist, create a new CharacterImage with this data.
     */
    create: XOR<CharacterImageCreateInput, CharacterImageUncheckedCreateInput>
    /**
     * In case the CharacterImage was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CharacterImageUpdateInput, CharacterImageUncheckedUpdateInput>
  }

  /**
   * CharacterImage delete
   */
  export type CharacterImageDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
    /**
     * Filter which CharacterImage to delete.
     */
    where: CharacterImageWhereUniqueInput
  }

  /**
   * CharacterImage deleteMany
   */
  export type CharacterImageDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CharacterImages to delete
     */
    where?: CharacterImageWhereInput
    /**
     * Limit how many CharacterImages to delete.
     */
    limit?: number
  }

  /**
   * CharacterImage without action
   */
  export type CharacterImageDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CharacterImage
     */
    select?: CharacterImageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CharacterImage
     */
    omit?: CharacterImageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CharacterImageInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const CharacterScalarFieldEnum: {
    id: 'id',
    name: 'name',
    occupation: 'occupation',
    age: 'age',
    gender: 'gender',
    birthplace: 'birthplace',
    residence: 'residence',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    str: 'str',
    con: 'con',
    pow: 'pow',
    dex: 'dex',
    app: 'app',
    siz: 'siz',
    int: 'int',
    edu: 'edu',
    luck: 'luck',
    hp: 'hp',
    maxHp: 'maxHp',
    mp: 'mp',
    maxMp: 'maxMp',
    san: 'san',
    maxSan: 'maxSan',
    mov: 'mov',
    build: 'build',
    skills: 'skills'
  };

  export type CharacterScalarFieldEnum = (typeof CharacterScalarFieldEnum)[keyof typeof CharacterScalarFieldEnum]


  export const ScenarioScalarFieldEnum: {
    id: 'id',
    title: 'title',
    author: 'author',
    description: 'description',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type ScenarioScalarFieldEnum = (typeof ScenarioScalarFieldEnum)[keyof typeof ScenarioScalarFieldEnum]


  export const SessionScalarFieldEnum: {
    id: 'id',
    characterId: 'characterId',
    scenarioId: 'scenarioId',
    kpName: 'kpName',
    playDate: 'playDate',
    memo: 'memo',
    participants: 'participants',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SessionScalarFieldEnum = (typeof SessionScalarFieldEnum)[keyof typeof SessionScalarFieldEnum]


  export const SkillHistoryScalarFieldEnum: {
    id: 'id',
    characterId: 'characterId',
    sessionId: 'sessionId',
    skillName: 'skillName',
    oldValue: 'oldValue',
    newValue: 'newValue',
    reason: 'reason',
    createdAt: 'createdAt'
  };

  export type SkillHistoryScalarFieldEnum = (typeof SkillHistoryScalarFieldEnum)[keyof typeof SkillHistoryScalarFieldEnum]


  export const SanityHistoryScalarFieldEnum: {
    id: 'id',
    characterId: 'characterId',
    sessionId: 'sessionId',
    oldValue: 'oldValue',
    newValue: 'newValue',
    reason: 'reason',
    createdAt: 'createdAt'
  };

  export type SanityHistoryScalarFieldEnum = (typeof SanityHistoryScalarFieldEnum)[keyof typeof SanityHistoryScalarFieldEnum]


  export const InsanitySymptomScalarFieldEnum: {
    id: 'id',
    characterId: 'characterId',
    sessionId: 'sessionId',
    symptomType: 'symptomType',
    symptomName: 'symptomName',
    description: 'description',
    isRecovered: 'isRecovered',
    recoveredAt: 'recoveredAt',
    createdAt: 'createdAt'
  };

  export type InsanitySymptomScalarFieldEnum = (typeof InsanitySymptomScalarFieldEnum)[keyof typeof InsanitySymptomScalarFieldEnum]


  export const CharacterImageScalarFieldEnum: {
    id: 'id',
    characterId: 'characterId',
    filename: 'filename',
    originalName: 'originalName',
    imageName: 'imageName',
    filePath: 'filePath',
    fileSize: 'fileSize',
    mimeType: 'mimeType',
    createdAt: 'createdAt'
  };

  export type CharacterImageScalarFieldEnum = (typeof CharacterImageScalarFieldEnum)[keyof typeof CharacterImageScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type CharacterWhereInput = {
    AND?: CharacterWhereInput | CharacterWhereInput[]
    OR?: CharacterWhereInput[]
    NOT?: CharacterWhereInput | CharacterWhereInput[]
    id?: StringFilter<"Character"> | string
    name?: StringFilter<"Character"> | string
    occupation?: StringNullableFilter<"Character"> | string | null
    age?: IntNullableFilter<"Character"> | number | null
    gender?: StringNullableFilter<"Character"> | string | null
    birthplace?: StringNullableFilter<"Character"> | string | null
    residence?: StringNullableFilter<"Character"> | string | null
    createdAt?: DateTimeFilter<"Character"> | Date | string
    updatedAt?: DateTimeFilter<"Character"> | Date | string
    str?: IntFilter<"Character"> | number
    con?: IntFilter<"Character"> | number
    pow?: IntFilter<"Character"> | number
    dex?: IntFilter<"Character"> | number
    app?: IntFilter<"Character"> | number
    siz?: IntFilter<"Character"> | number
    int?: IntFilter<"Character"> | number
    edu?: IntFilter<"Character"> | number
    luck?: IntFilter<"Character"> | number
    hp?: IntFilter<"Character"> | number
    maxHp?: IntFilter<"Character"> | number
    mp?: IntFilter<"Character"> | number
    maxMp?: IntFilter<"Character"> | number
    san?: IntFilter<"Character"> | number
    maxSan?: IntFilter<"Character"> | number
    mov?: IntFilter<"Character"> | number
    build?: IntFilter<"Character"> | number
    skills?: StringFilter<"Character"> | string
    sessions?: SessionListRelationFilter
    skillHistories?: SkillHistoryListRelationFilter
    sanityHistories?: SanityHistoryListRelationFilter
    insanitySymptoms?: InsanitySymptomListRelationFilter
    images?: CharacterImageListRelationFilter
  }

  export type CharacterOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    occupation?: SortOrderInput | SortOrder
    age?: SortOrderInput | SortOrder
    gender?: SortOrderInput | SortOrder
    birthplace?: SortOrderInput | SortOrder
    residence?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    str?: SortOrder
    con?: SortOrder
    pow?: SortOrder
    dex?: SortOrder
    app?: SortOrder
    siz?: SortOrder
    int?: SortOrder
    edu?: SortOrder
    luck?: SortOrder
    hp?: SortOrder
    maxHp?: SortOrder
    mp?: SortOrder
    maxMp?: SortOrder
    san?: SortOrder
    maxSan?: SortOrder
    mov?: SortOrder
    build?: SortOrder
    skills?: SortOrder
    sessions?: SessionOrderByRelationAggregateInput
    skillHistories?: SkillHistoryOrderByRelationAggregateInput
    sanityHistories?: SanityHistoryOrderByRelationAggregateInput
    insanitySymptoms?: InsanitySymptomOrderByRelationAggregateInput
    images?: CharacterImageOrderByRelationAggregateInput
  }

  export type CharacterWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: CharacterWhereInput | CharacterWhereInput[]
    OR?: CharacterWhereInput[]
    NOT?: CharacterWhereInput | CharacterWhereInput[]
    name?: StringFilter<"Character"> | string
    occupation?: StringNullableFilter<"Character"> | string | null
    age?: IntNullableFilter<"Character"> | number | null
    gender?: StringNullableFilter<"Character"> | string | null
    birthplace?: StringNullableFilter<"Character"> | string | null
    residence?: StringNullableFilter<"Character"> | string | null
    createdAt?: DateTimeFilter<"Character"> | Date | string
    updatedAt?: DateTimeFilter<"Character"> | Date | string
    str?: IntFilter<"Character"> | number
    con?: IntFilter<"Character"> | number
    pow?: IntFilter<"Character"> | number
    dex?: IntFilter<"Character"> | number
    app?: IntFilter<"Character"> | number
    siz?: IntFilter<"Character"> | number
    int?: IntFilter<"Character"> | number
    edu?: IntFilter<"Character"> | number
    luck?: IntFilter<"Character"> | number
    hp?: IntFilter<"Character"> | number
    maxHp?: IntFilter<"Character"> | number
    mp?: IntFilter<"Character"> | number
    maxMp?: IntFilter<"Character"> | number
    san?: IntFilter<"Character"> | number
    maxSan?: IntFilter<"Character"> | number
    mov?: IntFilter<"Character"> | number
    build?: IntFilter<"Character"> | number
    skills?: StringFilter<"Character"> | string
    sessions?: SessionListRelationFilter
    skillHistories?: SkillHistoryListRelationFilter
    sanityHistories?: SanityHistoryListRelationFilter
    insanitySymptoms?: InsanitySymptomListRelationFilter
    images?: CharacterImageListRelationFilter
  }, "id">

  export type CharacterOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    occupation?: SortOrderInput | SortOrder
    age?: SortOrderInput | SortOrder
    gender?: SortOrderInput | SortOrder
    birthplace?: SortOrderInput | SortOrder
    residence?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    str?: SortOrder
    con?: SortOrder
    pow?: SortOrder
    dex?: SortOrder
    app?: SortOrder
    siz?: SortOrder
    int?: SortOrder
    edu?: SortOrder
    luck?: SortOrder
    hp?: SortOrder
    maxHp?: SortOrder
    mp?: SortOrder
    maxMp?: SortOrder
    san?: SortOrder
    maxSan?: SortOrder
    mov?: SortOrder
    build?: SortOrder
    skills?: SortOrder
    _count?: CharacterCountOrderByAggregateInput
    _avg?: CharacterAvgOrderByAggregateInput
    _max?: CharacterMaxOrderByAggregateInput
    _min?: CharacterMinOrderByAggregateInput
    _sum?: CharacterSumOrderByAggregateInput
  }

  export type CharacterScalarWhereWithAggregatesInput = {
    AND?: CharacterScalarWhereWithAggregatesInput | CharacterScalarWhereWithAggregatesInput[]
    OR?: CharacterScalarWhereWithAggregatesInput[]
    NOT?: CharacterScalarWhereWithAggregatesInput | CharacterScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Character"> | string
    name?: StringWithAggregatesFilter<"Character"> | string
    occupation?: StringNullableWithAggregatesFilter<"Character"> | string | null
    age?: IntNullableWithAggregatesFilter<"Character"> | number | null
    gender?: StringNullableWithAggregatesFilter<"Character"> | string | null
    birthplace?: StringNullableWithAggregatesFilter<"Character"> | string | null
    residence?: StringNullableWithAggregatesFilter<"Character"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Character"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Character"> | Date | string
    str?: IntWithAggregatesFilter<"Character"> | number
    con?: IntWithAggregatesFilter<"Character"> | number
    pow?: IntWithAggregatesFilter<"Character"> | number
    dex?: IntWithAggregatesFilter<"Character"> | number
    app?: IntWithAggregatesFilter<"Character"> | number
    siz?: IntWithAggregatesFilter<"Character"> | number
    int?: IntWithAggregatesFilter<"Character"> | number
    edu?: IntWithAggregatesFilter<"Character"> | number
    luck?: IntWithAggregatesFilter<"Character"> | number
    hp?: IntWithAggregatesFilter<"Character"> | number
    maxHp?: IntWithAggregatesFilter<"Character"> | number
    mp?: IntWithAggregatesFilter<"Character"> | number
    maxMp?: IntWithAggregatesFilter<"Character"> | number
    san?: IntWithAggregatesFilter<"Character"> | number
    maxSan?: IntWithAggregatesFilter<"Character"> | number
    mov?: IntWithAggregatesFilter<"Character"> | number
    build?: IntWithAggregatesFilter<"Character"> | number
    skills?: StringWithAggregatesFilter<"Character"> | string
  }

  export type ScenarioWhereInput = {
    AND?: ScenarioWhereInput | ScenarioWhereInput[]
    OR?: ScenarioWhereInput[]
    NOT?: ScenarioWhereInput | ScenarioWhereInput[]
    id?: StringFilter<"Scenario"> | string
    title?: StringFilter<"Scenario"> | string
    author?: StringNullableFilter<"Scenario"> | string | null
    description?: StringNullableFilter<"Scenario"> | string | null
    createdAt?: DateTimeFilter<"Scenario"> | Date | string
    updatedAt?: DateTimeFilter<"Scenario"> | Date | string
    sessions?: SessionListRelationFilter
  }

  export type ScenarioOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    author?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    sessions?: SessionOrderByRelationAggregateInput
  }

  export type ScenarioWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ScenarioWhereInput | ScenarioWhereInput[]
    OR?: ScenarioWhereInput[]
    NOT?: ScenarioWhereInput | ScenarioWhereInput[]
    title?: StringFilter<"Scenario"> | string
    author?: StringNullableFilter<"Scenario"> | string | null
    description?: StringNullableFilter<"Scenario"> | string | null
    createdAt?: DateTimeFilter<"Scenario"> | Date | string
    updatedAt?: DateTimeFilter<"Scenario"> | Date | string
    sessions?: SessionListRelationFilter
  }, "id">

  export type ScenarioOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    author?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: ScenarioCountOrderByAggregateInput
    _max?: ScenarioMaxOrderByAggregateInput
    _min?: ScenarioMinOrderByAggregateInput
  }

  export type ScenarioScalarWhereWithAggregatesInput = {
    AND?: ScenarioScalarWhereWithAggregatesInput | ScenarioScalarWhereWithAggregatesInput[]
    OR?: ScenarioScalarWhereWithAggregatesInput[]
    NOT?: ScenarioScalarWhereWithAggregatesInput | ScenarioScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Scenario"> | string
    title?: StringWithAggregatesFilter<"Scenario"> | string
    author?: StringNullableWithAggregatesFilter<"Scenario"> | string | null
    description?: StringNullableWithAggregatesFilter<"Scenario"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Scenario"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Scenario"> | Date | string
  }

  export type SessionWhereInput = {
    AND?: SessionWhereInput | SessionWhereInput[]
    OR?: SessionWhereInput[]
    NOT?: SessionWhereInput | SessionWhereInput[]
    id?: StringFilter<"Session"> | string
    characterId?: StringFilter<"Session"> | string
    scenarioId?: StringFilter<"Session"> | string
    kpName?: StringNullableFilter<"Session"> | string | null
    playDate?: DateTimeFilter<"Session"> | Date | string
    memo?: StringNullableFilter<"Session"> | string | null
    participants?: StringNullableFilter<"Session"> | string | null
    createdAt?: DateTimeFilter<"Session"> | Date | string
    updatedAt?: DateTimeFilter<"Session"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    scenario?: XOR<ScenarioScalarRelationFilter, ScenarioWhereInput>
    skillHistories?: SkillHistoryListRelationFilter
    sanityHistories?: SanityHistoryListRelationFilter
    insanitySymptoms?: InsanitySymptomListRelationFilter
  }

  export type SessionOrderByWithRelationInput = {
    id?: SortOrder
    characterId?: SortOrder
    scenarioId?: SortOrder
    kpName?: SortOrderInput | SortOrder
    playDate?: SortOrder
    memo?: SortOrderInput | SortOrder
    participants?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    character?: CharacterOrderByWithRelationInput
    scenario?: ScenarioOrderByWithRelationInput
    skillHistories?: SkillHistoryOrderByRelationAggregateInput
    sanityHistories?: SanityHistoryOrderByRelationAggregateInput
    insanitySymptoms?: InsanitySymptomOrderByRelationAggregateInput
  }

  export type SessionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: SessionWhereInput | SessionWhereInput[]
    OR?: SessionWhereInput[]
    NOT?: SessionWhereInput | SessionWhereInput[]
    characterId?: StringFilter<"Session"> | string
    scenarioId?: StringFilter<"Session"> | string
    kpName?: StringNullableFilter<"Session"> | string | null
    playDate?: DateTimeFilter<"Session"> | Date | string
    memo?: StringNullableFilter<"Session"> | string | null
    participants?: StringNullableFilter<"Session"> | string | null
    createdAt?: DateTimeFilter<"Session"> | Date | string
    updatedAt?: DateTimeFilter<"Session"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    scenario?: XOR<ScenarioScalarRelationFilter, ScenarioWhereInput>
    skillHistories?: SkillHistoryListRelationFilter
    sanityHistories?: SanityHistoryListRelationFilter
    insanitySymptoms?: InsanitySymptomListRelationFilter
  }, "id">

  export type SessionOrderByWithAggregationInput = {
    id?: SortOrder
    characterId?: SortOrder
    scenarioId?: SortOrder
    kpName?: SortOrderInput | SortOrder
    playDate?: SortOrder
    memo?: SortOrderInput | SortOrder
    participants?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SessionCountOrderByAggregateInput
    _max?: SessionMaxOrderByAggregateInput
    _min?: SessionMinOrderByAggregateInput
  }

  export type SessionScalarWhereWithAggregatesInput = {
    AND?: SessionScalarWhereWithAggregatesInput | SessionScalarWhereWithAggregatesInput[]
    OR?: SessionScalarWhereWithAggregatesInput[]
    NOT?: SessionScalarWhereWithAggregatesInput | SessionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Session"> | string
    characterId?: StringWithAggregatesFilter<"Session"> | string
    scenarioId?: StringWithAggregatesFilter<"Session"> | string
    kpName?: StringNullableWithAggregatesFilter<"Session"> | string | null
    playDate?: DateTimeWithAggregatesFilter<"Session"> | Date | string
    memo?: StringNullableWithAggregatesFilter<"Session"> | string | null
    participants?: StringNullableWithAggregatesFilter<"Session"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Session"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Session"> | Date | string
  }

  export type SkillHistoryWhereInput = {
    AND?: SkillHistoryWhereInput | SkillHistoryWhereInput[]
    OR?: SkillHistoryWhereInput[]
    NOT?: SkillHistoryWhereInput | SkillHistoryWhereInput[]
    id?: StringFilter<"SkillHistory"> | string
    characterId?: StringFilter<"SkillHistory"> | string
    sessionId?: StringNullableFilter<"SkillHistory"> | string | null
    skillName?: StringFilter<"SkillHistory"> | string
    oldValue?: IntFilter<"SkillHistory"> | number
    newValue?: IntFilter<"SkillHistory"> | number
    reason?: StringNullableFilter<"SkillHistory"> | string | null
    createdAt?: DateTimeFilter<"SkillHistory"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    session?: XOR<SessionNullableScalarRelationFilter, SessionWhereInput> | null
  }

  export type SkillHistoryOrderByWithRelationInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrderInput | SortOrder
    skillName?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    character?: CharacterOrderByWithRelationInput
    session?: SessionOrderByWithRelationInput
  }

  export type SkillHistoryWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: SkillHistoryWhereInput | SkillHistoryWhereInput[]
    OR?: SkillHistoryWhereInput[]
    NOT?: SkillHistoryWhereInput | SkillHistoryWhereInput[]
    characterId?: StringFilter<"SkillHistory"> | string
    sessionId?: StringNullableFilter<"SkillHistory"> | string | null
    skillName?: StringFilter<"SkillHistory"> | string
    oldValue?: IntFilter<"SkillHistory"> | number
    newValue?: IntFilter<"SkillHistory"> | number
    reason?: StringNullableFilter<"SkillHistory"> | string | null
    createdAt?: DateTimeFilter<"SkillHistory"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    session?: XOR<SessionNullableScalarRelationFilter, SessionWhereInput> | null
  }, "id">

  export type SkillHistoryOrderByWithAggregationInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrderInput | SortOrder
    skillName?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: SkillHistoryCountOrderByAggregateInput
    _avg?: SkillHistoryAvgOrderByAggregateInput
    _max?: SkillHistoryMaxOrderByAggregateInput
    _min?: SkillHistoryMinOrderByAggregateInput
    _sum?: SkillHistorySumOrderByAggregateInput
  }

  export type SkillHistoryScalarWhereWithAggregatesInput = {
    AND?: SkillHistoryScalarWhereWithAggregatesInput | SkillHistoryScalarWhereWithAggregatesInput[]
    OR?: SkillHistoryScalarWhereWithAggregatesInput[]
    NOT?: SkillHistoryScalarWhereWithAggregatesInput | SkillHistoryScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"SkillHistory"> | string
    characterId?: StringWithAggregatesFilter<"SkillHistory"> | string
    sessionId?: StringNullableWithAggregatesFilter<"SkillHistory"> | string | null
    skillName?: StringWithAggregatesFilter<"SkillHistory"> | string
    oldValue?: IntWithAggregatesFilter<"SkillHistory"> | number
    newValue?: IntWithAggregatesFilter<"SkillHistory"> | number
    reason?: StringNullableWithAggregatesFilter<"SkillHistory"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"SkillHistory"> | Date | string
  }

  export type SanityHistoryWhereInput = {
    AND?: SanityHistoryWhereInput | SanityHistoryWhereInput[]
    OR?: SanityHistoryWhereInput[]
    NOT?: SanityHistoryWhereInput | SanityHistoryWhereInput[]
    id?: StringFilter<"SanityHistory"> | string
    characterId?: StringFilter<"SanityHistory"> | string
    sessionId?: StringNullableFilter<"SanityHistory"> | string | null
    oldValue?: IntFilter<"SanityHistory"> | number
    newValue?: IntFilter<"SanityHistory"> | number
    reason?: StringFilter<"SanityHistory"> | string
    createdAt?: DateTimeFilter<"SanityHistory"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    session?: XOR<SessionNullableScalarRelationFilter, SessionWhereInput> | null
  }

  export type SanityHistoryOrderByWithRelationInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrderInput | SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
    character?: CharacterOrderByWithRelationInput
    session?: SessionOrderByWithRelationInput
  }

  export type SanityHistoryWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: SanityHistoryWhereInput | SanityHistoryWhereInput[]
    OR?: SanityHistoryWhereInput[]
    NOT?: SanityHistoryWhereInput | SanityHistoryWhereInput[]
    characterId?: StringFilter<"SanityHistory"> | string
    sessionId?: StringNullableFilter<"SanityHistory"> | string | null
    oldValue?: IntFilter<"SanityHistory"> | number
    newValue?: IntFilter<"SanityHistory"> | number
    reason?: StringFilter<"SanityHistory"> | string
    createdAt?: DateTimeFilter<"SanityHistory"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    session?: XOR<SessionNullableScalarRelationFilter, SessionWhereInput> | null
  }, "id">

  export type SanityHistoryOrderByWithAggregationInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrderInput | SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
    _count?: SanityHistoryCountOrderByAggregateInput
    _avg?: SanityHistoryAvgOrderByAggregateInput
    _max?: SanityHistoryMaxOrderByAggregateInput
    _min?: SanityHistoryMinOrderByAggregateInput
    _sum?: SanityHistorySumOrderByAggregateInput
  }

  export type SanityHistoryScalarWhereWithAggregatesInput = {
    AND?: SanityHistoryScalarWhereWithAggregatesInput | SanityHistoryScalarWhereWithAggregatesInput[]
    OR?: SanityHistoryScalarWhereWithAggregatesInput[]
    NOT?: SanityHistoryScalarWhereWithAggregatesInput | SanityHistoryScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"SanityHistory"> | string
    characterId?: StringWithAggregatesFilter<"SanityHistory"> | string
    sessionId?: StringNullableWithAggregatesFilter<"SanityHistory"> | string | null
    oldValue?: IntWithAggregatesFilter<"SanityHistory"> | number
    newValue?: IntWithAggregatesFilter<"SanityHistory"> | number
    reason?: StringWithAggregatesFilter<"SanityHistory"> | string
    createdAt?: DateTimeWithAggregatesFilter<"SanityHistory"> | Date | string
  }

  export type InsanitySymptomWhereInput = {
    AND?: InsanitySymptomWhereInput | InsanitySymptomWhereInput[]
    OR?: InsanitySymptomWhereInput[]
    NOT?: InsanitySymptomWhereInput | InsanitySymptomWhereInput[]
    id?: StringFilter<"InsanitySymptom"> | string
    characterId?: StringFilter<"InsanitySymptom"> | string
    sessionId?: StringNullableFilter<"InsanitySymptom"> | string | null
    symptomType?: StringFilter<"InsanitySymptom"> | string
    symptomName?: StringFilter<"InsanitySymptom"> | string
    description?: StringNullableFilter<"InsanitySymptom"> | string | null
    isRecovered?: BoolFilter<"InsanitySymptom"> | boolean
    recoveredAt?: DateTimeNullableFilter<"InsanitySymptom"> | Date | string | null
    createdAt?: DateTimeFilter<"InsanitySymptom"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    session?: XOR<SessionNullableScalarRelationFilter, SessionWhereInput> | null
  }

  export type InsanitySymptomOrderByWithRelationInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrderInput | SortOrder
    symptomType?: SortOrder
    symptomName?: SortOrder
    description?: SortOrderInput | SortOrder
    isRecovered?: SortOrder
    recoveredAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    character?: CharacterOrderByWithRelationInput
    session?: SessionOrderByWithRelationInput
  }

  export type InsanitySymptomWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: InsanitySymptomWhereInput | InsanitySymptomWhereInput[]
    OR?: InsanitySymptomWhereInput[]
    NOT?: InsanitySymptomWhereInput | InsanitySymptomWhereInput[]
    characterId?: StringFilter<"InsanitySymptom"> | string
    sessionId?: StringNullableFilter<"InsanitySymptom"> | string | null
    symptomType?: StringFilter<"InsanitySymptom"> | string
    symptomName?: StringFilter<"InsanitySymptom"> | string
    description?: StringNullableFilter<"InsanitySymptom"> | string | null
    isRecovered?: BoolFilter<"InsanitySymptom"> | boolean
    recoveredAt?: DateTimeNullableFilter<"InsanitySymptom"> | Date | string | null
    createdAt?: DateTimeFilter<"InsanitySymptom"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
    session?: XOR<SessionNullableScalarRelationFilter, SessionWhereInput> | null
  }, "id">

  export type InsanitySymptomOrderByWithAggregationInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrderInput | SortOrder
    symptomType?: SortOrder
    symptomName?: SortOrder
    description?: SortOrderInput | SortOrder
    isRecovered?: SortOrder
    recoveredAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: InsanitySymptomCountOrderByAggregateInput
    _max?: InsanitySymptomMaxOrderByAggregateInput
    _min?: InsanitySymptomMinOrderByAggregateInput
  }

  export type InsanitySymptomScalarWhereWithAggregatesInput = {
    AND?: InsanitySymptomScalarWhereWithAggregatesInput | InsanitySymptomScalarWhereWithAggregatesInput[]
    OR?: InsanitySymptomScalarWhereWithAggregatesInput[]
    NOT?: InsanitySymptomScalarWhereWithAggregatesInput | InsanitySymptomScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"InsanitySymptom"> | string
    characterId?: StringWithAggregatesFilter<"InsanitySymptom"> | string
    sessionId?: StringNullableWithAggregatesFilter<"InsanitySymptom"> | string | null
    symptomType?: StringWithAggregatesFilter<"InsanitySymptom"> | string
    symptomName?: StringWithAggregatesFilter<"InsanitySymptom"> | string
    description?: StringNullableWithAggregatesFilter<"InsanitySymptom"> | string | null
    isRecovered?: BoolWithAggregatesFilter<"InsanitySymptom"> | boolean
    recoveredAt?: DateTimeNullableWithAggregatesFilter<"InsanitySymptom"> | Date | string | null
    createdAt?: DateTimeWithAggregatesFilter<"InsanitySymptom"> | Date | string
  }

  export type CharacterImageWhereInput = {
    AND?: CharacterImageWhereInput | CharacterImageWhereInput[]
    OR?: CharacterImageWhereInput[]
    NOT?: CharacterImageWhereInput | CharacterImageWhereInput[]
    id?: StringFilter<"CharacterImage"> | string
    characterId?: StringFilter<"CharacterImage"> | string
    filename?: StringFilter<"CharacterImage"> | string
    originalName?: StringFilter<"CharacterImage"> | string
    imageName?: StringNullableFilter<"CharacterImage"> | string | null
    filePath?: StringFilter<"CharacterImage"> | string
    fileSize?: IntFilter<"CharacterImage"> | number
    mimeType?: StringFilter<"CharacterImage"> | string
    createdAt?: DateTimeFilter<"CharacterImage"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
  }

  export type CharacterImageOrderByWithRelationInput = {
    id?: SortOrder
    characterId?: SortOrder
    filename?: SortOrder
    originalName?: SortOrder
    imageName?: SortOrderInput | SortOrder
    filePath?: SortOrder
    fileSize?: SortOrder
    mimeType?: SortOrder
    createdAt?: SortOrder
    character?: CharacterOrderByWithRelationInput
  }

  export type CharacterImageWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: CharacterImageWhereInput | CharacterImageWhereInput[]
    OR?: CharacterImageWhereInput[]
    NOT?: CharacterImageWhereInput | CharacterImageWhereInput[]
    characterId?: StringFilter<"CharacterImage"> | string
    filename?: StringFilter<"CharacterImage"> | string
    originalName?: StringFilter<"CharacterImage"> | string
    imageName?: StringNullableFilter<"CharacterImage"> | string | null
    filePath?: StringFilter<"CharacterImage"> | string
    fileSize?: IntFilter<"CharacterImage"> | number
    mimeType?: StringFilter<"CharacterImage"> | string
    createdAt?: DateTimeFilter<"CharacterImage"> | Date | string
    character?: XOR<CharacterScalarRelationFilter, CharacterWhereInput>
  }, "id">

  export type CharacterImageOrderByWithAggregationInput = {
    id?: SortOrder
    characterId?: SortOrder
    filename?: SortOrder
    originalName?: SortOrder
    imageName?: SortOrderInput | SortOrder
    filePath?: SortOrder
    fileSize?: SortOrder
    mimeType?: SortOrder
    createdAt?: SortOrder
    _count?: CharacterImageCountOrderByAggregateInput
    _avg?: CharacterImageAvgOrderByAggregateInput
    _max?: CharacterImageMaxOrderByAggregateInput
    _min?: CharacterImageMinOrderByAggregateInput
    _sum?: CharacterImageSumOrderByAggregateInput
  }

  export type CharacterImageScalarWhereWithAggregatesInput = {
    AND?: CharacterImageScalarWhereWithAggregatesInput | CharacterImageScalarWhereWithAggregatesInput[]
    OR?: CharacterImageScalarWhereWithAggregatesInput[]
    NOT?: CharacterImageScalarWhereWithAggregatesInput | CharacterImageScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"CharacterImage"> | string
    characterId?: StringWithAggregatesFilter<"CharacterImage"> | string
    filename?: StringWithAggregatesFilter<"CharacterImage"> | string
    originalName?: StringWithAggregatesFilter<"CharacterImage"> | string
    imageName?: StringNullableWithAggregatesFilter<"CharacterImage"> | string | null
    filePath?: StringWithAggregatesFilter<"CharacterImage"> | string
    fileSize?: IntWithAggregatesFilter<"CharacterImage"> | number
    mimeType?: StringWithAggregatesFilter<"CharacterImage"> | string
    createdAt?: DateTimeWithAggregatesFilter<"CharacterImage"> | Date | string
  }

  export type CharacterCreateInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutCharacterInput
    images?: CharacterImageCreateNestedManyWithoutCharacterInput
  }

  export type CharacterUncheckedCreateInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionUncheckedCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutCharacterInput
    images?: CharacterImageUncheckedCreateNestedManyWithoutCharacterInput
  }

  export type CharacterUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUpdateManyWithoutCharacterNestedInput
  }

  export type CharacterUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUncheckedUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUncheckedUpdateManyWithoutCharacterNestedInput
  }

  export type CharacterCreateManyInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
  }

  export type CharacterUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
  }

  export type CharacterUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
  }

  export type ScenarioCreateInput = {
    id?: string
    title: string
    author?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    sessions?: SessionCreateNestedManyWithoutScenarioInput
  }

  export type ScenarioUncheckedCreateInput = {
    id?: string
    title: string
    author?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    sessions?: SessionUncheckedCreateNestedManyWithoutScenarioInput
  }

  export type ScenarioUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    author?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    sessions?: SessionUpdateManyWithoutScenarioNestedInput
  }

  export type ScenarioUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    author?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    sessions?: SessionUncheckedUpdateManyWithoutScenarioNestedInput
  }

  export type ScenarioCreateManyInput = {
    id?: string
    title: string
    author?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ScenarioUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    author?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ScenarioUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    author?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionCreateInput = {
    id?: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    character: CharacterCreateNestedOneWithoutSessionsInput
    scenario: ScenarioCreateNestedOneWithoutSessionsInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutSessionInput
  }

  export type SessionUncheckedCreateInput = {
    id?: string
    characterId: string
    scenarioId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutSessionInput
  }

  export type SessionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSessionsNestedInput
    scenario?: ScenarioUpdateOneRequiredWithoutSessionsNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    scenarioId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type SessionCreateManyInput = {
    id?: string
    characterId: string
    scenarioId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SessionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    scenarioId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryCreateInput = {
    id?: string
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
    character: CharacterCreateNestedOneWithoutSkillHistoriesInput
    session?: SessionCreateNestedOneWithoutSkillHistoriesInput
  }

  export type SkillHistoryUncheckedCreateInput = {
    id?: string
    characterId: string
    sessionId?: string | null
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
  }

  export type SkillHistoryUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSkillHistoriesNestedInput
    session?: SessionUpdateOneWithoutSkillHistoriesNestedInput
  }

  export type SkillHistoryUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryCreateManyInput = {
    id?: string
    characterId: string
    sessionId?: string | null
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
  }

  export type SkillHistoryUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SanityHistoryCreateInput = {
    id?: string
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
    character: CharacterCreateNestedOneWithoutSanityHistoriesInput
    session?: SessionCreateNestedOneWithoutSanityHistoriesInput
  }

  export type SanityHistoryUncheckedCreateInput = {
    id?: string
    characterId: string
    sessionId?: string | null
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
  }

  export type SanityHistoryUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSanityHistoriesNestedInput
    session?: SessionUpdateOneWithoutSanityHistoriesNestedInput
  }

  export type SanityHistoryUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SanityHistoryCreateManyInput = {
    id?: string
    characterId: string
    sessionId?: string | null
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
  }

  export type SanityHistoryUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SanityHistoryUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InsanitySymptomCreateInput = {
    id?: string
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
    character: CharacterCreateNestedOneWithoutInsanitySymptomsInput
    session?: SessionCreateNestedOneWithoutInsanitySymptomsInput
  }

  export type InsanitySymptomUncheckedCreateInput = {
    id?: string
    characterId: string
    sessionId?: string | null
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
  }

  export type InsanitySymptomUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutInsanitySymptomsNestedInput
    session?: SessionUpdateOneWithoutInsanitySymptomsNestedInput
  }

  export type InsanitySymptomUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InsanitySymptomCreateManyInput = {
    id?: string
    characterId: string
    sessionId?: string | null
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
  }

  export type InsanitySymptomUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InsanitySymptomUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CharacterImageCreateInput = {
    id?: string
    filename: string
    originalName: string
    imageName?: string | null
    filePath: string
    fileSize: number
    mimeType: string
    createdAt?: Date | string
    character: CharacterCreateNestedOneWithoutImagesInput
  }

  export type CharacterImageUncheckedCreateInput = {
    id?: string
    characterId: string
    filename: string
    originalName: string
    imageName?: string | null
    filePath: string
    fileSize: number
    mimeType: string
    createdAt?: Date | string
  }

  export type CharacterImageUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    filename?: StringFieldUpdateOperationsInput | string
    originalName?: StringFieldUpdateOperationsInput | string
    imageName?: NullableStringFieldUpdateOperationsInput | string | null
    filePath?: StringFieldUpdateOperationsInput | string
    fileSize?: IntFieldUpdateOperationsInput | number
    mimeType?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutImagesNestedInput
  }

  export type CharacterImageUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    filename?: StringFieldUpdateOperationsInput | string
    originalName?: StringFieldUpdateOperationsInput | string
    imageName?: NullableStringFieldUpdateOperationsInput | string | null
    filePath?: StringFieldUpdateOperationsInput | string
    fileSize?: IntFieldUpdateOperationsInput | number
    mimeType?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CharacterImageCreateManyInput = {
    id?: string
    characterId: string
    filename: string
    originalName: string
    imageName?: string | null
    filePath: string
    fileSize: number
    mimeType: string
    createdAt?: Date | string
  }

  export type CharacterImageUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    filename?: StringFieldUpdateOperationsInput | string
    originalName?: StringFieldUpdateOperationsInput | string
    imageName?: NullableStringFieldUpdateOperationsInput | string | null
    filePath?: StringFieldUpdateOperationsInput | string
    fileSize?: IntFieldUpdateOperationsInput | number
    mimeType?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CharacterImageUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    filename?: StringFieldUpdateOperationsInput | string
    originalName?: StringFieldUpdateOperationsInput | string
    imageName?: NullableStringFieldUpdateOperationsInput | string | null
    filePath?: StringFieldUpdateOperationsInput | string
    fileSize?: IntFieldUpdateOperationsInput | number
    mimeType?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type SessionListRelationFilter = {
    every?: SessionWhereInput
    some?: SessionWhereInput
    none?: SessionWhereInput
  }

  export type SkillHistoryListRelationFilter = {
    every?: SkillHistoryWhereInput
    some?: SkillHistoryWhereInput
    none?: SkillHistoryWhereInput
  }

  export type SanityHistoryListRelationFilter = {
    every?: SanityHistoryWhereInput
    some?: SanityHistoryWhereInput
    none?: SanityHistoryWhereInput
  }

  export type InsanitySymptomListRelationFilter = {
    every?: InsanitySymptomWhereInput
    some?: InsanitySymptomWhereInput
    none?: InsanitySymptomWhereInput
  }

  export type CharacterImageListRelationFilter = {
    every?: CharacterImageWhereInput
    some?: CharacterImageWhereInput
    none?: CharacterImageWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type SessionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SkillHistoryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SanityHistoryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type InsanitySymptomOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CharacterImageOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CharacterCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    occupation?: SortOrder
    age?: SortOrder
    gender?: SortOrder
    birthplace?: SortOrder
    residence?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    str?: SortOrder
    con?: SortOrder
    pow?: SortOrder
    dex?: SortOrder
    app?: SortOrder
    siz?: SortOrder
    int?: SortOrder
    edu?: SortOrder
    luck?: SortOrder
    hp?: SortOrder
    maxHp?: SortOrder
    mp?: SortOrder
    maxMp?: SortOrder
    san?: SortOrder
    maxSan?: SortOrder
    mov?: SortOrder
    build?: SortOrder
    skills?: SortOrder
  }

  export type CharacterAvgOrderByAggregateInput = {
    age?: SortOrder
    str?: SortOrder
    con?: SortOrder
    pow?: SortOrder
    dex?: SortOrder
    app?: SortOrder
    siz?: SortOrder
    int?: SortOrder
    edu?: SortOrder
    luck?: SortOrder
    hp?: SortOrder
    maxHp?: SortOrder
    mp?: SortOrder
    maxMp?: SortOrder
    san?: SortOrder
    maxSan?: SortOrder
    mov?: SortOrder
    build?: SortOrder
  }

  export type CharacterMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    occupation?: SortOrder
    age?: SortOrder
    gender?: SortOrder
    birthplace?: SortOrder
    residence?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    str?: SortOrder
    con?: SortOrder
    pow?: SortOrder
    dex?: SortOrder
    app?: SortOrder
    siz?: SortOrder
    int?: SortOrder
    edu?: SortOrder
    luck?: SortOrder
    hp?: SortOrder
    maxHp?: SortOrder
    mp?: SortOrder
    maxMp?: SortOrder
    san?: SortOrder
    maxSan?: SortOrder
    mov?: SortOrder
    build?: SortOrder
    skills?: SortOrder
  }

  export type CharacterMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    occupation?: SortOrder
    age?: SortOrder
    gender?: SortOrder
    birthplace?: SortOrder
    residence?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    str?: SortOrder
    con?: SortOrder
    pow?: SortOrder
    dex?: SortOrder
    app?: SortOrder
    siz?: SortOrder
    int?: SortOrder
    edu?: SortOrder
    luck?: SortOrder
    hp?: SortOrder
    maxHp?: SortOrder
    mp?: SortOrder
    maxMp?: SortOrder
    san?: SortOrder
    maxSan?: SortOrder
    mov?: SortOrder
    build?: SortOrder
    skills?: SortOrder
  }

  export type CharacterSumOrderByAggregateInput = {
    age?: SortOrder
    str?: SortOrder
    con?: SortOrder
    pow?: SortOrder
    dex?: SortOrder
    app?: SortOrder
    siz?: SortOrder
    int?: SortOrder
    edu?: SortOrder
    luck?: SortOrder
    hp?: SortOrder
    maxHp?: SortOrder
    mp?: SortOrder
    maxMp?: SortOrder
    san?: SortOrder
    maxSan?: SortOrder
    mov?: SortOrder
    build?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type ScenarioCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    author?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ScenarioMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    author?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ScenarioMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    author?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CharacterScalarRelationFilter = {
    is?: CharacterWhereInput
    isNot?: CharacterWhereInput
  }

  export type ScenarioScalarRelationFilter = {
    is?: ScenarioWhereInput
    isNot?: ScenarioWhereInput
  }

  export type SessionCountOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    scenarioId?: SortOrder
    kpName?: SortOrder
    playDate?: SortOrder
    memo?: SortOrder
    participants?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SessionMaxOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    scenarioId?: SortOrder
    kpName?: SortOrder
    playDate?: SortOrder
    memo?: SortOrder
    participants?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SessionMinOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    scenarioId?: SortOrder
    kpName?: SortOrder
    playDate?: SortOrder
    memo?: SortOrder
    participants?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SessionNullableScalarRelationFilter = {
    is?: SessionWhereInput | null
    isNot?: SessionWhereInput | null
  }

  export type SkillHistoryCountOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    skillName?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
  }

  export type SkillHistoryAvgOrderByAggregateInput = {
    oldValue?: SortOrder
    newValue?: SortOrder
  }

  export type SkillHistoryMaxOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    skillName?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
  }

  export type SkillHistoryMinOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    skillName?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
  }

  export type SkillHistorySumOrderByAggregateInput = {
    oldValue?: SortOrder
    newValue?: SortOrder
  }

  export type SanityHistoryCountOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
  }

  export type SanityHistoryAvgOrderByAggregateInput = {
    oldValue?: SortOrder
    newValue?: SortOrder
  }

  export type SanityHistoryMaxOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
  }

  export type SanityHistoryMinOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    oldValue?: SortOrder
    newValue?: SortOrder
    reason?: SortOrder
    createdAt?: SortOrder
  }

  export type SanityHistorySumOrderByAggregateInput = {
    oldValue?: SortOrder
    newValue?: SortOrder
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type InsanitySymptomCountOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    symptomType?: SortOrder
    symptomName?: SortOrder
    description?: SortOrder
    isRecovered?: SortOrder
    recoveredAt?: SortOrder
    createdAt?: SortOrder
  }

  export type InsanitySymptomMaxOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    symptomType?: SortOrder
    symptomName?: SortOrder
    description?: SortOrder
    isRecovered?: SortOrder
    recoveredAt?: SortOrder
    createdAt?: SortOrder
  }

  export type InsanitySymptomMinOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    sessionId?: SortOrder
    symptomType?: SortOrder
    symptomName?: SortOrder
    description?: SortOrder
    isRecovered?: SortOrder
    recoveredAt?: SortOrder
    createdAt?: SortOrder
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type CharacterImageCountOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    filename?: SortOrder
    originalName?: SortOrder
    imageName?: SortOrder
    filePath?: SortOrder
    fileSize?: SortOrder
    mimeType?: SortOrder
    createdAt?: SortOrder
  }

  export type CharacterImageAvgOrderByAggregateInput = {
    fileSize?: SortOrder
  }

  export type CharacterImageMaxOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    filename?: SortOrder
    originalName?: SortOrder
    imageName?: SortOrder
    filePath?: SortOrder
    fileSize?: SortOrder
    mimeType?: SortOrder
    createdAt?: SortOrder
  }

  export type CharacterImageMinOrderByAggregateInput = {
    id?: SortOrder
    characterId?: SortOrder
    filename?: SortOrder
    originalName?: SortOrder
    imageName?: SortOrder
    filePath?: SortOrder
    fileSize?: SortOrder
    mimeType?: SortOrder
    createdAt?: SortOrder
  }

  export type CharacterImageSumOrderByAggregateInput = {
    fileSize?: SortOrder
  }

  export type SessionCreateNestedManyWithoutCharacterInput = {
    create?: XOR<SessionCreateWithoutCharacterInput, SessionUncheckedCreateWithoutCharacterInput> | SessionCreateWithoutCharacterInput[] | SessionUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutCharacterInput | SessionCreateOrConnectWithoutCharacterInput[]
    createMany?: SessionCreateManyCharacterInputEnvelope
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
  }

  export type SkillHistoryCreateNestedManyWithoutCharacterInput = {
    create?: XOR<SkillHistoryCreateWithoutCharacterInput, SkillHistoryUncheckedCreateWithoutCharacterInput> | SkillHistoryCreateWithoutCharacterInput[] | SkillHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutCharacterInput | SkillHistoryCreateOrConnectWithoutCharacterInput[]
    createMany?: SkillHistoryCreateManyCharacterInputEnvelope
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
  }

  export type SanityHistoryCreateNestedManyWithoutCharacterInput = {
    create?: XOR<SanityHistoryCreateWithoutCharacterInput, SanityHistoryUncheckedCreateWithoutCharacterInput> | SanityHistoryCreateWithoutCharacterInput[] | SanityHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutCharacterInput | SanityHistoryCreateOrConnectWithoutCharacterInput[]
    createMany?: SanityHistoryCreateManyCharacterInputEnvelope
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
  }

  export type InsanitySymptomCreateNestedManyWithoutCharacterInput = {
    create?: XOR<InsanitySymptomCreateWithoutCharacterInput, InsanitySymptomUncheckedCreateWithoutCharacterInput> | InsanitySymptomCreateWithoutCharacterInput[] | InsanitySymptomUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutCharacterInput | InsanitySymptomCreateOrConnectWithoutCharacterInput[]
    createMany?: InsanitySymptomCreateManyCharacterInputEnvelope
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
  }

  export type CharacterImageCreateNestedManyWithoutCharacterInput = {
    create?: XOR<CharacterImageCreateWithoutCharacterInput, CharacterImageUncheckedCreateWithoutCharacterInput> | CharacterImageCreateWithoutCharacterInput[] | CharacterImageUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: CharacterImageCreateOrConnectWithoutCharacterInput | CharacterImageCreateOrConnectWithoutCharacterInput[]
    createMany?: CharacterImageCreateManyCharacterInputEnvelope
    connect?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
  }

  export type SessionUncheckedCreateNestedManyWithoutCharacterInput = {
    create?: XOR<SessionCreateWithoutCharacterInput, SessionUncheckedCreateWithoutCharacterInput> | SessionCreateWithoutCharacterInput[] | SessionUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutCharacterInput | SessionCreateOrConnectWithoutCharacterInput[]
    createMany?: SessionCreateManyCharacterInputEnvelope
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
  }

  export type SkillHistoryUncheckedCreateNestedManyWithoutCharacterInput = {
    create?: XOR<SkillHistoryCreateWithoutCharacterInput, SkillHistoryUncheckedCreateWithoutCharacterInput> | SkillHistoryCreateWithoutCharacterInput[] | SkillHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutCharacterInput | SkillHistoryCreateOrConnectWithoutCharacterInput[]
    createMany?: SkillHistoryCreateManyCharacterInputEnvelope
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
  }

  export type SanityHistoryUncheckedCreateNestedManyWithoutCharacterInput = {
    create?: XOR<SanityHistoryCreateWithoutCharacterInput, SanityHistoryUncheckedCreateWithoutCharacterInput> | SanityHistoryCreateWithoutCharacterInput[] | SanityHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutCharacterInput | SanityHistoryCreateOrConnectWithoutCharacterInput[]
    createMany?: SanityHistoryCreateManyCharacterInputEnvelope
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
  }

  export type InsanitySymptomUncheckedCreateNestedManyWithoutCharacterInput = {
    create?: XOR<InsanitySymptomCreateWithoutCharacterInput, InsanitySymptomUncheckedCreateWithoutCharacterInput> | InsanitySymptomCreateWithoutCharacterInput[] | InsanitySymptomUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutCharacterInput | InsanitySymptomCreateOrConnectWithoutCharacterInput[]
    createMany?: InsanitySymptomCreateManyCharacterInputEnvelope
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
  }

  export type CharacterImageUncheckedCreateNestedManyWithoutCharacterInput = {
    create?: XOR<CharacterImageCreateWithoutCharacterInput, CharacterImageUncheckedCreateWithoutCharacterInput> | CharacterImageCreateWithoutCharacterInput[] | CharacterImageUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: CharacterImageCreateOrConnectWithoutCharacterInput | CharacterImageCreateOrConnectWithoutCharacterInput[]
    createMany?: CharacterImageCreateManyCharacterInputEnvelope
    connect?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type SessionUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<SessionCreateWithoutCharacterInput, SessionUncheckedCreateWithoutCharacterInput> | SessionCreateWithoutCharacterInput[] | SessionUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutCharacterInput | SessionCreateOrConnectWithoutCharacterInput[]
    upsert?: SessionUpsertWithWhereUniqueWithoutCharacterInput | SessionUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: SessionCreateManyCharacterInputEnvelope
    set?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    disconnect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    delete?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    update?: SessionUpdateWithWhereUniqueWithoutCharacterInput | SessionUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: SessionUpdateManyWithWhereWithoutCharacterInput | SessionUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: SessionScalarWhereInput | SessionScalarWhereInput[]
  }

  export type SkillHistoryUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<SkillHistoryCreateWithoutCharacterInput, SkillHistoryUncheckedCreateWithoutCharacterInput> | SkillHistoryCreateWithoutCharacterInput[] | SkillHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutCharacterInput | SkillHistoryCreateOrConnectWithoutCharacterInput[]
    upsert?: SkillHistoryUpsertWithWhereUniqueWithoutCharacterInput | SkillHistoryUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: SkillHistoryCreateManyCharacterInputEnvelope
    set?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    disconnect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    delete?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    update?: SkillHistoryUpdateWithWhereUniqueWithoutCharacterInput | SkillHistoryUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: SkillHistoryUpdateManyWithWhereWithoutCharacterInput | SkillHistoryUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: SkillHistoryScalarWhereInput | SkillHistoryScalarWhereInput[]
  }

  export type SanityHistoryUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<SanityHistoryCreateWithoutCharacterInput, SanityHistoryUncheckedCreateWithoutCharacterInput> | SanityHistoryCreateWithoutCharacterInput[] | SanityHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutCharacterInput | SanityHistoryCreateOrConnectWithoutCharacterInput[]
    upsert?: SanityHistoryUpsertWithWhereUniqueWithoutCharacterInput | SanityHistoryUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: SanityHistoryCreateManyCharacterInputEnvelope
    set?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    disconnect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    delete?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    update?: SanityHistoryUpdateWithWhereUniqueWithoutCharacterInput | SanityHistoryUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: SanityHistoryUpdateManyWithWhereWithoutCharacterInput | SanityHistoryUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: SanityHistoryScalarWhereInput | SanityHistoryScalarWhereInput[]
  }

  export type InsanitySymptomUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<InsanitySymptomCreateWithoutCharacterInput, InsanitySymptomUncheckedCreateWithoutCharacterInput> | InsanitySymptomCreateWithoutCharacterInput[] | InsanitySymptomUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutCharacterInput | InsanitySymptomCreateOrConnectWithoutCharacterInput[]
    upsert?: InsanitySymptomUpsertWithWhereUniqueWithoutCharacterInput | InsanitySymptomUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: InsanitySymptomCreateManyCharacterInputEnvelope
    set?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    disconnect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    delete?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    update?: InsanitySymptomUpdateWithWhereUniqueWithoutCharacterInput | InsanitySymptomUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: InsanitySymptomUpdateManyWithWhereWithoutCharacterInput | InsanitySymptomUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: InsanitySymptomScalarWhereInput | InsanitySymptomScalarWhereInput[]
  }

  export type CharacterImageUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<CharacterImageCreateWithoutCharacterInput, CharacterImageUncheckedCreateWithoutCharacterInput> | CharacterImageCreateWithoutCharacterInput[] | CharacterImageUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: CharacterImageCreateOrConnectWithoutCharacterInput | CharacterImageCreateOrConnectWithoutCharacterInput[]
    upsert?: CharacterImageUpsertWithWhereUniqueWithoutCharacterInput | CharacterImageUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: CharacterImageCreateManyCharacterInputEnvelope
    set?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    disconnect?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    delete?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    connect?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    update?: CharacterImageUpdateWithWhereUniqueWithoutCharacterInput | CharacterImageUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: CharacterImageUpdateManyWithWhereWithoutCharacterInput | CharacterImageUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: CharacterImageScalarWhereInput | CharacterImageScalarWhereInput[]
  }

  export type SessionUncheckedUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<SessionCreateWithoutCharacterInput, SessionUncheckedCreateWithoutCharacterInput> | SessionCreateWithoutCharacterInput[] | SessionUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutCharacterInput | SessionCreateOrConnectWithoutCharacterInput[]
    upsert?: SessionUpsertWithWhereUniqueWithoutCharacterInput | SessionUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: SessionCreateManyCharacterInputEnvelope
    set?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    disconnect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    delete?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    update?: SessionUpdateWithWhereUniqueWithoutCharacterInput | SessionUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: SessionUpdateManyWithWhereWithoutCharacterInput | SessionUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: SessionScalarWhereInput | SessionScalarWhereInput[]
  }

  export type SkillHistoryUncheckedUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<SkillHistoryCreateWithoutCharacterInput, SkillHistoryUncheckedCreateWithoutCharacterInput> | SkillHistoryCreateWithoutCharacterInput[] | SkillHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutCharacterInput | SkillHistoryCreateOrConnectWithoutCharacterInput[]
    upsert?: SkillHistoryUpsertWithWhereUniqueWithoutCharacterInput | SkillHistoryUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: SkillHistoryCreateManyCharacterInputEnvelope
    set?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    disconnect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    delete?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    update?: SkillHistoryUpdateWithWhereUniqueWithoutCharacterInput | SkillHistoryUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: SkillHistoryUpdateManyWithWhereWithoutCharacterInput | SkillHistoryUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: SkillHistoryScalarWhereInput | SkillHistoryScalarWhereInput[]
  }

  export type SanityHistoryUncheckedUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<SanityHistoryCreateWithoutCharacterInput, SanityHistoryUncheckedCreateWithoutCharacterInput> | SanityHistoryCreateWithoutCharacterInput[] | SanityHistoryUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutCharacterInput | SanityHistoryCreateOrConnectWithoutCharacterInput[]
    upsert?: SanityHistoryUpsertWithWhereUniqueWithoutCharacterInput | SanityHistoryUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: SanityHistoryCreateManyCharacterInputEnvelope
    set?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    disconnect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    delete?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    update?: SanityHistoryUpdateWithWhereUniqueWithoutCharacterInput | SanityHistoryUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: SanityHistoryUpdateManyWithWhereWithoutCharacterInput | SanityHistoryUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: SanityHistoryScalarWhereInput | SanityHistoryScalarWhereInput[]
  }

  export type InsanitySymptomUncheckedUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<InsanitySymptomCreateWithoutCharacterInput, InsanitySymptomUncheckedCreateWithoutCharacterInput> | InsanitySymptomCreateWithoutCharacterInput[] | InsanitySymptomUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutCharacterInput | InsanitySymptomCreateOrConnectWithoutCharacterInput[]
    upsert?: InsanitySymptomUpsertWithWhereUniqueWithoutCharacterInput | InsanitySymptomUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: InsanitySymptomCreateManyCharacterInputEnvelope
    set?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    disconnect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    delete?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    update?: InsanitySymptomUpdateWithWhereUniqueWithoutCharacterInput | InsanitySymptomUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: InsanitySymptomUpdateManyWithWhereWithoutCharacterInput | InsanitySymptomUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: InsanitySymptomScalarWhereInput | InsanitySymptomScalarWhereInput[]
  }

  export type CharacterImageUncheckedUpdateManyWithoutCharacterNestedInput = {
    create?: XOR<CharacterImageCreateWithoutCharacterInput, CharacterImageUncheckedCreateWithoutCharacterInput> | CharacterImageCreateWithoutCharacterInput[] | CharacterImageUncheckedCreateWithoutCharacterInput[]
    connectOrCreate?: CharacterImageCreateOrConnectWithoutCharacterInput | CharacterImageCreateOrConnectWithoutCharacterInput[]
    upsert?: CharacterImageUpsertWithWhereUniqueWithoutCharacterInput | CharacterImageUpsertWithWhereUniqueWithoutCharacterInput[]
    createMany?: CharacterImageCreateManyCharacterInputEnvelope
    set?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    disconnect?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    delete?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    connect?: CharacterImageWhereUniqueInput | CharacterImageWhereUniqueInput[]
    update?: CharacterImageUpdateWithWhereUniqueWithoutCharacterInput | CharacterImageUpdateWithWhereUniqueWithoutCharacterInput[]
    updateMany?: CharacterImageUpdateManyWithWhereWithoutCharacterInput | CharacterImageUpdateManyWithWhereWithoutCharacterInput[]
    deleteMany?: CharacterImageScalarWhereInput | CharacterImageScalarWhereInput[]
  }

  export type SessionCreateNestedManyWithoutScenarioInput = {
    create?: XOR<SessionCreateWithoutScenarioInput, SessionUncheckedCreateWithoutScenarioInput> | SessionCreateWithoutScenarioInput[] | SessionUncheckedCreateWithoutScenarioInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutScenarioInput | SessionCreateOrConnectWithoutScenarioInput[]
    createMany?: SessionCreateManyScenarioInputEnvelope
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
  }

  export type SessionUncheckedCreateNestedManyWithoutScenarioInput = {
    create?: XOR<SessionCreateWithoutScenarioInput, SessionUncheckedCreateWithoutScenarioInput> | SessionCreateWithoutScenarioInput[] | SessionUncheckedCreateWithoutScenarioInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutScenarioInput | SessionCreateOrConnectWithoutScenarioInput[]
    createMany?: SessionCreateManyScenarioInputEnvelope
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
  }

  export type SessionUpdateManyWithoutScenarioNestedInput = {
    create?: XOR<SessionCreateWithoutScenarioInput, SessionUncheckedCreateWithoutScenarioInput> | SessionCreateWithoutScenarioInput[] | SessionUncheckedCreateWithoutScenarioInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutScenarioInput | SessionCreateOrConnectWithoutScenarioInput[]
    upsert?: SessionUpsertWithWhereUniqueWithoutScenarioInput | SessionUpsertWithWhereUniqueWithoutScenarioInput[]
    createMany?: SessionCreateManyScenarioInputEnvelope
    set?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    disconnect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    delete?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    update?: SessionUpdateWithWhereUniqueWithoutScenarioInput | SessionUpdateWithWhereUniqueWithoutScenarioInput[]
    updateMany?: SessionUpdateManyWithWhereWithoutScenarioInput | SessionUpdateManyWithWhereWithoutScenarioInput[]
    deleteMany?: SessionScalarWhereInput | SessionScalarWhereInput[]
  }

  export type SessionUncheckedUpdateManyWithoutScenarioNestedInput = {
    create?: XOR<SessionCreateWithoutScenarioInput, SessionUncheckedCreateWithoutScenarioInput> | SessionCreateWithoutScenarioInput[] | SessionUncheckedCreateWithoutScenarioInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutScenarioInput | SessionCreateOrConnectWithoutScenarioInput[]
    upsert?: SessionUpsertWithWhereUniqueWithoutScenarioInput | SessionUpsertWithWhereUniqueWithoutScenarioInput[]
    createMany?: SessionCreateManyScenarioInputEnvelope
    set?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    disconnect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    delete?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    update?: SessionUpdateWithWhereUniqueWithoutScenarioInput | SessionUpdateWithWhereUniqueWithoutScenarioInput[]
    updateMany?: SessionUpdateManyWithWhereWithoutScenarioInput | SessionUpdateManyWithWhereWithoutScenarioInput[]
    deleteMany?: SessionScalarWhereInput | SessionScalarWhereInput[]
  }

  export type CharacterCreateNestedOneWithoutSessionsInput = {
    create?: XOR<CharacterCreateWithoutSessionsInput, CharacterUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutSessionsInput
    connect?: CharacterWhereUniqueInput
  }

  export type ScenarioCreateNestedOneWithoutSessionsInput = {
    create?: XOR<ScenarioCreateWithoutSessionsInput, ScenarioUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: ScenarioCreateOrConnectWithoutSessionsInput
    connect?: ScenarioWhereUniqueInput
  }

  export type SkillHistoryCreateNestedManyWithoutSessionInput = {
    create?: XOR<SkillHistoryCreateWithoutSessionInput, SkillHistoryUncheckedCreateWithoutSessionInput> | SkillHistoryCreateWithoutSessionInput[] | SkillHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutSessionInput | SkillHistoryCreateOrConnectWithoutSessionInput[]
    createMany?: SkillHistoryCreateManySessionInputEnvelope
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
  }

  export type SanityHistoryCreateNestedManyWithoutSessionInput = {
    create?: XOR<SanityHistoryCreateWithoutSessionInput, SanityHistoryUncheckedCreateWithoutSessionInput> | SanityHistoryCreateWithoutSessionInput[] | SanityHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutSessionInput | SanityHistoryCreateOrConnectWithoutSessionInput[]
    createMany?: SanityHistoryCreateManySessionInputEnvelope
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
  }

  export type InsanitySymptomCreateNestedManyWithoutSessionInput = {
    create?: XOR<InsanitySymptomCreateWithoutSessionInput, InsanitySymptomUncheckedCreateWithoutSessionInput> | InsanitySymptomCreateWithoutSessionInput[] | InsanitySymptomUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutSessionInput | InsanitySymptomCreateOrConnectWithoutSessionInput[]
    createMany?: InsanitySymptomCreateManySessionInputEnvelope
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
  }

  export type SkillHistoryUncheckedCreateNestedManyWithoutSessionInput = {
    create?: XOR<SkillHistoryCreateWithoutSessionInput, SkillHistoryUncheckedCreateWithoutSessionInput> | SkillHistoryCreateWithoutSessionInput[] | SkillHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutSessionInput | SkillHistoryCreateOrConnectWithoutSessionInput[]
    createMany?: SkillHistoryCreateManySessionInputEnvelope
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
  }

  export type SanityHistoryUncheckedCreateNestedManyWithoutSessionInput = {
    create?: XOR<SanityHistoryCreateWithoutSessionInput, SanityHistoryUncheckedCreateWithoutSessionInput> | SanityHistoryCreateWithoutSessionInput[] | SanityHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutSessionInput | SanityHistoryCreateOrConnectWithoutSessionInput[]
    createMany?: SanityHistoryCreateManySessionInputEnvelope
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
  }

  export type InsanitySymptomUncheckedCreateNestedManyWithoutSessionInput = {
    create?: XOR<InsanitySymptomCreateWithoutSessionInput, InsanitySymptomUncheckedCreateWithoutSessionInput> | InsanitySymptomCreateWithoutSessionInput[] | InsanitySymptomUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutSessionInput | InsanitySymptomCreateOrConnectWithoutSessionInput[]
    createMany?: InsanitySymptomCreateManySessionInputEnvelope
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
  }

  export type CharacterUpdateOneRequiredWithoutSessionsNestedInput = {
    create?: XOR<CharacterCreateWithoutSessionsInput, CharacterUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutSessionsInput
    upsert?: CharacterUpsertWithoutSessionsInput
    connect?: CharacterWhereUniqueInput
    update?: XOR<XOR<CharacterUpdateToOneWithWhereWithoutSessionsInput, CharacterUpdateWithoutSessionsInput>, CharacterUncheckedUpdateWithoutSessionsInput>
  }

  export type ScenarioUpdateOneRequiredWithoutSessionsNestedInput = {
    create?: XOR<ScenarioCreateWithoutSessionsInput, ScenarioUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: ScenarioCreateOrConnectWithoutSessionsInput
    upsert?: ScenarioUpsertWithoutSessionsInput
    connect?: ScenarioWhereUniqueInput
    update?: XOR<XOR<ScenarioUpdateToOneWithWhereWithoutSessionsInput, ScenarioUpdateWithoutSessionsInput>, ScenarioUncheckedUpdateWithoutSessionsInput>
  }

  export type SkillHistoryUpdateManyWithoutSessionNestedInput = {
    create?: XOR<SkillHistoryCreateWithoutSessionInput, SkillHistoryUncheckedCreateWithoutSessionInput> | SkillHistoryCreateWithoutSessionInput[] | SkillHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutSessionInput | SkillHistoryCreateOrConnectWithoutSessionInput[]
    upsert?: SkillHistoryUpsertWithWhereUniqueWithoutSessionInput | SkillHistoryUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: SkillHistoryCreateManySessionInputEnvelope
    set?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    disconnect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    delete?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    update?: SkillHistoryUpdateWithWhereUniqueWithoutSessionInput | SkillHistoryUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: SkillHistoryUpdateManyWithWhereWithoutSessionInput | SkillHistoryUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: SkillHistoryScalarWhereInput | SkillHistoryScalarWhereInput[]
  }

  export type SanityHistoryUpdateManyWithoutSessionNestedInput = {
    create?: XOR<SanityHistoryCreateWithoutSessionInput, SanityHistoryUncheckedCreateWithoutSessionInput> | SanityHistoryCreateWithoutSessionInput[] | SanityHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutSessionInput | SanityHistoryCreateOrConnectWithoutSessionInput[]
    upsert?: SanityHistoryUpsertWithWhereUniqueWithoutSessionInput | SanityHistoryUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: SanityHistoryCreateManySessionInputEnvelope
    set?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    disconnect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    delete?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    update?: SanityHistoryUpdateWithWhereUniqueWithoutSessionInput | SanityHistoryUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: SanityHistoryUpdateManyWithWhereWithoutSessionInput | SanityHistoryUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: SanityHistoryScalarWhereInput | SanityHistoryScalarWhereInput[]
  }

  export type InsanitySymptomUpdateManyWithoutSessionNestedInput = {
    create?: XOR<InsanitySymptomCreateWithoutSessionInput, InsanitySymptomUncheckedCreateWithoutSessionInput> | InsanitySymptomCreateWithoutSessionInput[] | InsanitySymptomUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutSessionInput | InsanitySymptomCreateOrConnectWithoutSessionInput[]
    upsert?: InsanitySymptomUpsertWithWhereUniqueWithoutSessionInput | InsanitySymptomUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: InsanitySymptomCreateManySessionInputEnvelope
    set?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    disconnect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    delete?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    update?: InsanitySymptomUpdateWithWhereUniqueWithoutSessionInput | InsanitySymptomUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: InsanitySymptomUpdateManyWithWhereWithoutSessionInput | InsanitySymptomUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: InsanitySymptomScalarWhereInput | InsanitySymptomScalarWhereInput[]
  }

  export type SkillHistoryUncheckedUpdateManyWithoutSessionNestedInput = {
    create?: XOR<SkillHistoryCreateWithoutSessionInput, SkillHistoryUncheckedCreateWithoutSessionInput> | SkillHistoryCreateWithoutSessionInput[] | SkillHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SkillHistoryCreateOrConnectWithoutSessionInput | SkillHistoryCreateOrConnectWithoutSessionInput[]
    upsert?: SkillHistoryUpsertWithWhereUniqueWithoutSessionInput | SkillHistoryUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: SkillHistoryCreateManySessionInputEnvelope
    set?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    disconnect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    delete?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    connect?: SkillHistoryWhereUniqueInput | SkillHistoryWhereUniqueInput[]
    update?: SkillHistoryUpdateWithWhereUniqueWithoutSessionInput | SkillHistoryUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: SkillHistoryUpdateManyWithWhereWithoutSessionInput | SkillHistoryUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: SkillHistoryScalarWhereInput | SkillHistoryScalarWhereInput[]
  }

  export type SanityHistoryUncheckedUpdateManyWithoutSessionNestedInput = {
    create?: XOR<SanityHistoryCreateWithoutSessionInput, SanityHistoryUncheckedCreateWithoutSessionInput> | SanityHistoryCreateWithoutSessionInput[] | SanityHistoryUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: SanityHistoryCreateOrConnectWithoutSessionInput | SanityHistoryCreateOrConnectWithoutSessionInput[]
    upsert?: SanityHistoryUpsertWithWhereUniqueWithoutSessionInput | SanityHistoryUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: SanityHistoryCreateManySessionInputEnvelope
    set?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    disconnect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    delete?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    connect?: SanityHistoryWhereUniqueInput | SanityHistoryWhereUniqueInput[]
    update?: SanityHistoryUpdateWithWhereUniqueWithoutSessionInput | SanityHistoryUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: SanityHistoryUpdateManyWithWhereWithoutSessionInput | SanityHistoryUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: SanityHistoryScalarWhereInput | SanityHistoryScalarWhereInput[]
  }

  export type InsanitySymptomUncheckedUpdateManyWithoutSessionNestedInput = {
    create?: XOR<InsanitySymptomCreateWithoutSessionInput, InsanitySymptomUncheckedCreateWithoutSessionInput> | InsanitySymptomCreateWithoutSessionInput[] | InsanitySymptomUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: InsanitySymptomCreateOrConnectWithoutSessionInput | InsanitySymptomCreateOrConnectWithoutSessionInput[]
    upsert?: InsanitySymptomUpsertWithWhereUniqueWithoutSessionInput | InsanitySymptomUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: InsanitySymptomCreateManySessionInputEnvelope
    set?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    disconnect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    delete?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    connect?: InsanitySymptomWhereUniqueInput | InsanitySymptomWhereUniqueInput[]
    update?: InsanitySymptomUpdateWithWhereUniqueWithoutSessionInput | InsanitySymptomUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: InsanitySymptomUpdateManyWithWhereWithoutSessionInput | InsanitySymptomUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: InsanitySymptomScalarWhereInput | InsanitySymptomScalarWhereInput[]
  }

  export type CharacterCreateNestedOneWithoutSkillHistoriesInput = {
    create?: XOR<CharacterCreateWithoutSkillHistoriesInput, CharacterUncheckedCreateWithoutSkillHistoriesInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutSkillHistoriesInput
    connect?: CharacterWhereUniqueInput
  }

  export type SessionCreateNestedOneWithoutSkillHistoriesInput = {
    create?: XOR<SessionCreateWithoutSkillHistoriesInput, SessionUncheckedCreateWithoutSkillHistoriesInput>
    connectOrCreate?: SessionCreateOrConnectWithoutSkillHistoriesInput
    connect?: SessionWhereUniqueInput
  }

  export type CharacterUpdateOneRequiredWithoutSkillHistoriesNestedInput = {
    create?: XOR<CharacterCreateWithoutSkillHistoriesInput, CharacterUncheckedCreateWithoutSkillHistoriesInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutSkillHistoriesInput
    upsert?: CharacterUpsertWithoutSkillHistoriesInput
    connect?: CharacterWhereUniqueInput
    update?: XOR<XOR<CharacterUpdateToOneWithWhereWithoutSkillHistoriesInput, CharacterUpdateWithoutSkillHistoriesInput>, CharacterUncheckedUpdateWithoutSkillHistoriesInput>
  }

  export type SessionUpdateOneWithoutSkillHistoriesNestedInput = {
    create?: XOR<SessionCreateWithoutSkillHistoriesInput, SessionUncheckedCreateWithoutSkillHistoriesInput>
    connectOrCreate?: SessionCreateOrConnectWithoutSkillHistoriesInput
    upsert?: SessionUpsertWithoutSkillHistoriesInput
    disconnect?: SessionWhereInput | boolean
    delete?: SessionWhereInput | boolean
    connect?: SessionWhereUniqueInput
    update?: XOR<XOR<SessionUpdateToOneWithWhereWithoutSkillHistoriesInput, SessionUpdateWithoutSkillHistoriesInput>, SessionUncheckedUpdateWithoutSkillHistoriesInput>
  }

  export type CharacterCreateNestedOneWithoutSanityHistoriesInput = {
    create?: XOR<CharacterCreateWithoutSanityHistoriesInput, CharacterUncheckedCreateWithoutSanityHistoriesInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutSanityHistoriesInput
    connect?: CharacterWhereUniqueInput
  }

  export type SessionCreateNestedOneWithoutSanityHistoriesInput = {
    create?: XOR<SessionCreateWithoutSanityHistoriesInput, SessionUncheckedCreateWithoutSanityHistoriesInput>
    connectOrCreate?: SessionCreateOrConnectWithoutSanityHistoriesInput
    connect?: SessionWhereUniqueInput
  }

  export type CharacterUpdateOneRequiredWithoutSanityHistoriesNestedInput = {
    create?: XOR<CharacterCreateWithoutSanityHistoriesInput, CharacterUncheckedCreateWithoutSanityHistoriesInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutSanityHistoriesInput
    upsert?: CharacterUpsertWithoutSanityHistoriesInput
    connect?: CharacterWhereUniqueInput
    update?: XOR<XOR<CharacterUpdateToOneWithWhereWithoutSanityHistoriesInput, CharacterUpdateWithoutSanityHistoriesInput>, CharacterUncheckedUpdateWithoutSanityHistoriesInput>
  }

  export type SessionUpdateOneWithoutSanityHistoriesNestedInput = {
    create?: XOR<SessionCreateWithoutSanityHistoriesInput, SessionUncheckedCreateWithoutSanityHistoriesInput>
    connectOrCreate?: SessionCreateOrConnectWithoutSanityHistoriesInput
    upsert?: SessionUpsertWithoutSanityHistoriesInput
    disconnect?: SessionWhereInput | boolean
    delete?: SessionWhereInput | boolean
    connect?: SessionWhereUniqueInput
    update?: XOR<XOR<SessionUpdateToOneWithWhereWithoutSanityHistoriesInput, SessionUpdateWithoutSanityHistoriesInput>, SessionUncheckedUpdateWithoutSanityHistoriesInput>
  }

  export type CharacterCreateNestedOneWithoutInsanitySymptomsInput = {
    create?: XOR<CharacterCreateWithoutInsanitySymptomsInput, CharacterUncheckedCreateWithoutInsanitySymptomsInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutInsanitySymptomsInput
    connect?: CharacterWhereUniqueInput
  }

  export type SessionCreateNestedOneWithoutInsanitySymptomsInput = {
    create?: XOR<SessionCreateWithoutInsanitySymptomsInput, SessionUncheckedCreateWithoutInsanitySymptomsInput>
    connectOrCreate?: SessionCreateOrConnectWithoutInsanitySymptomsInput
    connect?: SessionWhereUniqueInput
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type CharacterUpdateOneRequiredWithoutInsanitySymptomsNestedInput = {
    create?: XOR<CharacterCreateWithoutInsanitySymptomsInput, CharacterUncheckedCreateWithoutInsanitySymptomsInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutInsanitySymptomsInput
    upsert?: CharacterUpsertWithoutInsanitySymptomsInput
    connect?: CharacterWhereUniqueInput
    update?: XOR<XOR<CharacterUpdateToOneWithWhereWithoutInsanitySymptomsInput, CharacterUpdateWithoutInsanitySymptomsInput>, CharacterUncheckedUpdateWithoutInsanitySymptomsInput>
  }

  export type SessionUpdateOneWithoutInsanitySymptomsNestedInput = {
    create?: XOR<SessionCreateWithoutInsanitySymptomsInput, SessionUncheckedCreateWithoutInsanitySymptomsInput>
    connectOrCreate?: SessionCreateOrConnectWithoutInsanitySymptomsInput
    upsert?: SessionUpsertWithoutInsanitySymptomsInput
    disconnect?: SessionWhereInput | boolean
    delete?: SessionWhereInput | boolean
    connect?: SessionWhereUniqueInput
    update?: XOR<XOR<SessionUpdateToOneWithWhereWithoutInsanitySymptomsInput, SessionUpdateWithoutInsanitySymptomsInput>, SessionUncheckedUpdateWithoutInsanitySymptomsInput>
  }

  export type CharacterCreateNestedOneWithoutImagesInput = {
    create?: XOR<CharacterCreateWithoutImagesInput, CharacterUncheckedCreateWithoutImagesInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutImagesInput
    connect?: CharacterWhereUniqueInput
  }

  export type CharacterUpdateOneRequiredWithoutImagesNestedInput = {
    create?: XOR<CharacterCreateWithoutImagesInput, CharacterUncheckedCreateWithoutImagesInput>
    connectOrCreate?: CharacterCreateOrConnectWithoutImagesInput
    upsert?: CharacterUpsertWithoutImagesInput
    connect?: CharacterWhereUniqueInput
    update?: XOR<XOR<CharacterUpdateToOneWithWhereWithoutImagesInput, CharacterUpdateWithoutImagesInput>, CharacterUncheckedUpdateWithoutImagesInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type SessionCreateWithoutCharacterInput = {
    id?: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    scenario: ScenarioCreateNestedOneWithoutSessionsInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutSessionInput
  }

  export type SessionUncheckedCreateWithoutCharacterInput = {
    id?: string
    scenarioId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutSessionInput
  }

  export type SessionCreateOrConnectWithoutCharacterInput = {
    where: SessionWhereUniqueInput
    create: XOR<SessionCreateWithoutCharacterInput, SessionUncheckedCreateWithoutCharacterInput>
  }

  export type SessionCreateManyCharacterInputEnvelope = {
    data: SessionCreateManyCharacterInput | SessionCreateManyCharacterInput[]
    skipDuplicates?: boolean
  }

  export type SkillHistoryCreateWithoutCharacterInput = {
    id?: string
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
    session?: SessionCreateNestedOneWithoutSkillHistoriesInput
  }

  export type SkillHistoryUncheckedCreateWithoutCharacterInput = {
    id?: string
    sessionId?: string | null
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
  }

  export type SkillHistoryCreateOrConnectWithoutCharacterInput = {
    where: SkillHistoryWhereUniqueInput
    create: XOR<SkillHistoryCreateWithoutCharacterInput, SkillHistoryUncheckedCreateWithoutCharacterInput>
  }

  export type SkillHistoryCreateManyCharacterInputEnvelope = {
    data: SkillHistoryCreateManyCharacterInput | SkillHistoryCreateManyCharacterInput[]
    skipDuplicates?: boolean
  }

  export type SanityHistoryCreateWithoutCharacterInput = {
    id?: string
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
    session?: SessionCreateNestedOneWithoutSanityHistoriesInput
  }

  export type SanityHistoryUncheckedCreateWithoutCharacterInput = {
    id?: string
    sessionId?: string | null
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
  }

  export type SanityHistoryCreateOrConnectWithoutCharacterInput = {
    where: SanityHistoryWhereUniqueInput
    create: XOR<SanityHistoryCreateWithoutCharacterInput, SanityHistoryUncheckedCreateWithoutCharacterInput>
  }

  export type SanityHistoryCreateManyCharacterInputEnvelope = {
    data: SanityHistoryCreateManyCharacterInput | SanityHistoryCreateManyCharacterInput[]
    skipDuplicates?: boolean
  }

  export type InsanitySymptomCreateWithoutCharacterInput = {
    id?: string
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
    session?: SessionCreateNestedOneWithoutInsanitySymptomsInput
  }

  export type InsanitySymptomUncheckedCreateWithoutCharacterInput = {
    id?: string
    sessionId?: string | null
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
  }

  export type InsanitySymptomCreateOrConnectWithoutCharacterInput = {
    where: InsanitySymptomWhereUniqueInput
    create: XOR<InsanitySymptomCreateWithoutCharacterInput, InsanitySymptomUncheckedCreateWithoutCharacterInput>
  }

  export type InsanitySymptomCreateManyCharacterInputEnvelope = {
    data: InsanitySymptomCreateManyCharacterInput | InsanitySymptomCreateManyCharacterInput[]
    skipDuplicates?: boolean
  }

  export type CharacterImageCreateWithoutCharacterInput = {
    id?: string
    filename: string
    originalName: string
    imageName?: string | null
    filePath: string
    fileSize: number
    mimeType: string
    createdAt?: Date | string
  }

  export type CharacterImageUncheckedCreateWithoutCharacterInput = {
    id?: string
    filename: string
    originalName: string
    imageName?: string | null
    filePath: string
    fileSize: number
    mimeType: string
    createdAt?: Date | string
  }

  export type CharacterImageCreateOrConnectWithoutCharacterInput = {
    where: CharacterImageWhereUniqueInput
    create: XOR<CharacterImageCreateWithoutCharacterInput, CharacterImageUncheckedCreateWithoutCharacterInput>
  }

  export type CharacterImageCreateManyCharacterInputEnvelope = {
    data: CharacterImageCreateManyCharacterInput | CharacterImageCreateManyCharacterInput[]
    skipDuplicates?: boolean
  }

  export type SessionUpsertWithWhereUniqueWithoutCharacterInput = {
    where: SessionWhereUniqueInput
    update: XOR<SessionUpdateWithoutCharacterInput, SessionUncheckedUpdateWithoutCharacterInput>
    create: XOR<SessionCreateWithoutCharacterInput, SessionUncheckedCreateWithoutCharacterInput>
  }

  export type SessionUpdateWithWhereUniqueWithoutCharacterInput = {
    where: SessionWhereUniqueInput
    data: XOR<SessionUpdateWithoutCharacterInput, SessionUncheckedUpdateWithoutCharacterInput>
  }

  export type SessionUpdateManyWithWhereWithoutCharacterInput = {
    where: SessionScalarWhereInput
    data: XOR<SessionUpdateManyMutationInput, SessionUncheckedUpdateManyWithoutCharacterInput>
  }

  export type SessionScalarWhereInput = {
    AND?: SessionScalarWhereInput | SessionScalarWhereInput[]
    OR?: SessionScalarWhereInput[]
    NOT?: SessionScalarWhereInput | SessionScalarWhereInput[]
    id?: StringFilter<"Session"> | string
    characterId?: StringFilter<"Session"> | string
    scenarioId?: StringFilter<"Session"> | string
    kpName?: StringNullableFilter<"Session"> | string | null
    playDate?: DateTimeFilter<"Session"> | Date | string
    memo?: StringNullableFilter<"Session"> | string | null
    participants?: StringNullableFilter<"Session"> | string | null
    createdAt?: DateTimeFilter<"Session"> | Date | string
    updatedAt?: DateTimeFilter<"Session"> | Date | string
  }

  export type SkillHistoryUpsertWithWhereUniqueWithoutCharacterInput = {
    where: SkillHistoryWhereUniqueInput
    update: XOR<SkillHistoryUpdateWithoutCharacterInput, SkillHistoryUncheckedUpdateWithoutCharacterInput>
    create: XOR<SkillHistoryCreateWithoutCharacterInput, SkillHistoryUncheckedCreateWithoutCharacterInput>
  }

  export type SkillHistoryUpdateWithWhereUniqueWithoutCharacterInput = {
    where: SkillHistoryWhereUniqueInput
    data: XOR<SkillHistoryUpdateWithoutCharacterInput, SkillHistoryUncheckedUpdateWithoutCharacterInput>
  }

  export type SkillHistoryUpdateManyWithWhereWithoutCharacterInput = {
    where: SkillHistoryScalarWhereInput
    data: XOR<SkillHistoryUpdateManyMutationInput, SkillHistoryUncheckedUpdateManyWithoutCharacterInput>
  }

  export type SkillHistoryScalarWhereInput = {
    AND?: SkillHistoryScalarWhereInput | SkillHistoryScalarWhereInput[]
    OR?: SkillHistoryScalarWhereInput[]
    NOT?: SkillHistoryScalarWhereInput | SkillHistoryScalarWhereInput[]
    id?: StringFilter<"SkillHistory"> | string
    characterId?: StringFilter<"SkillHistory"> | string
    sessionId?: StringNullableFilter<"SkillHistory"> | string | null
    skillName?: StringFilter<"SkillHistory"> | string
    oldValue?: IntFilter<"SkillHistory"> | number
    newValue?: IntFilter<"SkillHistory"> | number
    reason?: StringNullableFilter<"SkillHistory"> | string | null
    createdAt?: DateTimeFilter<"SkillHistory"> | Date | string
  }

  export type SanityHistoryUpsertWithWhereUniqueWithoutCharacterInput = {
    where: SanityHistoryWhereUniqueInput
    update: XOR<SanityHistoryUpdateWithoutCharacterInput, SanityHistoryUncheckedUpdateWithoutCharacterInput>
    create: XOR<SanityHistoryCreateWithoutCharacterInput, SanityHistoryUncheckedCreateWithoutCharacterInput>
  }

  export type SanityHistoryUpdateWithWhereUniqueWithoutCharacterInput = {
    where: SanityHistoryWhereUniqueInput
    data: XOR<SanityHistoryUpdateWithoutCharacterInput, SanityHistoryUncheckedUpdateWithoutCharacterInput>
  }

  export type SanityHistoryUpdateManyWithWhereWithoutCharacterInput = {
    where: SanityHistoryScalarWhereInput
    data: XOR<SanityHistoryUpdateManyMutationInput, SanityHistoryUncheckedUpdateManyWithoutCharacterInput>
  }

  export type SanityHistoryScalarWhereInput = {
    AND?: SanityHistoryScalarWhereInput | SanityHistoryScalarWhereInput[]
    OR?: SanityHistoryScalarWhereInput[]
    NOT?: SanityHistoryScalarWhereInput | SanityHistoryScalarWhereInput[]
    id?: StringFilter<"SanityHistory"> | string
    characterId?: StringFilter<"SanityHistory"> | string
    sessionId?: StringNullableFilter<"SanityHistory"> | string | null
    oldValue?: IntFilter<"SanityHistory"> | number
    newValue?: IntFilter<"SanityHistory"> | number
    reason?: StringFilter<"SanityHistory"> | string
    createdAt?: DateTimeFilter<"SanityHistory"> | Date | string
  }

  export type InsanitySymptomUpsertWithWhereUniqueWithoutCharacterInput = {
    where: InsanitySymptomWhereUniqueInput
    update: XOR<InsanitySymptomUpdateWithoutCharacterInput, InsanitySymptomUncheckedUpdateWithoutCharacterInput>
    create: XOR<InsanitySymptomCreateWithoutCharacterInput, InsanitySymptomUncheckedCreateWithoutCharacterInput>
  }

  export type InsanitySymptomUpdateWithWhereUniqueWithoutCharacterInput = {
    where: InsanitySymptomWhereUniqueInput
    data: XOR<InsanitySymptomUpdateWithoutCharacterInput, InsanitySymptomUncheckedUpdateWithoutCharacterInput>
  }

  export type InsanitySymptomUpdateManyWithWhereWithoutCharacterInput = {
    where: InsanitySymptomScalarWhereInput
    data: XOR<InsanitySymptomUpdateManyMutationInput, InsanitySymptomUncheckedUpdateManyWithoutCharacterInput>
  }

  export type InsanitySymptomScalarWhereInput = {
    AND?: InsanitySymptomScalarWhereInput | InsanitySymptomScalarWhereInput[]
    OR?: InsanitySymptomScalarWhereInput[]
    NOT?: InsanitySymptomScalarWhereInput | InsanitySymptomScalarWhereInput[]
    id?: StringFilter<"InsanitySymptom"> | string
    characterId?: StringFilter<"InsanitySymptom"> | string
    sessionId?: StringNullableFilter<"InsanitySymptom"> | string | null
    symptomType?: StringFilter<"InsanitySymptom"> | string
    symptomName?: StringFilter<"InsanitySymptom"> | string
    description?: StringNullableFilter<"InsanitySymptom"> | string | null
    isRecovered?: BoolFilter<"InsanitySymptom"> | boolean
    recoveredAt?: DateTimeNullableFilter<"InsanitySymptom"> | Date | string | null
    createdAt?: DateTimeFilter<"InsanitySymptom"> | Date | string
  }

  export type CharacterImageUpsertWithWhereUniqueWithoutCharacterInput = {
    where: CharacterImageWhereUniqueInput
    update: XOR<CharacterImageUpdateWithoutCharacterInput, CharacterImageUncheckedUpdateWithoutCharacterInput>
    create: XOR<CharacterImageCreateWithoutCharacterInput, CharacterImageUncheckedCreateWithoutCharacterInput>
  }

  export type CharacterImageUpdateWithWhereUniqueWithoutCharacterInput = {
    where: CharacterImageWhereUniqueInput
    data: XOR<CharacterImageUpdateWithoutCharacterInput, CharacterImageUncheckedUpdateWithoutCharacterInput>
  }

  export type CharacterImageUpdateManyWithWhereWithoutCharacterInput = {
    where: CharacterImageScalarWhereInput
    data: XOR<CharacterImageUpdateManyMutationInput, CharacterImageUncheckedUpdateManyWithoutCharacterInput>
  }

  export type CharacterImageScalarWhereInput = {
    AND?: CharacterImageScalarWhereInput | CharacterImageScalarWhereInput[]
    OR?: CharacterImageScalarWhereInput[]
    NOT?: CharacterImageScalarWhereInput | CharacterImageScalarWhereInput[]
    id?: StringFilter<"CharacterImage"> | string
    characterId?: StringFilter<"CharacterImage"> | string
    filename?: StringFilter<"CharacterImage"> | string
    originalName?: StringFilter<"CharacterImage"> | string
    imageName?: StringNullableFilter<"CharacterImage"> | string | null
    filePath?: StringFilter<"CharacterImage"> | string
    fileSize?: IntFilter<"CharacterImage"> | number
    mimeType?: StringFilter<"CharacterImage"> | string
    createdAt?: DateTimeFilter<"CharacterImage"> | Date | string
  }

  export type SessionCreateWithoutScenarioInput = {
    id?: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    character: CharacterCreateNestedOneWithoutSessionsInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutSessionInput
  }

  export type SessionUncheckedCreateWithoutScenarioInput = {
    id?: string
    characterId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutSessionInput
  }

  export type SessionCreateOrConnectWithoutScenarioInput = {
    where: SessionWhereUniqueInput
    create: XOR<SessionCreateWithoutScenarioInput, SessionUncheckedCreateWithoutScenarioInput>
  }

  export type SessionCreateManyScenarioInputEnvelope = {
    data: SessionCreateManyScenarioInput | SessionCreateManyScenarioInput[]
    skipDuplicates?: boolean
  }

  export type SessionUpsertWithWhereUniqueWithoutScenarioInput = {
    where: SessionWhereUniqueInput
    update: XOR<SessionUpdateWithoutScenarioInput, SessionUncheckedUpdateWithoutScenarioInput>
    create: XOR<SessionCreateWithoutScenarioInput, SessionUncheckedCreateWithoutScenarioInput>
  }

  export type SessionUpdateWithWhereUniqueWithoutScenarioInput = {
    where: SessionWhereUniqueInput
    data: XOR<SessionUpdateWithoutScenarioInput, SessionUncheckedUpdateWithoutScenarioInput>
  }

  export type SessionUpdateManyWithWhereWithoutScenarioInput = {
    where: SessionScalarWhereInput
    data: XOR<SessionUpdateManyMutationInput, SessionUncheckedUpdateManyWithoutScenarioInput>
  }

  export type CharacterCreateWithoutSessionsInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    skillHistories?: SkillHistoryCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutCharacterInput
    images?: CharacterImageCreateNestedManyWithoutCharacterInput
  }

  export type CharacterUncheckedCreateWithoutSessionsInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutCharacterInput
    images?: CharacterImageUncheckedCreateNestedManyWithoutCharacterInput
  }

  export type CharacterCreateOrConnectWithoutSessionsInput = {
    where: CharacterWhereUniqueInput
    create: XOR<CharacterCreateWithoutSessionsInput, CharacterUncheckedCreateWithoutSessionsInput>
  }

  export type ScenarioCreateWithoutSessionsInput = {
    id?: string
    title: string
    author?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ScenarioUncheckedCreateWithoutSessionsInput = {
    id?: string
    title: string
    author?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ScenarioCreateOrConnectWithoutSessionsInput = {
    where: ScenarioWhereUniqueInput
    create: XOR<ScenarioCreateWithoutSessionsInput, ScenarioUncheckedCreateWithoutSessionsInput>
  }

  export type SkillHistoryCreateWithoutSessionInput = {
    id?: string
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
    character: CharacterCreateNestedOneWithoutSkillHistoriesInput
  }

  export type SkillHistoryUncheckedCreateWithoutSessionInput = {
    id?: string
    characterId: string
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
  }

  export type SkillHistoryCreateOrConnectWithoutSessionInput = {
    where: SkillHistoryWhereUniqueInput
    create: XOR<SkillHistoryCreateWithoutSessionInput, SkillHistoryUncheckedCreateWithoutSessionInput>
  }

  export type SkillHistoryCreateManySessionInputEnvelope = {
    data: SkillHistoryCreateManySessionInput | SkillHistoryCreateManySessionInput[]
    skipDuplicates?: boolean
  }

  export type SanityHistoryCreateWithoutSessionInput = {
    id?: string
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
    character: CharacterCreateNestedOneWithoutSanityHistoriesInput
  }

  export type SanityHistoryUncheckedCreateWithoutSessionInput = {
    id?: string
    characterId: string
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
  }

  export type SanityHistoryCreateOrConnectWithoutSessionInput = {
    where: SanityHistoryWhereUniqueInput
    create: XOR<SanityHistoryCreateWithoutSessionInput, SanityHistoryUncheckedCreateWithoutSessionInput>
  }

  export type SanityHistoryCreateManySessionInputEnvelope = {
    data: SanityHistoryCreateManySessionInput | SanityHistoryCreateManySessionInput[]
    skipDuplicates?: boolean
  }

  export type InsanitySymptomCreateWithoutSessionInput = {
    id?: string
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
    character: CharacterCreateNestedOneWithoutInsanitySymptomsInput
  }

  export type InsanitySymptomUncheckedCreateWithoutSessionInput = {
    id?: string
    characterId: string
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
  }

  export type InsanitySymptomCreateOrConnectWithoutSessionInput = {
    where: InsanitySymptomWhereUniqueInput
    create: XOR<InsanitySymptomCreateWithoutSessionInput, InsanitySymptomUncheckedCreateWithoutSessionInput>
  }

  export type InsanitySymptomCreateManySessionInputEnvelope = {
    data: InsanitySymptomCreateManySessionInput | InsanitySymptomCreateManySessionInput[]
    skipDuplicates?: boolean
  }

  export type CharacterUpsertWithoutSessionsInput = {
    update: XOR<CharacterUpdateWithoutSessionsInput, CharacterUncheckedUpdateWithoutSessionsInput>
    create: XOR<CharacterCreateWithoutSessionsInput, CharacterUncheckedCreateWithoutSessionsInput>
    where?: CharacterWhereInput
  }

  export type CharacterUpdateToOneWithWhereWithoutSessionsInput = {
    where?: CharacterWhereInput
    data: XOR<CharacterUpdateWithoutSessionsInput, CharacterUncheckedUpdateWithoutSessionsInput>
  }

  export type CharacterUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    skillHistories?: SkillHistoryUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUpdateManyWithoutCharacterNestedInput
  }

  export type CharacterUncheckedUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUncheckedUpdateManyWithoutCharacterNestedInput
  }

  export type ScenarioUpsertWithoutSessionsInput = {
    update: XOR<ScenarioUpdateWithoutSessionsInput, ScenarioUncheckedUpdateWithoutSessionsInput>
    create: XOR<ScenarioCreateWithoutSessionsInput, ScenarioUncheckedCreateWithoutSessionsInput>
    where?: ScenarioWhereInput
  }

  export type ScenarioUpdateToOneWithWhereWithoutSessionsInput = {
    where?: ScenarioWhereInput
    data: XOR<ScenarioUpdateWithoutSessionsInput, ScenarioUncheckedUpdateWithoutSessionsInput>
  }

  export type ScenarioUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    author?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ScenarioUncheckedUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    author?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryUpsertWithWhereUniqueWithoutSessionInput = {
    where: SkillHistoryWhereUniqueInput
    update: XOR<SkillHistoryUpdateWithoutSessionInput, SkillHistoryUncheckedUpdateWithoutSessionInput>
    create: XOR<SkillHistoryCreateWithoutSessionInput, SkillHistoryUncheckedCreateWithoutSessionInput>
  }

  export type SkillHistoryUpdateWithWhereUniqueWithoutSessionInput = {
    where: SkillHistoryWhereUniqueInput
    data: XOR<SkillHistoryUpdateWithoutSessionInput, SkillHistoryUncheckedUpdateWithoutSessionInput>
  }

  export type SkillHistoryUpdateManyWithWhereWithoutSessionInput = {
    where: SkillHistoryScalarWhereInput
    data: XOR<SkillHistoryUpdateManyMutationInput, SkillHistoryUncheckedUpdateManyWithoutSessionInput>
  }

  export type SanityHistoryUpsertWithWhereUniqueWithoutSessionInput = {
    where: SanityHistoryWhereUniqueInput
    update: XOR<SanityHistoryUpdateWithoutSessionInput, SanityHistoryUncheckedUpdateWithoutSessionInput>
    create: XOR<SanityHistoryCreateWithoutSessionInput, SanityHistoryUncheckedCreateWithoutSessionInput>
  }

  export type SanityHistoryUpdateWithWhereUniqueWithoutSessionInput = {
    where: SanityHistoryWhereUniqueInput
    data: XOR<SanityHistoryUpdateWithoutSessionInput, SanityHistoryUncheckedUpdateWithoutSessionInput>
  }

  export type SanityHistoryUpdateManyWithWhereWithoutSessionInput = {
    where: SanityHistoryScalarWhereInput
    data: XOR<SanityHistoryUpdateManyMutationInput, SanityHistoryUncheckedUpdateManyWithoutSessionInput>
  }

  export type InsanitySymptomUpsertWithWhereUniqueWithoutSessionInput = {
    where: InsanitySymptomWhereUniqueInput
    update: XOR<InsanitySymptomUpdateWithoutSessionInput, InsanitySymptomUncheckedUpdateWithoutSessionInput>
    create: XOR<InsanitySymptomCreateWithoutSessionInput, InsanitySymptomUncheckedCreateWithoutSessionInput>
  }

  export type InsanitySymptomUpdateWithWhereUniqueWithoutSessionInput = {
    where: InsanitySymptomWhereUniqueInput
    data: XOR<InsanitySymptomUpdateWithoutSessionInput, InsanitySymptomUncheckedUpdateWithoutSessionInput>
  }

  export type InsanitySymptomUpdateManyWithWhereWithoutSessionInput = {
    where: InsanitySymptomScalarWhereInput
    data: XOR<InsanitySymptomUpdateManyMutationInput, InsanitySymptomUncheckedUpdateManyWithoutSessionInput>
  }

  export type CharacterCreateWithoutSkillHistoriesInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutCharacterInput
    images?: CharacterImageCreateNestedManyWithoutCharacterInput
  }

  export type CharacterUncheckedCreateWithoutSkillHistoriesInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionUncheckedCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutCharacterInput
    images?: CharacterImageUncheckedCreateNestedManyWithoutCharacterInput
  }

  export type CharacterCreateOrConnectWithoutSkillHistoriesInput = {
    where: CharacterWhereUniqueInput
    create: XOR<CharacterCreateWithoutSkillHistoriesInput, CharacterUncheckedCreateWithoutSkillHistoriesInput>
  }

  export type SessionCreateWithoutSkillHistoriesInput = {
    id?: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    character: CharacterCreateNestedOneWithoutSessionsInput
    scenario: ScenarioCreateNestedOneWithoutSessionsInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutSessionInput
  }

  export type SessionUncheckedCreateWithoutSkillHistoriesInput = {
    id?: string
    characterId: string
    scenarioId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutSessionInput
  }

  export type SessionCreateOrConnectWithoutSkillHistoriesInput = {
    where: SessionWhereUniqueInput
    create: XOR<SessionCreateWithoutSkillHistoriesInput, SessionUncheckedCreateWithoutSkillHistoriesInput>
  }

  export type CharacterUpsertWithoutSkillHistoriesInput = {
    update: XOR<CharacterUpdateWithoutSkillHistoriesInput, CharacterUncheckedUpdateWithoutSkillHistoriesInput>
    create: XOR<CharacterCreateWithoutSkillHistoriesInput, CharacterUncheckedCreateWithoutSkillHistoriesInput>
    where?: CharacterWhereInput
  }

  export type CharacterUpdateToOneWithWhereWithoutSkillHistoriesInput = {
    where?: CharacterWhereInput
    data: XOR<CharacterUpdateWithoutSkillHistoriesInput, CharacterUncheckedUpdateWithoutSkillHistoriesInput>
  }

  export type CharacterUpdateWithoutSkillHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUpdateManyWithoutCharacterNestedInput
  }

  export type CharacterUncheckedUpdateWithoutSkillHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUncheckedUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUncheckedUpdateManyWithoutCharacterNestedInput
  }

  export type SessionUpsertWithoutSkillHistoriesInput = {
    update: XOR<SessionUpdateWithoutSkillHistoriesInput, SessionUncheckedUpdateWithoutSkillHistoriesInput>
    create: XOR<SessionCreateWithoutSkillHistoriesInput, SessionUncheckedCreateWithoutSkillHistoriesInput>
    where?: SessionWhereInput
  }

  export type SessionUpdateToOneWithWhereWithoutSkillHistoriesInput = {
    where?: SessionWhereInput
    data: XOR<SessionUpdateWithoutSkillHistoriesInput, SessionUncheckedUpdateWithoutSkillHistoriesInput>
  }

  export type SessionUpdateWithoutSkillHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSessionsNestedInput
    scenario?: ScenarioUpdateOneRequiredWithoutSessionsNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateWithoutSkillHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    scenarioId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type CharacterCreateWithoutSanityHistoriesInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutCharacterInput
    images?: CharacterImageCreateNestedManyWithoutCharacterInput
  }

  export type CharacterUncheckedCreateWithoutSanityHistoriesInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionUncheckedCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutCharacterInput
    images?: CharacterImageUncheckedCreateNestedManyWithoutCharacterInput
  }

  export type CharacterCreateOrConnectWithoutSanityHistoriesInput = {
    where: CharacterWhereUniqueInput
    create: XOR<CharacterCreateWithoutSanityHistoriesInput, CharacterUncheckedCreateWithoutSanityHistoriesInput>
  }

  export type SessionCreateWithoutSanityHistoriesInput = {
    id?: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    character: CharacterCreateNestedOneWithoutSessionsInput
    scenario: ScenarioCreateNestedOneWithoutSessionsInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutSessionInput
  }

  export type SessionUncheckedCreateWithoutSanityHistoriesInput = {
    id?: string
    characterId: string
    scenarioId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutSessionInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutSessionInput
  }

  export type SessionCreateOrConnectWithoutSanityHistoriesInput = {
    where: SessionWhereUniqueInput
    create: XOR<SessionCreateWithoutSanityHistoriesInput, SessionUncheckedCreateWithoutSanityHistoriesInput>
  }

  export type CharacterUpsertWithoutSanityHistoriesInput = {
    update: XOR<CharacterUpdateWithoutSanityHistoriesInput, CharacterUncheckedUpdateWithoutSanityHistoriesInput>
    create: XOR<CharacterCreateWithoutSanityHistoriesInput, CharacterUncheckedCreateWithoutSanityHistoriesInput>
    where?: CharacterWhereInput
  }

  export type CharacterUpdateToOneWithWhereWithoutSanityHistoriesInput = {
    where?: CharacterWhereInput
    data: XOR<CharacterUpdateWithoutSanityHistoriesInput, CharacterUncheckedUpdateWithoutSanityHistoriesInput>
  }

  export type CharacterUpdateWithoutSanityHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUpdateManyWithoutCharacterNestedInput
  }

  export type CharacterUncheckedUpdateWithoutSanityHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUncheckedUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUncheckedUpdateManyWithoutCharacterNestedInput
  }

  export type SessionUpsertWithoutSanityHistoriesInput = {
    update: XOR<SessionUpdateWithoutSanityHistoriesInput, SessionUncheckedUpdateWithoutSanityHistoriesInput>
    create: XOR<SessionCreateWithoutSanityHistoriesInput, SessionUncheckedCreateWithoutSanityHistoriesInput>
    where?: SessionWhereInput
  }

  export type SessionUpdateToOneWithWhereWithoutSanityHistoriesInput = {
    where?: SessionWhereInput
    data: XOR<SessionUpdateWithoutSanityHistoriesInput, SessionUncheckedUpdateWithoutSanityHistoriesInput>
  }

  export type SessionUpdateWithoutSanityHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSessionsNestedInput
    scenario?: ScenarioUpdateOneRequiredWithoutSessionsNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateWithoutSanityHistoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    scenarioId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type CharacterCreateWithoutInsanitySymptomsInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutCharacterInput
    images?: CharacterImageCreateNestedManyWithoutCharacterInput
  }

  export type CharacterUncheckedCreateWithoutInsanitySymptomsInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionUncheckedCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutCharacterInput
    images?: CharacterImageUncheckedCreateNestedManyWithoutCharacterInput
  }

  export type CharacterCreateOrConnectWithoutInsanitySymptomsInput = {
    where: CharacterWhereUniqueInput
    create: XOR<CharacterCreateWithoutInsanitySymptomsInput, CharacterUncheckedCreateWithoutInsanitySymptomsInput>
  }

  export type SessionCreateWithoutInsanitySymptomsInput = {
    id?: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    character: CharacterCreateNestedOneWithoutSessionsInput
    scenario: ScenarioCreateNestedOneWithoutSessionsInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutSessionInput
  }

  export type SessionUncheckedCreateWithoutInsanitySymptomsInput = {
    id?: string
    characterId: string
    scenarioId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutSessionInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutSessionInput
  }

  export type SessionCreateOrConnectWithoutInsanitySymptomsInput = {
    where: SessionWhereUniqueInput
    create: XOR<SessionCreateWithoutInsanitySymptomsInput, SessionUncheckedCreateWithoutInsanitySymptomsInput>
  }

  export type CharacterUpsertWithoutInsanitySymptomsInput = {
    update: XOR<CharacterUpdateWithoutInsanitySymptomsInput, CharacterUncheckedUpdateWithoutInsanitySymptomsInput>
    create: XOR<CharacterCreateWithoutInsanitySymptomsInput, CharacterUncheckedCreateWithoutInsanitySymptomsInput>
    where?: CharacterWhereInput
  }

  export type CharacterUpdateToOneWithWhereWithoutInsanitySymptomsInput = {
    where?: CharacterWhereInput
    data: XOR<CharacterUpdateWithoutInsanitySymptomsInput, CharacterUncheckedUpdateWithoutInsanitySymptomsInput>
  }

  export type CharacterUpdateWithoutInsanitySymptomsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUpdateManyWithoutCharacterNestedInput
  }

  export type CharacterUncheckedUpdateWithoutInsanitySymptomsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUncheckedUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    images?: CharacterImageUncheckedUpdateManyWithoutCharacterNestedInput
  }

  export type SessionUpsertWithoutInsanitySymptomsInput = {
    update: XOR<SessionUpdateWithoutInsanitySymptomsInput, SessionUncheckedUpdateWithoutInsanitySymptomsInput>
    create: XOR<SessionCreateWithoutInsanitySymptomsInput, SessionUncheckedCreateWithoutInsanitySymptomsInput>
    where?: SessionWhereInput
  }

  export type SessionUpdateToOneWithWhereWithoutInsanitySymptomsInput = {
    where?: SessionWhereInput
    data: XOR<SessionUpdateWithoutInsanitySymptomsInput, SessionUncheckedUpdateWithoutInsanitySymptomsInput>
  }

  export type SessionUpdateWithoutInsanitySymptomsInput = {
    id?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSessionsNestedInput
    scenario?: ScenarioUpdateOneRequiredWithoutSessionsNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateWithoutInsanitySymptomsInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    scenarioId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type CharacterCreateWithoutImagesInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomCreateNestedManyWithoutCharacterInput
  }

  export type CharacterUncheckedCreateWithoutImagesInput = {
    id?: string
    name: string
    occupation?: string | null
    age?: number | null
    gender?: string | null
    birthplace?: string | null
    residence?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    str?: number
    con?: number
    pow?: number
    dex?: number
    app?: number
    siz?: number
    int?: number
    edu?: number
    luck?: number
    hp?: number
    maxHp?: number
    mp?: number
    maxMp?: number
    san?: number
    maxSan?: number
    mov?: number
    build?: number
    skills?: string
    sessions?: SessionUncheckedCreateNestedManyWithoutCharacterInput
    skillHistories?: SkillHistoryUncheckedCreateNestedManyWithoutCharacterInput
    sanityHistories?: SanityHistoryUncheckedCreateNestedManyWithoutCharacterInput
    insanitySymptoms?: InsanitySymptomUncheckedCreateNestedManyWithoutCharacterInput
  }

  export type CharacterCreateOrConnectWithoutImagesInput = {
    where: CharacterWhereUniqueInput
    create: XOR<CharacterCreateWithoutImagesInput, CharacterUncheckedCreateWithoutImagesInput>
  }

  export type CharacterUpsertWithoutImagesInput = {
    update: XOR<CharacterUpdateWithoutImagesInput, CharacterUncheckedUpdateWithoutImagesInput>
    create: XOR<CharacterCreateWithoutImagesInput, CharacterUncheckedCreateWithoutImagesInput>
    where?: CharacterWhereInput
  }

  export type CharacterUpdateToOneWithWhereWithoutImagesInput = {
    where?: CharacterWhereInput
    data: XOR<CharacterUpdateWithoutImagesInput, CharacterUncheckedUpdateWithoutImagesInput>
  }

  export type CharacterUpdateWithoutImagesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutCharacterNestedInput
  }

  export type CharacterUncheckedUpdateWithoutImagesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    occupation?: NullableStringFieldUpdateOperationsInput | string | null
    age?: NullableIntFieldUpdateOperationsInput | number | null
    gender?: NullableStringFieldUpdateOperationsInput | string | null
    birthplace?: NullableStringFieldUpdateOperationsInput | string | null
    residence?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    str?: IntFieldUpdateOperationsInput | number
    con?: IntFieldUpdateOperationsInput | number
    pow?: IntFieldUpdateOperationsInput | number
    dex?: IntFieldUpdateOperationsInput | number
    app?: IntFieldUpdateOperationsInput | number
    siz?: IntFieldUpdateOperationsInput | number
    int?: IntFieldUpdateOperationsInput | number
    edu?: IntFieldUpdateOperationsInput | number
    luck?: IntFieldUpdateOperationsInput | number
    hp?: IntFieldUpdateOperationsInput | number
    maxHp?: IntFieldUpdateOperationsInput | number
    mp?: IntFieldUpdateOperationsInput | number
    maxMp?: IntFieldUpdateOperationsInput | number
    san?: IntFieldUpdateOperationsInput | number
    maxSan?: IntFieldUpdateOperationsInput | number
    mov?: IntFieldUpdateOperationsInput | number
    build?: IntFieldUpdateOperationsInput | number
    skills?: StringFieldUpdateOperationsInput | string
    sessions?: SessionUncheckedUpdateManyWithoutCharacterNestedInput
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutCharacterNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutCharacterNestedInput
  }

  export type SessionCreateManyCharacterInput = {
    id?: string
    scenarioId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SkillHistoryCreateManyCharacterInput = {
    id?: string
    sessionId?: string | null
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
  }

  export type SanityHistoryCreateManyCharacterInput = {
    id?: string
    sessionId?: string | null
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
  }

  export type InsanitySymptomCreateManyCharacterInput = {
    id?: string
    sessionId?: string | null
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
  }

  export type CharacterImageCreateManyCharacterInput = {
    id?: string
    filename: string
    originalName: string
    imageName?: string | null
    filePath: string
    fileSize: number
    mimeType: string
    createdAt?: Date | string
  }

  export type SessionUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    scenario?: ScenarioUpdateOneRequiredWithoutSessionsNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    scenarioId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateManyWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    scenarioId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    session?: SessionUpdateOneWithoutSkillHistoriesNestedInput
  }

  export type SkillHistoryUncheckedUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryUncheckedUpdateManyWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SanityHistoryUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    session?: SessionUpdateOneWithoutSanityHistoriesNestedInput
  }

  export type SanityHistoryUncheckedUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SanityHistoryUncheckedUpdateManyWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InsanitySymptomUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    session?: SessionUpdateOneWithoutInsanitySymptomsNestedInput
  }

  export type InsanitySymptomUncheckedUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InsanitySymptomUncheckedUpdateManyWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionId?: NullableStringFieldUpdateOperationsInput | string | null
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CharacterImageUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    filename?: StringFieldUpdateOperationsInput | string
    originalName?: StringFieldUpdateOperationsInput | string
    imageName?: NullableStringFieldUpdateOperationsInput | string | null
    filePath?: StringFieldUpdateOperationsInput | string
    fileSize?: IntFieldUpdateOperationsInput | number
    mimeType?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CharacterImageUncheckedUpdateWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    filename?: StringFieldUpdateOperationsInput | string
    originalName?: StringFieldUpdateOperationsInput | string
    imageName?: NullableStringFieldUpdateOperationsInput | string | null
    filePath?: StringFieldUpdateOperationsInput | string
    fileSize?: IntFieldUpdateOperationsInput | number
    mimeType?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CharacterImageUncheckedUpdateManyWithoutCharacterInput = {
    id?: StringFieldUpdateOperationsInput | string
    filename?: StringFieldUpdateOperationsInput | string
    originalName?: StringFieldUpdateOperationsInput | string
    imageName?: NullableStringFieldUpdateOperationsInput | string | null
    filePath?: StringFieldUpdateOperationsInput | string
    fileSize?: IntFieldUpdateOperationsInput | number
    mimeType?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionCreateManyScenarioInput = {
    id?: string
    characterId: string
    kpName?: string | null
    playDate: Date | string
    memo?: string | null
    participants?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SessionUpdateWithoutScenarioInput = {
    id?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSessionsNestedInput
    skillHistories?: SkillHistoryUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateWithoutScenarioInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    skillHistories?: SkillHistoryUncheckedUpdateManyWithoutSessionNestedInput
    sanityHistories?: SanityHistoryUncheckedUpdateManyWithoutSessionNestedInput
    insanitySymptoms?: InsanitySymptomUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type SessionUncheckedUpdateManyWithoutScenarioInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    kpName?: NullableStringFieldUpdateOperationsInput | string | null
    playDate?: DateTimeFieldUpdateOperationsInput | Date | string
    memo?: NullableStringFieldUpdateOperationsInput | string | null
    participants?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryCreateManySessionInput = {
    id?: string
    characterId: string
    skillName: string
    oldValue: number
    newValue: number
    reason?: string | null
    createdAt?: Date | string
  }

  export type SanityHistoryCreateManySessionInput = {
    id?: string
    characterId: string
    oldValue: number
    newValue: number
    reason: string
    createdAt?: Date | string
  }

  export type InsanitySymptomCreateManySessionInput = {
    id?: string
    characterId: string
    symptomType: string
    symptomName: string
    description?: string | null
    isRecovered?: boolean
    recoveredAt?: Date | string | null
    createdAt?: Date | string
  }

  export type SkillHistoryUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSkillHistoriesNestedInput
  }

  export type SkillHistoryUncheckedUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SkillHistoryUncheckedUpdateManyWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    skillName?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SanityHistoryUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutSanityHistoriesNestedInput
  }

  export type SanityHistoryUncheckedUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SanityHistoryUncheckedUpdateManyWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    oldValue?: IntFieldUpdateOperationsInput | number
    newValue?: IntFieldUpdateOperationsInput | number
    reason?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InsanitySymptomUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    character?: CharacterUpdateOneRequiredWithoutInsanitySymptomsNestedInput
  }

  export type InsanitySymptomUncheckedUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InsanitySymptomUncheckedUpdateManyWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    characterId?: StringFieldUpdateOperationsInput | string
    symptomType?: StringFieldUpdateOperationsInput | string
    symptomName?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    isRecovered?: BoolFieldUpdateOperationsInput | boolean
    recoveredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}